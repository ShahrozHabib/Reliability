function varargout = utdgui(varargin)
% UTDGUI MATLAB code for utdgui.fig
%      UTDGUI, by itself, creates a new UTDGUI or raises the existing
%      singleton*.
%
%      H = UTDGUI returns the handle to a new UTDGUI or the handle to
%      the existing singleton*.
%
%      UTDGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UTDGUI.M with the given input arguments.
%
%      UTDGUI('Property','Value',...) creates a new UTDGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before utdgui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to utdgui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help utdgui

% Last Modified by GUIDE v2.5 04-Nov-2014 16:33:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @utdgui_OpeningFcn, ...
                   'gui_OutputFcn',  @utdgui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before utdgui is made visible.
function utdgui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to utdgui (see VARARGIN)

% Choose default command line output for utdgui
handles.output = hObject;

set (hObject,'CurrentAxes',handles.background);
imshow ('backgr.bmp');
axis(handles.background,'normal');

axes(handles.axes3);
imshow('nust1.jpg')

set(handles.savebutton,'enable','off');

handles.utd.imm = '';
handles.utd.x = '';
handles.utd.y = '';
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes utdgui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = utdgui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in savebutton.
function savebutton_Callback(hObject, eventdata, handles)
% hObject    handle to savebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[graph_filename,graph_pathname] = uiputfile('.dat');
graph_fullpath = fullfile(graph_pathname,graph_filename);

y=handles.utd.y;

fid = fopen(graph_fullpath, 'w');
fprintf(fid,'SONATEST WAVEFORM FILE: ALOG  1\rRANGE = 50\rVELOCITY = 5926\rGAIN = 25.0\rWAVEFORM AMPLITUDES');

for kop=1:255
    fprintf(fid,'\r%d',y(kop));
end
fclose(fid);
save(uiputfile)

%csvwrite(uiputfile('.dat'),y');




% --- Executes on button press in loadimage.
function loadimage_Callback(hObject, eventdata, handles)
% hObject    handle to loadimage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[picture,pathname]=uigetfile('*.jpg');

[handles.utd.imm,handles.utd.x,handles.utd.y]=utdimage(picture,pathname);

axes(handles.axes3);
imshow(handles.utd.imm)

axes(handles.axes4);
plot(handles.utd.x,handles.utd.y);

set(handles.savebutton,'enable','on');

guidata(hObject,handles);




% --- Executes on button press in loadgraph.
function loadgraph_Callback(hObject, eventdata, handles)
% hObject    handle to loadgraph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.savebutton,'enable','off');
axes(handles.axes3);
imshow('nust1.jpg');

graphload=uigetfile('*.mat');

g=load(graphload);

axes(handles.axes4);
plot(g.handles.utd.x,g.handles.utd.y);
