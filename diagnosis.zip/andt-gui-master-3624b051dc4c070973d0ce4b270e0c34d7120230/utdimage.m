function [imm,x,y]=utdimage(picture,pathname)

currentpath=cd;

cd(pathname);

%crop rotate and convertimage to 2d matrix

JJ = imread(picture);
[im n m] =crop_image(JJ);
%figure;
%imshow(im);
%n is lengthsmaller
%m is widthgreater

imm=im;
im = imrotate(im,270);
im = im2bw(im,0.01);
%figure;
%image(im);

%these two loops look for grid lines and remove them

%removes vertical lines

for ff=20:m
    q=all(im(ff,:)==0,3);
    w=find(q,1,'last');
    
    if isempty(w)
       continue;
   end
    
    if (w>=n)&&(w<=m)
        im(ff,:)=255;
    end
end

%removes horizontal lines
im(:,(n/2:n))=255;
for rr=50:n
    zz=all(im(:,rr)==0,3);
    pp=find(zz,1,'last')
    
    if isempty(pp)
       continue;
   end
    
    if ((pp>=n)&&(pp<=(m+10)))||((pp>=549)&&(pp<=553))
        im(:,rr)=255;
    end
end
 %|| ((pp>=549)&&(pp<=553)
%im(:,512)=255;
%im(:,385)=255;
%im(:,257)=255;
%im(:,130)=255;
%im(145,:)=255;
%im(287,:)=255;
%im(428,:)=255;
%im(570,:)=255;
%im(712,:)=255;
%im(636,641)=255;

%figure;
%imshow(im);
%[x,y] = find(all(im==0,3)); %# find black pixels
%x=single(x);
%y=single(y);
Magdata=0;
ii=length(im);

%this loop looks for black pixels remaining
for C=1:ii
   h=all(im(C,:)==0,3);
   j=find(h);
   if isempty(j)
       continue;
   end
   %j=j';
   vals=minmax(j);
   Magdata = horzcat(Magdata,vals);

end

dp=downsample(Magdata,6);
dp = round(255*(dp./max(dp)));
lll=length(dp);

if lll<255
    zeropad=255-lll;
    dp=horzcat(dp,zeros(1,zeropad));
end

llll=length(dp);
x=0:50/(llll-1):50;
y=dp;



%lll=length(Magdata);
%x=0:50/(lll-1):50;
%y=Magdata;



cd(currentpath);



