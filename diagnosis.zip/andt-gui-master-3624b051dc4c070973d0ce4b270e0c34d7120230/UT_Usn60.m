
function [yaxis,xaxis]=UT_Usn60(varargin,savefile,ylimit,xlimit)
%the function can be used for calibrating graphs coordinates
%it also cancells out the vertical and horizontal lines of grid if it is 
%(255 255 255) black this shows 4 graphs and allows viewing of plots 
%in stem.
%email: talhawaqar1@hotmail.com
%
%example
%[yaxis,xaxis]=UT_Usn60(file to be read,file name to be save as,range of yaxis output,range of xaxis output)
%[yaxis,xaxis]=UT_Usn60('1.jpg','file1.mat',280)

line=500;
ui = [0 0 0];
copy = imcrop(varargin,[4 3 791 640]);
inc1=1;
inc2=1;
xaxis=1:80000;
yaxis=1:80000;
x2axis=1:80000;
y2axis=1:80000;
%x3axis=1:80000;
%y3axis=1:80000;
%%%%%%%%%%%%%%%%%%%
%newx=1:400;
%newy=1:400;
%no1=1;
%no2=1;

%%%%%%%%%%%%%%%%%%

figure(4)
imshow(copy)


inc1=1;
inc2=1;
columns=791;
rowsl=791;

for y = 1:1:columns
    nextinc2=0;
for x = 1:1:rowsl
    c = [y];
    r = [791-x];
pixels = impixel(copy,c,r);

if nextinc2 <= (line-1)
if pixels == ui
   
    x2axis(inc1)=x;
    y2axis(inc2)=y;
    inc1=inc1+1;
    inc2=inc2+1;
    nextinc2=nextinc2+1;
    fprintf('in process\n')
    
end
if nextinc2 == line
%    newx(no1)=x;
 %   newy(no2)=y;
  %  no1=no1+1;
   % no2=no2+1;
    inc1=inc1-line;
    inc2=inc2-line;
for n=1:791
        copy(n,y2axis(inc2),:) = [219,50,40];
    end
  
    
end
end

end
end


inc1=1;
inc2=1;
line2=100;
figure(9)
imshow(copy)

for x = 1:1:rowsl
    nextinc2=0;
for y = 1:1:columns
    c = [y];
    r = [791-x];
pixels = impixel(copy,c,r);
if nextinc2 <= (line2-1)
if pixels == ui
   
    xaxis(inc1)=x*(xlimit/643);
    yaxis(inc2)=y*(ylimit/791);
    inc1=inc1+1;
    inc2=inc2+1;
    nextinc2=nextinc2+1;
    fprintf('in process\n')
end
if nextinc2 == line2
    inc1=inc1-line2;
    inc2=inc2-line2;
    
end

end
end
end

inc1=1;
inc2=2;

%for n=1:300
%    if xaxis ~= 0
%    if y2axis(n) == xaxis(n)
%        y2axis(inc1) == xaxis(inc1);
%        inc1=inc1+1;
%    end
%    end
 %   if yaxis ~= 0
%        if x2axis(n) == yaxis(n)
%            x2axis(inc2)=yaxis(inc2);
%            inc2=inc2+1;
%        end
 %   end
%end
        







u=1:7000;
i=1:7000;
figure(1)
stem(y2axis(u),x2axis(i)-10)
figure(2)
stem(yaxis(u),xaxis(i)-10)
fprintf('end')

save(savefile)
