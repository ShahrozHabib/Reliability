function [ Enrgy ] = UT_hlhut(A, varargin)

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
    if (optargin == 3)
        k = varargin{2}; % Get Location Number
        cmap = varargin{3};
    elseif (optargin == 2)
        k = varargin{2}; % Get Location Number
        cmap = colormap; % Keep the default colormap by default
    else
        k = 1;      % Keep default Location: 1
        cmap = colormap; % Keep the default colormap by default
    end
    axis on;
else
    % disp_h = 1; 
end

% for k=1:4
    subplot(1,1,1);
    
    imf=emd((A(:,k)));
    [aaa,fff,ttf] = UT_hhspectrum(imf);
    [im,ttt] = toimage(aaa,fff);
%     subplot(2,2,k)
    UT_disp_hhs(im)
%     colormap(bone)
%     colormap(1-colormap)
    colormap(cmap);
    axis([6 10 0.06 0.15])
    colorbar
    
%     load('temp.mat', 'im')
%       for i=1
%          % n=i*5-4;
%       Ft=cumsum(im(6:15,30:51)'); % distance from 6 mm till 10 mm 
%       %Ft=cumsum(im');
%       Tf=Ft';
%       sd=size(Ft);
%       Cd=Tf(:,sd(1)); % length of Tf in case of old one 
%       VB(i,k)=mean(Cd);
%       end
%  % for normalized values
%  
%       V=cumsum(VB);
%       V1=V(length(V),:);
%       for o=1:length(V1)
%           Q(:,o)=VB(:,o)/V1(o);
%       end
%      
% end
% 
% Enrgy=Q;

% end

