function [ clean_binimage ] = ET_morph_ops( adaptive_thresholding_image, varargin)
% This is the 5th function. Is used to apply morphological operation on the
% given image

CBW=adaptive_thresholding_image;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

% if optargin         % if optional arguments present          
%     disp_h = varargin{1};
%     axes (disp_h);
%     axis on;      
% else
%     % disp_h = 1; 
% end

if (optargin == 2)
    cmap = varargin{2};
    disp_h = varargin{1};
    axes (disp_h);
    axis on; 
elseif (optargin ==1)
    cmap = colormap;
    disp_h = varargin{1};
    axes (disp_h);
    axis on; 
else
    cmap = colormap;
    %disp_h = varargin{1};
    axes (disp_h);
    axis on;
end
  
CBW = bwmorph(adaptive_thresholding_image,'majority',2); % Used to make the image more uniform based on neighbouring pixel values.


CBW = bwmorph(CBW,'remove',2);

CBW = bwmorph(CBW,'majority',2);
 

    %figure(10)
    imagesc(CBW);
    colormap(cmap);
    title('Scaled image plot of Magnitude after thresholding and ROI Detection','FontSize', 11);
xlabel('Indices','FontSize', 11)
ylabel('Rows','FontSize', 11);
h=colorbar;
xlabel(h,'Voltage','FontSize', 11);

clean_binimage=CBW;
end

