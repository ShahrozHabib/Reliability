function [croppedim rowssss colssss]=crop_image(im)

%im=imread('SPINDLE.jpg');

[m,~]=size(im);
r= im(:,:,3);
[~,n]=size(r);
firstcol=1;
firstrow=2;
secondcol=100 ;
secondrow=100;

%first horz border


for A=1:m/2
    rows1=im(A,:);
    num1=histc(rows1,100);
    if num1>=300
        firstrow=A;
    end
end

%second horzborder
for B=50:m
    rows2=im(B,:);
    num2=histc(rows2,100);
    if num2>=300
        secondrow=B;
    end
end

%1st vertical border

for C=1:n/2
    cols1=r(:,C);
    num3=histc(cols1,100);
    if num3>=300
        firstcol=C;
    end
end
%second vertical border
for D=50:n
    cols2=r(:,D);
    num4=histc(cols2,100);
    if num4>=300
        secondcol=D;
    end
end


%firstrow 
%secondrow
%firstcol
%secondcol


croppedim = imcrop(im,[firstcol firstrow+1 (secondcol-firstcol-1) (secondrow-firstrow-2)]);
%imshow(croppedim)
colssss=(secondcol-firstcol-1);
rowssss=(secondrow-firstrow-2);
%[1stcol 1strow 2ndcolumn 2ndrow]