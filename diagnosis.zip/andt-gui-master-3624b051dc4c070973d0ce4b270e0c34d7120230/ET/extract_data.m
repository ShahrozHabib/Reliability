
function [impedence, impedence_mag, Real_Component, Imaginary_Component] = extract_data(path)
%   This is the 1st function and is used to extract data files from the folder placed in
%   in the PC. The input of this function is the path of the folder in
%   which raw data file is placed and output is the impedence and its
%   magnitude.
%--------------------------------------------------------------------------------------------

% Extract all files sequencially placed in a 200KHz data file folder 

nm=dir(path);
for i=1:length(nm);
    newdata=importdata(nm(i).name,' ', 17);
    vars=fieldnames(newdata);
    A(:,i)=newdata.(vars{1});
    clear newdata
    clear vars
end

% Remove Noise i.e starting and ending values from the matrix

A=A(341:end-321,:);  


% Place all the real component values in x matrix

[row,col]=size(A);
i=1;
k=row;
for j=1:col                   
x(j,:)=A(i:2:k);    
i=i+row;
k=k+row;
end
x=x';
Real_Component= x;
% Place all the imaginary values in y matrix

[row,col]=size(A);
i=2;
k=row;
for j=1:col                   
y(j,:)=A(i:2:k);    
i=i+row;
k=k+row;
end
y=y';
Imaginary_Component=y;
% Formation of Impedence Matrix and its Plotting

impedence=x+1i*y;
figure (1);
plot(impedence,'*');
title('Impedance Plot of Raw Data');
xlabel('Resistance, R');
ylabel('Inductive Reactance,X');

% Calculation of Impedence Magnitude and its plotting

impedence_mag=abs(impedence);
% figure (2)
% plot(impedence_mag);
% title('Impedence Magnitude Plot of Raw Data');
% xlabel('Indices');
% ylabel('Amplitude');


end

