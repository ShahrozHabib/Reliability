function [ calibrate_impedence, imaginary_part, real_part ] = calibrate( impedence,impedence_mag,Real_Component,Imaginary_Component)

% This is the 2nd function and is used to calibrate raw data.
% The input of this function is impedence magnitude matrix, Real_Component
% Matrix, Imaginary_Component Matrix.
% output is the calibrated data. The calibration is done by getting two calibration
% parameters i.e Rotation matrix and scaling factor. Data is also centered
% through this function.

%-------------------------------------------------------------------------
x=Real_Component;
y=Imaginary_Component;

MaxMag = max(max(impedence_mag));
[a, b] = find(impedence_mag == MaxMag);
Phs = 180/pi*angle(impedence(a(1),b(1))); % ans is in degree
Rot_Deg = (135 - Phs)/180*pi;
RotMat= [cos(Rot_Deg) -1*sin(Rot_Deg); sin(Rot_Deg) cos(Rot_Deg)];
ScalingFactor=(10/MaxMag);




x1=x(:,1);
x2=x(:,2);
x3=x(:,3);
x4=x(:,4);
x5=x(:,5);
x6=x(:,6);
x7=x(:,7);
x8=x(:,8);
x9=x(:,9);


y1=y(:,1);
y2=y(:,2);
y3=y(:,3);
y4=y(:,4);
y5=y(:,5);
y6=y(:,6);
y7=y(:,7);
y8=y(:,8);
y9=y(:,9);


x1y1= [x1 y1];
rot_x1y1= (x1y1*RotMat);
sc_rot_x1y1=rot_x1y1 * ScalingFactor;
cal_x1 = sc_rot_x1y1(:,[1]);
cal_y1 = sc_rot_x1y1(:,[2]);
newx1=cal_x1-(max(cal_x1))*(ones(size(cal_x1))); % Data Centering
newy1=cal_y1-(min(cal_y1))*(ones(size(cal_y1))); % Data Centering
imp1=newx1+ 1i*newy1;

x2y2= [x2 y2];
rot_x2y2= (x2y2*RotMat);
sc_rot_x2y2=rot_x2y2 * ScalingFactor;
cal_x2 = sc_rot_x2y2(:,[1]);
cal_y2 = sc_rot_x2y2(:,[2]);
newx2=cal_x2-(max(cal_x2))*(ones(size(cal_x2)));
newy2=cal_y2-(min(cal_y2))*(ones(size(cal_y2)));
imp2=newx2+ 1i*newy2;

x3y3= [x3 y3];
rot_x3y3= (x3y3*RotMat);
sc_rot_x3y3=rot_x3y3 * ScalingFactor;
cal_x3 = sc_rot_x3y3(:,[1]);
cal_y3 = sc_rot_x3y3(:,[2]);
newx3=cal_x3-(max(cal_x3))*(ones(size(cal_x3)));
newy3=cal_y3-(min(cal_y3))*(ones(size(cal_y3)));
imp3=newx3+ 1i*newy3;

x4y4= [x4 y4];
rot_x4y4= (x4y4*RotMat);
sc_rot_x4y4=rot_x4y4 * ScalingFactor;
cal_x4 = sc_rot_x4y4(:,[1]);
cal_y4 = sc_rot_x4y4(:,[2]);
newx4=cal_x4-(max(cal_x4))*(ones(size(cal_x4)));
newy4=cal_y4-(min(cal_y4))*(ones(size(cal_y4)));
imp4=newx4+ 1i*newy4;

x5y5= [x5 y5];
rot_x5y5= (x5y5*RotMat);
sc_rot_x5y5=rot_x5y5 * ScalingFactor;
cal_x5 = sc_rot_x5y5(:,[1]);
cal_y5 = sc_rot_x5y5(:,[2]);
newx5=cal_x5-(max(cal_x5))*(ones(size(cal_x5)));
newy5=cal_y5-(min(cal_y5))*(ones(size(cal_y5)));
imp5=newx5+ 1i*newy5;

x6y6= [x6 y6];
rot_x6y6= (x6y6*RotMat);
sc_rot_x6y6=rot_x6y6 * ScalingFactor;
cal_x6 = sc_rot_x6y6(:,[1]);
cal_y6 = sc_rot_x6y6(:,[2]);
newx6=cal_x6-(max(cal_x6))*(ones(size(cal_x6)));
newy6=cal_y6-(min(cal_y6))*(ones(size(cal_y6)));
imp6=newx6+ 1i*newy6;

x7y7= [x7 y7];
rot_x7y7= (x7y7*RotMat);
sc_rot_x7y7=rot_x7y7 * ScalingFactor;
cal_x7 = sc_rot_x7y7(:,[1]);
cal_y7 = sc_rot_x7y7(:,[2]);
newx7=cal_x7-(max(cal_x7))*(ones(size(cal_x7)));
newy7=cal_y7-(min(cal_y7))*(ones(size(cal_y7)));
imp7=newx7+ 1i*newy7;

x8y8= [x8 y8];
rot_x8y8= (x8y8*RotMat);
sc_rot_x8y8=rot_x8y8 * ScalingFactor;
cal_x8 = sc_rot_x8y8(:,[1]);
cal_y8 = sc_rot_x8y8(:,[2]);
newx8=cal_x8-(max(cal_x8))*(ones(size(cal_x8)));
newy8=cal_y8-(min(cal_y8))*(ones(size(cal_y8)));
imp8=newx8+ 1i*newy8;

x9y9= [x9 y9];
rot_x9y9= (x9y9*RotMat);
sc_rot_x9y9=rot_x9y9 * ScalingFactor;
cal_x9 = sc_rot_x9y9(:,[1]);
cal_y9 = sc_rot_x9y9(:,[2]);
newx9=cal_x9-(max(cal_x9))*(ones(size(cal_x9)));
newy9=cal_y9-(min(cal_y9))*(ones(size(cal_y9)));
imp9=newx9+ 1i*newy9;
imaginary_part = [ newy1 newy2 newy3 newy4 newy5 newy6 newy7 newy8 newy9]';
real_part = [ newx1 newx2 newx3 newx4 newx5 newx6 newx7 newx8 newx9]';

new_mag=[abs(imp1) abs(imp2) abs(imp2) abs(imp4) abs(imp5) abs(imp6) abs(imp7) abs(imp8) abs(imp9)];

figure (3)
plot(new_mag);
title('Plot of Calibrated Magnitude');
xlabel('indices')
ylabel('Amplitude');

figure (4)
imagesc(imaginary_part);
title('Imagesc plot of Calibrated Imaginary Part');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');


figure (5)
imagesc(real_part);
title('Imagesc plot of Calibrated Real Part');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');

new_mag=new_mag';
Data=new_mag;
figure(6)
imagesc(Data); 
title('Imagesc plot of Calibrated Magnitude');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');

calibrate_impedence=Data;







end

