function [corbox_out]=Roi_detmain(image,row_start,col_start)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  This function is used to detect the ROI boxes for a given 2D image.
%  The inputs to this function are the binary image that is to be used and
%  the starting row and column of the image from which the analysis is to
%  be performed.
%  The ouput of this function is a list of ROIs detected in the specified
%  image.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[nrow ncol]=size(image);

rowout1 = Find_roi_range(image);

corbox = [];

nran = size(rowout1,1);
for i = 1:nran
   parti = image(rowout1(i,1):rowout1(i,2),:);
   colouti = Find_roi_range(parti');
   ncra = size(colouti,1);
   boxi = [repmat(rowout1(i,:),ncra,1) colouti];
   corbox = [corbox;boxi];
end


if (~isempty(corbox))
   nboxes = size(corbox,1);
   outpoints  = corbox + repmat([row_start row_start col_start col_start],nboxes,1);
else
   outpoints = corbox;
end

corbox_out=outpoints;