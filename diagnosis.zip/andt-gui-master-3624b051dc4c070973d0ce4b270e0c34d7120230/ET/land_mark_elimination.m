function [ lme_data] = land_mark_elimination( calibrate_impedence )
% This is the 3rd function. Input is the calibrated data. Land Mark
% elimination is done on this data.


lme_data=calibrate_impedence;

for i = 1:length(lme_data(:,1))
        for j = 1:length(lme_data(1,:))
            if lme_data(i,j) >= 7
               lme_data(i,j) = 1;
            end
        end
end

figure(7)
imagesc(lme_data)
title('Imagesc plot of Magnitude After Land Mark Elimination');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');




end

