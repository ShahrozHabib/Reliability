function [ clean_binimage ] = morph_ops( adaptive_thresholding_image )
% This is the 5th function. Is used to apply morphological operation on the
% given image


  
CBW = bwmorph(adaptive_thresholding_image,'majority',2); % Used to make the image more uniform based on neighbouring pixel values.
CBW = bwmorph(CBW,'clean',2); % Used to remove isolated one pixels.

    figure(10)
    imagesc(CBW);
    title('Imagesc plot of Magnitude after thresholding and ROI Detection');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');

clean_binimage=CBW;
end

