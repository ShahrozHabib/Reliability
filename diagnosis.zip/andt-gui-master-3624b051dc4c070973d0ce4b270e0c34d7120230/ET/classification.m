function [ features ] = classification( Feature_Extracted_Boxes )
%UNTITLED2 Summary of this function goes here

features= Feature_Extracted_Boxes;

     
     for i=1:length(features);
    isDefect = '';
    if(features(i).A200_maxVert >= 0.08) 
        %if( (features(i).A300_PhsMxVert  > params.A300_PhsMxVert_low) && (features(i).A300_PhsMxVert  < params.A300_PhsMxVert_high))
            if( (features(i).A200_PhsMxVert  > 20) && (features(i).A200_PhsMxVert  < 140))                              % values taken from SPfiles Arkanas
                if( (features(i).A100_PhsMxVert  > 0) && (features(i).A100_PhsMxVert  < 130))                        % values taken from SPfiles Arkanas
                    %if(CL_OD == 1)  % what is CL_OD?                                                                         % values taken from SPfiles Arkanas
                        %if((features(i).A300_PhsMxVert - features(i).A200_PhsMxVert) > params.A300_200)                      
                             if((features(i).A200_PhsMxVert - features(i).A100_PhsMxVert) >= -5)  %% values taken from SPfiles Arkanas 
                                 isDefect = 'A';
                            end
                        %end
                    %end
                    %if( (params.CL_OD == 0) || (params.CL_OD == 2) )
                        %if((features(i).A100_PhsMxVert - features(i).A200_PhsMxVert) > params.A100_200)
                            %if((features(i).A200_PhsMxVert - features(i).A300_PhsMxVert) >= params.A200_300)
                                %isDefect = 'A';
                            %end                        
                        %end
                    %end
                end
            end
        %end
    end
  
    
    isDefect = [isDefect];
    if(strcmp(isDefect,'A'))
        isDefect = 'DEFECT';
    %elseif(strcmp(isDefect,'C'))
        %isDefect = 'SCI';
    %elseif(strcmp(isDefect, 'AC'))
        %isDefect = 'VOL';
    else 
        isDefect = 'NO DEFECT';
    end 
    features(i).isDefect = isDefect;
end




end

