function [ adaptive_thresholding_image ] = Adaptive_Thresholding( lme_data )

% This is the 4th function. Input is the land mark eliminated data and output
% is the binary image after adaptive thresholding

number_bins=100;
    elim_percent=1;
    im2d=lme_data;
   
    Numrow=size(im2d,1);
    Numcol=size(im2d,2);
    bin_img=zeros(size(im2d));
    % 2D to 1D conversion before histogram thresholding.
    im2dnew=im2d';
    im1d=im2dnew(:);
   
    %-------------------------------------------------------------------------%
    length1d=size(im1d,1);
    N=length1d;
    nbin=number_bins;
    x=im1d;
    %------There is median removal before thresholding------------------------%
    mn=median(x);
    x=x-mn;
    %-------------------------------------------------------------------------%
    [P,Q] = hist(x,nbin);
       
    %% Only for plotting use 100 bins
    [hdist, hcent]=hist(x,100);
    figure(8)
    hist(x,100);
    title('Histogram of Calibrated Magnitude')
    xlabel('Voltage');
    ylabel('Frequency');
    
    
    
    for pp=1:nbin
        P_acc(pp)=sum(P(1:pp));
    end;
    P_acc=P_acc/N;
     
        
    index_thresh=min(find(P_acc>=elim_percent));
  
    thresh_return=abs(Q(index_thresh));
    
%     
    index=1;
    %Thresholding------------------
    for index=1:length1d
%    if(im1d(index)<thresh_return) 
     if(im1d(index)>thresh_return) % lu
        
         im1d(index)=1;
        else
            im1d(index)=0;
     end

    end
    index=1;
    % 1D to 2D conversion to reshape the thresholded output into the required
    % format
    bin_img=reshape(im1d,[Numcol,Numrow])';
   figure(9)
    imagesc(bin_img);
    title('Imagesc plot of Magnitude');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');
adaptive_thresholding_image=bin_img;  
    %


end

