clc;
close all;
clear all;
%%
%***************  200k DATA FILE 1 ******************

fid1 = fopen('NortecData_200k_1.dat','rt');
a1 = textscan(fid1, '%f', 'HeaderLines',17);
a1 = a1{1} ;
fclose(fid1);

x1 = a1(363:2:end-321);
y1 = a1(364:2:end-321);
z1 = x1 + 1i*y1 ;

%%
%*************** 200k DATA FILE 2 ******************

fid2 = fopen('NortecData_200k_2.dat','rt');
a2= textscan(fid2, '%f', 'HeaderLines',17);
a2 = a2{1} ;
fclose(fid2);

x2 = a2(363:2:end-321);

y2 = a2(364:2:end-321);

z2 = x2 + 1i*y2 ;

%%
%*************** 200k DATA FILE 3 ******************

fid3 = fopen('NortecData_200k_3.dat','rt');
a3 = textscan(fid3, '%f', 'HeaderLines',17);
a3 = a3{1} ;
fclose(fid3);

x3 = a3(363:2:end-321);

y3 = a3(364:2:end-321);

z3 = x3 + 1i*y3 ;

%%
%***************200k DATA FILE 4 ******************

fid4 = fopen('NortecData_200k_4.dat','rt');
a4 = textscan(fid4, '%f', 'HeaderLines',17);
a4 = a4{1} ;
fclose(fid4);

x4 = a4(363:2:end-321);

y4 = a4(364:2:end-321);

z4 = x4 + 1i*y4 ;

%%
%*************** 200k DATA FILE 5 ******************

fid5 = fopen('NortecData_200k_5.dat','rt');
a5 = textscan(fid5, '%f', 'HeaderLines',17);
a5 = a5{1} ;
fclose(fid5);

x5 = a5(363:2:end-321);

y5 = a5(364:2:end-321);

z5 = x5 + 1i*y5 ;

%%
%*************** 200k DATA FILE 6 ******************

fid6 = fopen('NortecData_200k_6.dat','rt');
a6 = textscan(fid6, '%f', 'HeaderLines',17);
a6 = a6{1} ;
fclose(fid6);

x6 = a6(363:2:end-321);

y6 = a6(364:2:end-321);

z6 = x6 + 1i*y6 ;

%%
%*************** 200k DATA FILE 7 ******************

fid7 = fopen('NortecData_200k_7.dat','rt');
a7 = textscan(fid7, '%f', 'HeaderLines',17);
a7 = a7{1} ;
fclose(fid7);

x7 = a7(363:2:end-321);

y7 = a7(364:2:end-321);

z7 = x7 + 1i*y7 ;

%%
%*************** 200k DATA FILE 8 ******************

fid8 = fopen('NortecData_200k_8.dat','rt');
a8 = textscan(fid8, '%f', 'HeaderLines',17);
a8 = a8{1} ;
fclose(fid8);

x8 = a8(363:2:end-321);

y8 = a8(364:2:end-321);

z8 = x8 + 1i*y8 ;

%%
%*************** 200k DATA FILE 9 ******************

fid9 = fopen('NortecData_200k_9.dat','rt');
a9 = textscan(fid9, '%f', 'HeaderLines',17);
a9 = a9{1} ;
fclose(fid9);

x9 = a9(363:2:end-321);

y9 = a9(364:2:end-321);

z9 = (x9 + 1i*y9);
% 
%% Impedence

z=[z1 z2 z3 z4 z5 z6 z7 z8 z9]';
plot(z,'*');
title('Impedance plot');
xlabel('Resistance, R');
ylabel('Inductive Reactance,X');






%% Magnitudes

abs_z1=abs(z1);
abs_z2=abs(z2);
abs_z3=abs(z3);
abs_z4=abs(z4);
abs_z5=abs(z5);
abs_z6=abs(z6);
abs_z7=abs(z7);
abs_z8=abs(z8);
abs_z9=abs(z9);


%%
%***********************************************************************
%******************** Calculation of Caliberation Parameters***************************
%***********************************************************************

abs_mag= [abs_z1 abs_z2 abs_z3 abs_z4 abs_z5 abs_z6 abs_z7 abs_z8 abs_z9]; 
figure (1)
plot(abs_mag)
title('Magnitude Matrix Plot');
title('Magnitude Plot');
xlabel('Indices');
ylabel('Amplitude');

MaxMag = max(max(abs_mag));
[a, b] = find(abs_mag == MaxMag);
impedence_matrix= [z1 z2 z3 z4 z5 z6 z7 z8 z9];

Phs = 180/pi*angle(impedence_matrix(a(1),b(1))); % ans is in degree
Rot_Deg = (135 - Phs)/180*pi;
RotMat= [cos(Rot_Deg) -1*sin(Rot_Deg); sin(Rot_Deg) cos(Rot_Deg)];
ScalingFactor=(10/MaxMag);

figure(2)
imagesc(abs_mag');
title('Imagesc plot of Magnitude');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');


    
x1y1= [x1 y1];
rot_x1y1= (x1y1*RotMat);
sc_rot_x1y1=rot_x1y1 * ScalingFactor;
cal_x1 = sc_rot_x1y1(:,[1]);
cal_y1 = sc_rot_x1y1(:,[2]);
newx1=cal_x1-(max(cal_x1))*(ones(size(cal_x1))); % Data Centering
newy1=cal_y1-(min(cal_y1))*(ones(size(cal_y1))); % Data Centering
imp1=newx1+ 1i*newy1;

x2y2= [x2 y2];
rot_x2y2= (x2y2*RotMat);
sc_rot_x2y2=rot_x2y2 * ScalingFactor;
cal_x2 = sc_rot_x2y2(:,[1]);
cal_y2 = sc_rot_x2y2(:,[2]);
newx2=cal_x2-(max(cal_x2))*(ones(size(cal_x2)));
newy2=cal_y2-(min(cal_y2))*(ones(size(cal_y2)));
imp2=newx2+ 1i*newy2;

x3y3= [x3 y3];
rot_x3y3= (x3y3*RotMat);
sc_rot_x3y3=rot_x3y3 * ScalingFactor;
cal_x3 = sc_rot_x3y3(:,[1]);
cal_y3 = sc_rot_x3y3(:,[2]);
newx3=cal_x3-(max(cal_x3))*(ones(size(cal_x3)));
newy3=cal_y3-(min(cal_y3))*(ones(size(cal_y3)));
imp3=newx3+ 1i*newy3;

x4y4= [x4 y4];
rot_x4y4= (x4y4*RotMat);
sc_rot_x4y4=rot_x4y4 * ScalingFactor;
cal_x4 = sc_rot_x4y4(:,[1]);
cal_y4 = sc_rot_x4y4(:,[2]);
newx4=cal_x4-(max(cal_x4))*(ones(size(cal_x4)));
newy4=cal_y4-(min(cal_y4))*(ones(size(cal_y4)));
imp4=newx4+ 1i*newy4;

x5y5= [x5 y5];
rot_x5y5= (x5y5*RotMat);
sc_rot_x5y5=rot_x5y5 * ScalingFactor;
cal_x5 = sc_rot_x5y5(:,[1]);
cal_y5 = sc_rot_x5y5(:,[2]);
newx5=cal_x5-(max(cal_x5))*(ones(size(cal_x5)));
newy5=cal_y5-(min(cal_y5))*(ones(size(cal_y5)));
imp5=newx5+ 1i*newy5;

x6y6= [x6 y6];
rot_x6y6= (x6y6*RotMat);
sc_rot_x6y6=rot_x6y6 * ScalingFactor;
cal_x6 = sc_rot_x6y6(:,[1]);
cal_y6 = sc_rot_x6y6(:,[2]);
newx6=cal_x6-(max(cal_x6))*(ones(size(cal_x6)));
newy6=cal_y6-(min(cal_y6))*(ones(size(cal_y6)));
imp6=newx6+ 1i*newy6;

x7y7= [x7 y7];
rot_x7y7= (x7y7*RotMat);
sc_rot_x7y7=rot_x7y7 * ScalingFactor;
cal_x7 = sc_rot_x7y7(:,[1]);
cal_y7 = sc_rot_x7y7(:,[2]);
newx7=cal_x7-(max(cal_x7))*(ones(size(cal_x7)));
newy7=cal_y7-(min(cal_y7))*(ones(size(cal_y7)));
imp7=newx7+ 1i*newy7;

x8y8= [x8 y8];
rot_x8y8= (x8y8*RotMat);
sc_rot_x8y8=rot_x8y8 * ScalingFactor;
cal_x8 = sc_rot_x8y8(:,[1]);
cal_y8 = sc_rot_x8y8(:,[2]);
newx8=cal_x8-(max(cal_x8))*(ones(size(cal_x8)));
newy8=cal_y8-(min(cal_y8))*(ones(size(cal_y8)));
imp8=newx8+ 1i*newy8;

x9y9= [x9 y9];
rot_x9y9= (x9y9*RotMat);
sc_rot_x9y9=rot_x9y9 * ScalingFactor;
cal_x9 = sc_rot_x9y9(:,[1]);
cal_y9 = sc_rot_x9y9(:,[2]);
newx9=cal_x9-(max(cal_x9))*(ones(size(cal_x9)));
newy9=cal_y9-(min(cal_y9))*(ones(size(cal_y9)));
imp9=newx9+ 1i*newy9;
calibrated_data.outim_200k = [ newy1 newy2 newy3 newy4 newy5 newy6 newy7 newy8 newy9]';
calibrated_data.outre_200k = [ newx1 newx2 newx3 newx4 newx5 newx6 newx7 newx8 newx9]';
new_mag=[abs(imp1) abs(imp2) abs(imp2) abs(imp4) abs(imp5) abs(imp6) abs(imp7) abs(imp8) abs(imp9)];

figure (3)
plot(new_mag);



new_mag=new_mag';
 Data=new_mag;
figure(4)
imagesc(Data);
title('Imagesc plot of Calibrated Magnitude');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');


figure (14)
imagesc(calibrated_data.outim_200k);
title('Imagesc plot of Calibrated Imaginary Part');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');


figure (15)
imagesc(calibrated_data.outre_200k);
title('Imagesc plot of Calibrated Real Part');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');





% 
%%  Pre processing Land Mark Elimination From Image

for i = 1:length(Data(:,1))
        for j = 1:length(Data(1,:))
            if Data(i,j) >= 7
               Data(i,j) = 1;
            end
        end
end

figure(5)
imagesc(Data)
title('Imagesc plot of Magnitude After Land Mark Elimination');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');


    %% Adaptive_Thresholding_simple
    
    number_bins=100;
    elim_percent=1;
    im2d=Data;
   
    Numrow=size(im2d,1);
    Numcol=size(im2d,2);
    bin_img=zeros(size(im2d));
    % 2D to 1D conversion before histogram thresholding.
    im2dnew=im2d';
    im1d=im2dnew(:);
   
    %-------------------------------------------------------------------------%
    length1d=size(im1d,1);
    N=length1d;
    nbin=number_bins;
    x=im1d;
    %------There is median removal before thresholding------------------------%
    mn=median(x);
    x=x-mn;
    %-------------------------------------------------------------------------%
    [P,Q] = hist(x,nbin);
       
    %% Only for plotting use 100 bins
    [hdist, hcent]=hist(x,100);
    figure(11)
    hist(x,100);
    title('Histogram of Calibetared Magnitude')
    xlabel('Voltage');
    ylabel('Frequency');
    
    
 %   figure(11),plot(hcent,100*hdist/sum(hdist));xlabel('\bfVertical component (volts)');ylabel('\bfDistribution(%)');
    
    for pp=1:nbin
        P_acc(pp)=sum(P(1:pp));
    end;
    P_acc=P_acc/N;
 % figure;plot(Q,P_acc);xlabel('\bfVertical component (volts)');ylabel('\bfCumulative Distribution(%)');
    
        
    index_thresh=min(find(P_acc>=elim_percent));
  
    thresh_return=abs(Q(index_thresh));
    
%     lowthresh_return = 0 - thresh_return; %lu            
    
%     hold on;
%     plot(thresh_return,P_acc,'r');
%     hold on;
%     plot(lowthresh_return,P_acc,'r');
%     hold off;
    index=1;
    %Thresholding------------------
    for index=1:length1d
%    if(im1d(index)<thresh_return) 
     if(im1d(index)>thresh_return) % lu
        
         im1d(index)=1;
        else
            im1d(index)=0;
     end

    end
    index=1;
    % 1D to 2D conversion to reshape the thresholded output into the required
    % format
    bin_img=reshape(im1d,[Numcol,Numrow])';
   figure(12)
    imagesc(bin_img);
    title('Imagesc plot of Magnitude');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');
    
    %
    %% ROI Detection Morphological Operation
    
  
CBW = bwmorph(bin_img,'majority',2); % Used to make the image more uniform based on neighbouring pixel values.
CBW = bwmorph(CBW,'clean',2); % Used to remove isolated one pixels.

    figure(13)
    imagesc(CBW);
    title('Imagesc plot of Magnitude after thresholding and ROI Detection');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');

%% ROI Detection

%   This is used to determine the corners of the ROI boxes using
%   the input binary image.It includes two functions namely Find_roi_range,
%   which determines the range of ROIs in terms of rows and ROI_detmain,
%   which determines the column and rows of ROIs

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
try
clean_binimg = CBW ;

roiboxes=[];
    
    corbox1=Roi_detmain(clean_binimg,0,0);      
    corbox2=[];
 
     nbox1 = size(corbox1,1);
 
    for k = 1:nbox1
        imagek = clean_binimg(corbox1(k,1):corbox1(k,2),corbox1(k,3):corbox1(k,4));
        cboxk = Roi_detmain(imagek,corbox1(k,1)-1,corbox1(k,3)-1);
        corbox2 = [corbox2;cboxk];
    end
 
    nbox2 = size(corbox2,1);
 
    roiboxes = corbox2;        
    
    s_bit=1;
catch
    roiboxes=[];
    s_bit=0;
end

pixsum = [];
for i = 1:size(roiboxes,1)
    pixelnum = sum(sum(clean_binimg(roiboxes(i,1):roiboxes(i,2),roiboxes(i,3):roiboxes(i,4))));
    pixsum = [pixsum;pixelnum];
end

indix = find(pixsum<=6);
roiboxes(indix,:)=[];


%% 


%***************  100k DATA FILE 1 ******************

fid1 = fopen('NortecData_100k_1.dat','rt');
a1 = textscan(fid1, '%f', 'HeaderLines',17);
a1 = a1{1} ;
fclose(fid1);

x1 = a1(363:2:end-321);
y1 = a1(364:2:end-321);
z1 = x1 + 1i*y1 ;

%%
%*************** 100k DATA FILE 2 ******************

fid2 = fopen('NortecData_100k_2.dat','rt');
a2= textscan(fid2, '%f', 'HeaderLines',17);
a2 = a2{1} ;
fclose(fid2);

x2 = a2(363:2:end-321);

y2 = a2(364:2:end-321);

z2 = x2 + 1i*y2 ;

%%
%*************** 100k DATA FILE 3 ******************

fid3 = fopen('NortecData_100k_3.dat','rt');
a3 = textscan(fid3, '%f', 'HeaderLines',17);
a3 = a3{1} ;
fclose(fid3);

x3 = a3(363:2:end-321);

y3 = a3(364:2:end-321);

z3 = x3 + 1i*y3 ;

%%
%***************100k DATA FILE 4 ******************

fid4 = fopen('NortecData_100k_4.dat','rt');
a4 = textscan(fid4, '%f', 'HeaderLines',17);
a4 = a4{1} ;
fclose(fid4);

x4 = a4(363:2:end-321);

y4 = a4(364:2:end-321);

z4 = x4 + 1i*y4 ;

%%
%*************** 100k DATA FILE 5 ******************

fid5 = fopen('NortecData_100k_5.dat','rt');
a5 = textscan(fid5, '%f', 'HeaderLines',17);
a5 = a5{1} ;
fclose(fid5);

x5 = a5(363:2:end-321);

y5 = a5(364:2:end-321);

z5 = x5 + 1i*y5 ;

%%
%*************** 100k DATA FILE 6 ******************

fid6 = fopen('NortecData_100k_6.dat','rt');
a6 = textscan(fid6, '%f', 'HeaderLines',17);
a6 = a6{1} ;
fclose(fid6);

x6 = a6(363:2:end-321);

y6 = a6(364:2:end-321);

z6 = x6 + 1i*y6 ;

%%
%*************** 100k DATA FILE 7 ******************

fid7 = fopen('NortecData_100k_7.dat','rt');
a7 = textscan(fid7, '%f', 'HeaderLines',17);
a7 = a7{1} ;
fclose(fid7);

x7 = a7(363:2:end-321);

y7 = a7(364:2:end-321);

z7 = x7 + 1i*y7 ;

%%
%*************** 100k DATA FILE 8 ******************

fid8 = fopen('NortecData_100k_8.dat','rt');
a8 = textscan(fid8, '%f', 'HeaderLines',17);
a8 = a8{1} ;
fclose(fid8);

x8 = a8(363:2:end-321);

y8 = a8(364:2:end-321);

z8 = x8 + 1i*y8 ;

%%
%*************** 100k DATA FILE 9 ******************

fid9 = fopen('NortecData_100k_9.dat','rt');
a9 = textscan(fid9, '%f', 'HeaderLines',17);
a9 = a9{1} ;
fclose(fid9);

x9 = a9(363:2:end-321);

y9 = a9(364:2:end-321);

z9 = (x9 + 1i*y9);


%% Magnitudes

abs_z1=abs(z1);
abs_z2=abs(z2);
abs_z3=abs(z3);
abs_z4=abs(z4);
abs_z5=abs(z5);
abs_z6=abs(z6);
abs_z7=abs(z7);
abs_z8=abs(z8);
abs_z9=abs(z9);


%%
%***********************************************************************
%******************** Calculation of Caliberation Parameters***************************
%***********************************************************************

abs_mag= [abs_z1 abs_z2 abs_z3 abs_z4 abs_z5 abs_z6 abs_z7 abs_z8 abs_z9]; 

MaxMag = max(max(abs_mag));
[a, b] = find(abs_mag == MaxMag);
impedence_matrix= [z1 z2 z3 z4 z5 z6 z7 z8 z9];

Phs = 180/pi*angle(impedence_matrix(a(1),b(1))); % ans is in degree
Rot_Deg = (135 - Phs)/180*pi;
RotMat= [cos(Rot_Deg) -1*sin(Rot_Deg); sin(Rot_Deg) cos(Rot_Deg)];
ScalingFactor=(10/MaxMag);


    
x1y1= [x1 y1];
rot_x1y1= (x1y1*RotMat);
sc_rot_x1y1=rot_x1y1 * ScalingFactor;
cal_x1 = sc_rot_x1y1(:,[1]);
cal_y1 = sc_rot_x1y1(:,[2]);
newx1=cal_x1-(max(cal_x1))*(ones(size(cal_x1))); % Data Centering
newy1=cal_y1-(min(cal_y1))*(ones(size(cal_y1))); % Data Centering
imp1=newx1+ 1i*newy1;

x2y2= [x2 y2];
rot_x2y2= (x2y2*RotMat);
sc_rot_x2y2=rot_x2y2 * ScalingFactor;
cal_x2 = sc_rot_x2y2(:,[1]);
cal_y2 = sc_rot_x2y2(:,[2]);
newx2=cal_x2-(max(cal_x2))*(ones(size(cal_x2)));
newy2=cal_y2-(min(cal_y2))*(ones(size(cal_y2)));
imp2=newx2+ 1i*newy2;

x3y3= [x3 y3];
rot_x3y3= (x3y3*RotMat);
sc_rot_x3y3=rot_x3y3 * ScalingFactor;
cal_x3 = sc_rot_x3y3(:,[1]);
cal_y3 = sc_rot_x3y3(:,[2]);
newx3=cal_x3-(max(cal_x3))*(ones(size(cal_x3)));
newy3=cal_y3-(min(cal_y3))*(ones(size(cal_y3)));
imp3=newx3+ 1i*newy3;

x4y4= [x4 y4];
rot_x4y4= (x4y4*RotMat);
sc_rot_x4y4=rot_x4y4 * ScalingFactor;
cal_x4 = sc_rot_x4y4(:,[1]);
cal_y4 = sc_rot_x4y4(:,[2]);
newx4=cal_x4-(max(cal_x4))*(ones(size(cal_x4)));
newy4=cal_y4-(min(cal_y4))*(ones(size(cal_y4)));
imp4=newx4+ 1i*newy4;

x5y5= [x5 y5];
rot_x5y5= (x5y5*RotMat);
sc_rot_x5y5=rot_x5y5 * ScalingFactor;
cal_x5 = sc_rot_x5y5(:,[1]);
cal_y5 = sc_rot_x5y5(:,[2]);
newx5=cal_x5-(max(cal_x5))*(ones(size(cal_x5)));
newy5=cal_y5-(min(cal_y5))*(ones(size(cal_y5)));
imp5=newx5+ 1i*newy5;

x6y6= [x6 y6];
rot_x6y6= (x6y6*RotMat);
sc_rot_x6y6=rot_x6y6 * ScalingFactor;
cal_x6 = sc_rot_x6y6(:,[1]);
cal_y6 = sc_rot_x6y6(:,[2]);
newx6=cal_x6-(max(cal_x6))*(ones(size(cal_x6)));
newy6=cal_y6-(min(cal_y6))*(ones(size(cal_y6)));
imp6=newx6+ 1i*newy6;

x7y7= [x7 y7];
rot_x7y7= (x7y7*RotMat);
sc_rot_x7y7=rot_x7y7 * ScalingFactor;
cal_x7 = sc_rot_x7y7(:,[1]);
cal_y7 = sc_rot_x7y7(:,[2]);
newx7=cal_x7-(max(cal_x7))*(ones(size(cal_x7)));
newy7=cal_y7-(min(cal_y7))*(ones(size(cal_y7)));
imp7=newx7+ 1i*newy7;

x8y8= [x8 y8];
rot_x8y8= (x8y8*RotMat);
sc_rot_x8y8=rot_x8y8 * ScalingFactor;
cal_x8 = sc_rot_x8y8(:,[1]);
cal_y8 = sc_rot_x8y8(:,[2]);
newx8=cal_x8-(max(cal_x8))*(ones(size(cal_x8)));
newy8=cal_y8-(min(cal_y8))*(ones(size(cal_y8)));
imp8=newx8+ 1i*newy8;

x9y9= [x9 y9];
rot_x9y9= (x9y9*RotMat);
sc_rot_x9y9=rot_x9y9 * ScalingFactor;
cal_x9 = sc_rot_x9y9(:,[1]);
cal_y9 = sc_rot_x9y9(:,[2]);
newx9=cal_x9-(max(cal_x9))*(ones(size(cal_x9)));
newy9=cal_y9-(min(cal_y9))*(ones(size(cal_y9)));
imp9=newx9+ 1i*newy9;
calibrated_data.outim_100k = [ newy1 newy2 newy3 newy4 newy5 newy6 newy7 newy8 newy9]';
calibrated_data.outre_100k = [ newx1 newx2 newx3 newx4 newx5 newx6 newx7 newx8 newx9]';









%% Feature Extraction

    s_bit=1;
    num_boxes=size(roiboxes,1);
    
     for n=1:num_boxes
        %------------------Extract ROI Data-----------------------------------%

interest_data.outim_200k = calibrated_data.outim_200k(roiboxes(n,1):roiboxes(n,2), roiboxes(n,3):roiboxes(n,4));
interest_data.outre_200k = calibrated_data.outre_200k(roiboxes(n,1):roiboxes(n,2), roiboxes(n,3):roiboxes(n,4));
interest_data.outim_100k = calibrated_data.outim_100k(roiboxes(n,1):roiboxes(n,2), roiboxes(n,3):roiboxes(n,4));
interest_data.outre_100k = calibrated_data.outre_100k(roiboxes(n,1):roiboxes(n,2), roiboxes(n,3):roiboxes(n,4));

%%............Field # 1.................

Feature_Extracted_Boxes(n).roi = roiboxes(n,:);


%.............Feature: Max Vert Axial First Channel.................%


Feature_Extracted_Boxes(n).A200_maxVert = max(max(interest_data.outim_200k));

%..............Feature: Max Mag Axial First Channel................%
        Feature_Extracted_Boxes(n).A200_maxMag = ...
max(max(abs((interest_data.outre_200k) + sqrt(-1)*interest_data.outim_200k))); 

    
            % Location of Maximum Vertical Component.
            [a b] = find(interest_data.outim_200k == Feature_Extracted_Boxes(n).A200_maxVert);

%-----------Relative Row Column Values[Considering the entire Image]------------------------%
            row = roiboxes(n,1)+a(1)-1; %Check OK
            col = roiboxes(n,3)+b(1)-1; %Check OK
%-------------------------------------------------------------%

%------------Phase at MAX VERT Computation-------------------------%

ph_first = angle(interest_data.outre_200k(a(1),b(1))+sqrt(-1)*interest_data.outim_200k(a(1),b(1)));
ph_second = angle(interest_data.outre_100k(a(1),b(1))+sqrt(-1)*interest_data.outim_100k(a(1),b(1)));

 %---------------Phase Conversion to ASME Std--------------------------%
 
  Feature_Extracted_Boxes(n).A200_PhsMxVert = floor(180-ph_first*180/pi); 
  Feature_Extracted_Boxes(n).A100_PhsMxVert = floor(180-ph_second*180/pi);

   
     end

     %% Classification 
% features = classification(features, params)

features= Feature_Extracted_Boxes;

     
     for i=1:length(features);
    isDefect = '';
    if(features(i).A200_maxVert >= 0.08) 
        %if( (features(i).A300_PhsMxVert  > params.A300_PhsMxVert_low) && (features(i).A300_PhsMxVert  < params.A300_PhsMxVert_high))
            if( (features(i).A200_PhsMxVert  > 20) && (features(i).A200_PhsMxVert  < 140))                              % values taken from SPfiles Arkanas
                if( (features(i).A100_PhsMxVert  > 0) && (features(i).A100_PhsMxVert  < 130))                        % values taken from SPfiles Arkanas
                    %if(CL_OD == 1)  % what is CL_OD?                                                                         % values taken from SPfiles Arkanas
                        %if((features(i).A300_PhsMxVert - features(i).A200_PhsMxVert) > params.A300_200)                      
                             if((features(i).A200_PhsMxVert - features(i).A100_PhsMxVert) >= -5)  %% values taken from SPfiles Arkanas 
                                 isDefect = 'A';
                            end
                        %end
                    %end
                    %if( (params.CL_OD == 0) || (params.CL_OD == 2) )
                        %if((features(i).A100_PhsMxVert - features(i).A200_PhsMxVert) > params.A100_200)
                            %if((features(i).A200_PhsMxVert - features(i).A300_PhsMxVert) >= params.A200_300)
                                %isDefect = 'A';
                            %end                        
                        %end
                    %end
                end
            end
        %end
    end
  
    
    isDefect = [isDefect];
    if(strcmp(isDefect,'A'))
        isDefect = 'DEFECT';
    %elseif(strcmp(isDefect,'C'))
        %isDefect = 'SCI';
    %elseif(strcmp(isDefect, 'AC'))
        %isDefect = 'VOL';
    else 
        isDefect = 'NO DEFECT';
    end 
    features(i).isDefect = isDefect;
end

%% Report Generation Module
% function report = generateReport(FileName, features, mizheader, StructureDetails, interpMtx, loc_info)

% Open File for Reporting Important Parameters
fid = fopen('ET_Report.txt','w');
if (fid == -1), error('File not opened!'); end
fprintf(fid,'::Eddy Current Test Report::\r\n\r\n\r\n');
fprintf(fid,'Engineers: Taufeeq Ahmed, Moez-ul-Hasan, Taha Ali\r\n');
fprintf(fid,'Date: %s\r\n\r\n',date);

    
fprintf(fid,'Number of ROIs: %d\r\n\r\n',length(features));
fprintf(fid,'ROI# \tROI Locations \tFeatures \tValue \tDecision\r\n\r\n');

for k=1:length(features)

fprintf(fid,'%d \t%ld \t\t\t%s \t%f \t%s\r\n',k,features(k).roi(1,1),'MaxVert', ...
features(k).A200_maxVert,features(k).isDefect);

fprintf(fid,'\t%ld \t\t\t%s \t%f\r\n',features(k).roi(1,2),'MaxMag', ...
features(k).A200_maxMag);

fprintf(fid,'\t%ld \t\t\t%s \t%f\r\n',features(k).roi(1,3),'Phs_High', ...
features(k).A200_PhsMxVert);

fprintf(fid,'\t%ld \t\t\t%s \t%f\r\n',features(k).roi(1,4),'Phs_Low', ...
features(k).A100_PhsMxVert);

fprintf(fid,'\r\n');
end

fprintf(fid,'::End of Report::');
fclose(fid);


% % Writing the report
% [nrows,ncols] = size(report);
% for row = 1:nrows
%     fprintf(fid, '%s %s %s %s\n', num2str(report{row,:}));
% end


% table_row = 3;  
%     
% report{1,1} ='Number of ROIs';
% report{1,2} = length(features);
% 
% for k=1:length(features)
% 
% report{table_row,1} = k ;
% report{table_row,2}='Features';
% report{table_row,3}='Features Value'
% report{table_row,4} = 'Decision';
% 
% table_row = table_row +1;
% 
% report{table_row,1} = features(k).roi(1,1);
% report{table_row,2}='MaxVert';
% report{table_row,3}=features(k).A200_maxVert;
% report{table_row,4}= features(k).isDefect;
% 
% table_row = table_row +1;
% 
% report{table_row,1} = features(k).roi(1,2);
% report{table_row,2}='MaxMag';
% report{table_row,3}=features(k).A200_maxMag;
% 
% table_row = table_row +1;
% 
% report{table_row,1} = features(k).roi(1,3);
% report{table_row,2}='Phs_200';
% report{table_row,3}=features(k).A200_PhsMxVert;
% 
% table_row = table_row +1;
% 
% report{table_row,1} = features(k).roi(1,4);
% report{table_row,2}='Phs_100';
% report{table_row,3}=features(k).A100_PhsMxVert;
% 
% table_row = table_row +2;
% end



   
  





    
