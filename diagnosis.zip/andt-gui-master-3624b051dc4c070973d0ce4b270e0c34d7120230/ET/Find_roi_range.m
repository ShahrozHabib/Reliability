function outrow = Find_roi_range(in_image)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  This function is used to find defect range in input image.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[nrow ncol]=size(in_image);

enin_image = zeros(nrow+2,ncol);   %zero pading on border
enin_image(2:nrow+1,:) = in_image;

srow1 = sum(enin_image')';

irow1 = im2bw(srow1);

drow1 = find(abs(diff(double(irow1))) > 0 );
outrow = reshape(drow1,2,size(drow1,1)/2)';
outrow(:,2) = outrow(:,2)-1;
