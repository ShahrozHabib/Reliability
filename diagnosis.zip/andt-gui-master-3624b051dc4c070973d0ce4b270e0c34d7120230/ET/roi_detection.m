function [ roiboxes ] = roi_detection( clean_binimg )
% This is the 6th function. It is used to determine the corners of the ROI boxes using
% the input binary image.It includes two functions namely Find_roi_range,
% which determines the range of ROIs in terms of rows and ROI_detmain,
% which determines the column and rows of ROIs


try

roiboxes=[];
    
    corbox1=Roi_detmain(clean_binimg,0,0);      
    corbox2=[];
 
     nbox1 = size(corbox1,1);
 
    for k = 1:nbox1
        imagek = clean_binimg(corbox1(k,1):corbox1(k,2),corbox1(k,3):corbox1(k,4));
        cboxk = Roi_detmain(imagek,corbox1(k,1)-1,corbox1(k,3)-1);
        corbox2 = [corbox2;cboxk];
    end
 
    nbox2 = size(corbox2,1);
 
    roiboxes = corbox2;        
    
    s_bit=1;
catch
    roiboxes=[];
    s_bit=0;
end

pixsum = [];
for i = 1:size(roiboxes,1)
    pixelnum = sum(sum(clean_binimg(roiboxes(i,1):roiboxes(i,2),roiboxes(i,3):roiboxes(i,4))));
    pixsum = [pixsum;pixelnum];
end

indix = find(pixsum<=6);
roiboxes(indix,:)=[];




end

