

clc;
close all;
clear all;

%% Data Extraction and Format Analysis from 200KHz Signal

current_path = path;    % store current path
data_path='C:\Users\Salar\Desktop\ANDT_GUI-20140310\ET\Data_files\200k\*.dat';
path (path,'C:\Users\Salar\Desktop\ANDT_GUI-20140310\ET\Data_files\200k\');  % append given data path to MATLAB search path temporarily

[impedence, impedence_mag, Real_Component, Imaginary_Component] = extract_data(data_path);

path (current_path);    % restore current path


%% Data Calibration of 200KHz Signal

[ calibrate_impedence,imaginary_part,real_part] =calibrate( impedence,impedence_mag,Real_Component,Imaginary_Component);
calibrated_data.outim_200k=imaginary_part;
calibrated_data.outre_200k=real_part;

 
%%  Pre processing Land Mark Elimination 

[ lme_data] = land_mark_elimination( calibrate_impedence );

%% Adaptive_Thresholding
    
[ adaptive_thresholding_image ] = Adaptive_Thresholding( lme_data );
   
   
  
%% Morphological Operation
    
  
[ clean_binimg ] = morph_ops( adaptive_thresholding_image );

%% Region Of Interst Detection


[ roiboxes ] = roi_detection( clean_binimg);


%% Data Extraction and Format Analysis from 100KHz Signal

current_path = path;    % store current path
data_path='C:\Users\Salar\Desktop\ANDT_GUI-20140310\ET\Data_files\200k\*.dat';
path (path,'C:\Users\Salar\Desktop\ANDT_GUI-20140310\ET\Data_files\200k\');  % append given data path to MATLAB search path temporarily

[impedence, impedence_mag, Real_Component, Imaginary_Component] = extract_data(data_path);

path (current_path);    % restore current path

%% Data Calibration of 100KHz Signal

[ calibrate_impedence,imaginary_part,real_part] =calibrate( impedence,impedence_mag,Real_Component,Imaginary_Component);
calibrated_data.outim_100k=imaginary_part;
calibrated_data.outre_100k=real_part;


%% Feature Extraction

[ Feature_Extracted_Boxes ] = feature_extraction( roiboxes,calibrated_data );

%% Classification

 
[ features ] = classification( Feature_Extracted_Boxes );

%% Report Generation


% Open File for Reporting Important Parameters
fid = fopen('ET_Report.txt','w');
if (fid == -1), error('File not opened!'); end
fprintf(fid,'::Eddy Current Test Report::\r\n\r\n\r\n');
fprintf(fid,'Engineers: Taufeeq Ahmed, Moez-ul-Hasan, Taha Ali\r\n');
fprintf(fid,'Date: %s\r\n\r\n',date);

    
fprintf(fid,'Number of ROIs: %d\r\n\r\n',length(features));
fprintf(fid,'ROI# \tROI Locations \tFeatures \tValue \tDecision\r\n\r\n');

for k=1:length(features)

fprintf(fid,'%d \t%ld \t\t\t%s \t%f \t%s\r\n',k,features(k).roi(1,1),'MaxVert', ...
features(k).A200_maxVert,features(k).isDefect);

fprintf(fid,'\t%ld \t\t\t%s \t%f\r\n',features(k).roi(1,2),'MaxMag', ...
features(k).A200_maxMag);

fprintf(fid,'\t%ld \t\t\t%s \t%f\r\n',features(k).roi(1,3),'Phs_200', ...
features(k).A200_PhsMxVert);

fprintf(fid,'\t%ld \t\t\t%s \t%f\r\n',features(k).roi(1,4),'Phs_100', ...
features(k).A100_PhsMxVert);

fprintf(fid,'\r\n');
end

fprintf(fid,'::End of Report::');
fclose(fid);







   
  





    
