function UT_Spctstft(A,D, varargin)

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
    
    axis on;     
else
    % disp_h = 1; 
end

tt=2*D/5926e3;

w=window(@rectwin,6); % window size to be used for STFT
% figure ;
    
k=4;
fr=0:10e6/256:10e6-1;
[y,f,t,p] = spectrogram(A(:,k),w,4,256,10e6);
subplot(2,2,1)
 surf(t,f,abs(p),'edgecolor','none');
 axis tight 
view (180,90)
xlabel('Time (sec)'); %%Label added
ylabel('Frequency (Hz)'); %%Label added
% pause
% clf
Bm=A(:,k);
C=[15 18 21 24 27]; %%What is 'C'? Why is it hard coded?
subplot(2,2,2)
plot(tt,A(:,k))
title(['A-Scan location   ',num2str(k),''])
grid on
xlabel('Time');
ylabel('Amplitude');
text(t(C),t(C),'O','color','red');
    tm=(t(:,C(2)));
    dc=tm*5926/2;
% subplot(2,2,3);
% [y,f,t,p] = spectrogram(A(:,k),w,4,256,15e6);
%      surf(t,f,10*abs(p),'edgecolor','red');
%      axis tight 
%      view (-90,0)
% xlabel('time (sec)');
% ylabel('Frequency (Hz)');
subplot(2,2,4);
plot(f,p(:,C(2)));
ylabel('Amplitude');
xlabel('Frequency (Hz)');
title(['Time = ',num2str(tm),'sec'])
legend(['Distance = ',num2str(dc),'m'])
grid on
end

% for k=1:length(A(1,:))
%     
% fr=0:10e6/256:10e6-1;
% [y,f,t,p] = spectrogram(A(:,k),w,4,256,10e6);
%  surf(t,f,abs(p),'edgecolor','none');
%  axis tight 
% view (180,90)
% pause
% clf
% Bm=A(:,k);
% C=[15 18 21 24 27];
% subplot(2,3,1)
% plot(tt,A(:,k))
% title(['A-Scan location   ',num2str(k),''])
% grid on
% xlabel('Time');
% ylabel('Amplitude');
% text(t(C),t(C),'O','color','red')
%  for px=1:2
%     tm=(t(:,C(px)));
%     dc=tm*5926/2;
% subplot(2,3,px+1)
% [y,f,t,p] = spectrogram(A(:,k),w,4,256,15e6);
%      surf(t,f,10*abs(p),'edgecolor','red');
%      axis tight 
%      view (-90,0)
% xlabel('time (sec)');
% ylabel('Frequency (Hz)');
% plot(f,p(:,C(px)))
% ylabel('Amplitude');
% xlabel('Frequency (Hz)');
% title(['Time = ',num2str(tm),'sec'])
% legend(['Distance = ',num2str(dc),'m'])
% grid on
%  end
%  pause
% end
%  pause
% end

