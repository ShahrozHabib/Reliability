 function [M_c] = UT_CScan(A , D , varargin)

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
    axis on;
    if (optargin==5)
        R=varargin{2};
        C=varargin{3};
        cmap=varargin{4};
        P=varargin{5};
    else if (optargin == 4)
        R = varargin{2};
        C = varargin{3};
        cmap = varargin{4};
        P=1; %default case
    elseif (optargin == 3)
        R = varargin{2};
        C = varargin{3};
        cmap = flipud(colormap); % Set Inverted Colormap as default
        P = 1;
    else 
        R = 1;
        C = 1;
        cmap = flipud(colormap); % Set Inverted Colormap as default
        P = 1;
    end
%else
    % disp_h = 1; 
end

M = zeros (R,C); % Initialize Cscan matrix for requisite no. of Rows and Coloumns

%condition for plotting
if (P==1)
    subplot(1,1,1)
end

for k=1:length(A(1,:))
[X,Y]=findpeaks(A(:,k),'npeaks',11);
    %[X1,Y1]=findpeaks(Amp,'sortstr','ascend')
    D1=D(Y);
    %D2=D(Y1);
    
%     F=[X D1']; % Version dependent code: Works for R2013a
%     F=[X' D1']; % Version dependent code: Works for R2010a
    for p=1:11
%         if F(p,2)>6 && F(p,1)>15 % Version dependent code
        if D1(p)>6 && X(p)>15 % Version Independent code
%             M(k)=F(p,2); % Version dependent code
           M(k)= D1(p); % Version Independent code
            break
        end
    end

end
%%figure 

M_c = M';
% M_c = imcomplement (M');

%condition for plot
if (P==1)

    imagesc(M_c);
    colormap(cmap);
    xlabel ('Distance / Horizontal Locations');
    ylabel('Distance / Vertical Locations');
    title('C-Scan Plot / Top View');
    colorbar; 
end

end

