function UT_AScan(Amp,Dist, varargin)

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
    axis on;
    if (optargin == 2)
        k = varargin{2}; % Get Location Number
    else
        k = 1;
    end
else
    % disp_h = 1; 
end

    %figure
    %subplot(disp_h);
    %for k=1:4
    subplot(1,1,1);
    Amp_n = Amp(:,k)./max(Amp(:,k)); % Normalized Amplitude
%     plot(Dist, Amp(:,k))
    plot(Dist, Amp_n);
    grid on;
    title(['Amplitude Scan for Location # ' num2str(k)]);
    xlabel('Depth in mm');
    ylabel('Normalized Amplitude');
   
%     subplot(2,2,2);
%     plot(Dist, Amp(:,2))
%     grid on;
%     title('Amplitude Scan')
%     xlabel('Depth in mm')
%     ylabel('Amplitude')
%     
%     subplot(2,2,3);
%     plot(Dist, Amp(:,3))
%     grid on;
%     title('Amplitude Scan')
%     xlabel('Depth in mm')
%     ylabel('Amplitude')
%     
%     subplot(2,2,4);
%     plot(Dist, Amp(:,4))
%     grid on;
%     title('Amplitude Scan')
%     xlabel('Depth in mm')
%     ylabel('Amplitude')
end
% % Points for Max-Min and Zero Crossing
% x=A(:,5);
% figure; plot(x); set(gca,'xtick',0:numel(x)+2); ylim([0 210])
% [iP,iT,iC] = findextrema(x);
% hold on; plot(iP,x(iP),'r*'); plot(iT,x(iT),'g*'); plot(iC,x(iC),'ks');
% legend({'Data','Peak','Trough','Zero-Crossing'},'location','NorthEast');0