function [ adaptive_thresholding_image ] = ET_Adaptive_Thresholding( calibrate_impedence,varargin )

% This is the 4th function. Input is the land mark eliminated data and output
% is the binary image after adaptive thresholding


% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;


if (optargin==3)
        cmap = varargin{3};
        disp_h = varargin{1};
        axes (disp_h);
        axis on; 
           sel = varargin{2};  % check selection from GUI
        if sel
            disp_at = 1;
            disp_hist = 0;
        else
            disp_at = 0;
            disp_hist = 1;
        end
elseif (optargin == 2)         % if optional arguments present          
        sel = varargin{2};  % check selection from GUI
        if sel
            disp_at = 1;
            disp_hist = 0;
        else
            disp_at = 0;
            disp_hist = 1;
        end
        cmap = colormap;
        disp_h = varargin{1};
        axes (disp_h);
        axis on;
elseif (optargin==1)
    cmap = colormap;
    disp_h = varargin{1};
    axes (disp_h);
    axis on;
    disp_at = 1;
    disp_hist = 1;
else
    cmap = colormap;
    %disp_h = varargin{1};
    axes (disp_h);
    axis on;
    disp_at = 1;
    disp_hist = 1;    
end

number_bins=100;
    elim_percent=0.1
    im2d=calibrate_impedence;
   
    Numrow=size(im2d,1);
    Numcol=size(im2d,2);
    bin_img=zeros(size(im2d));
    % 2D to 1D conversion before histogram thresholding.
    im2dnew=im2d';
    im1d=im2dnew(:);
   
    %-------------------------------------------------------------------------%
    length1d=size(im1d,1);
    N=length1d;
    nbin=number_bins;
    x=im1d;
    %------There is median removal before thresholding------------------------%
%    mn=median(x);
 %   x=x-mn;
    %-------------------------------------------------------------------------%
    [P,Q] = hist(x,nbin);
       
    %% Only for plotting use 100 bins
    [hdist, hcent]=hist(x,100);
    
    if disp_hist
%         figure(8)
        colorbar('off');
        hist(x,100,'FaceColor','k');
%         colormap(cmap);
        hist_obj_h = findobj(gca,'Type','patch'); 
        set(hist_obj_h,'FaceColor','b','EdgeColor','w');
        axis auto;
        axis normal;
        title('Histogram of Calibrated Magnitude','FontSize', 11)
        xlabel('Voltage (V)','FontSize', 11);
        ylabel('Frequency','FontSize', 11);
%         set(gca,'YGrid','on');
    end
    
    
    
    
    for pp=1:nbin
        P_acc(pp)=sum(P(1:pp));
    end;
    P_acc=P_acc/N;
     
        
    index_thresh=min(find(P_acc>=elim_percent));
  
    thresh_return=abs(Q(index_thresh));
    
%     
    index=1;
    %Thresholding------------------
    for index=1:length1d
%    if(im1d(index)<thresh_return) 
     if(im1d(index)>thresh_return) % lu
        
         im1d(index)=1;
        else
            im1d(index)=0;
     end

    end
    index=1;
    % 1D to 2D conversion to reshape the thresholded output into the required
    % format
    bin_img=reshape(im1d,[Numcol,Numrow])';
    bin_img=imcomplement(bin_img);
    
    if disp_at
%         figure(9)
        imagesc(bin_img);
        colormap(cmap);
        axis auto;
        axis normal;
        title('Scaled image plot of Magnitude','FontSize', 11);
        xlabel('Indices','FontSize', 11)
        ylabel('Rows','FontSize', 11);
        h=colorbar;
        xlabel(h,'Voltage','FontSize', 11);
    end
adaptive_thresholding_image=bin_img;  
    %


end

