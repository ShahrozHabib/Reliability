function varargout = ANDT_GUI_TA_Sel(varargin)
% ANDT_GUI_TA_SEL M-file for ANDT_GUI_TA_Sel.fig
%      ANDT_GUI_TA_SEL, by itself, creates a new ANDT_GUI_TA_SEL or raises the existing
%      singleton*.
%
%      H = ANDT_GUI_TA_SEL returns the handle to a new ANDT_GUI_TA_SEL or the handle to
%      the existing singleton*.
%
%      ANDT_GUI_TA_SEL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANDT_GUI_TA_SEL.M with the given input arguments.
%
%      ANDT_GUI_TA_SEL('Property','Value',...) creates a new ANDT_GUI_TA_SEL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ANDT_GUI_TA_Sel_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ANDT_GUI_TA_Sel_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ANDT_GUI_TA_Sel

% Last Modified by GUIDE v2.5 28-Jun-2014 04:42:05

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ANDT_GUI_TA_Sel_OpeningFcn, ...
                   'gui_OutputFcn',  @ANDT_GUI_TA_Sel_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ANDT_GUI_TA_Sel is made visible.
function ANDT_GUI_TA_Sel_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ANDT_GUI_TA_Sel (see VARARGIN)

% Display backgrounds
set (hObject,'CurrentAxes',handles.backgr);
imshow ('backgr.bmp');
axis(handles.backgr,'normal');

% Choose default command line output for ANDT_GUI_TA_Sel
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
end

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ANDT_GUI_TA_Sel wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% Set window Title
set (hObject,'Name','Aerospace NDT GUI - Target Area Selection');


% --- Outputs from this function are returned to the command line.
function varargout = ANDT_GUI_TA_Sel_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in ta_fuselage_btn.
function ta_fuselage_btn_Callback(hObject, eventdata, handles)
% hObject    handle to ta_fuselage_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.igc.ta_sel = 'Fuselage';
ANDT_GUI_M_Sel (handles.igc);

% --- Executes on button press in ta_wings_btn.
function ta_wings_btn_Callback(hObject, eventdata, handles)
% hObject    handle to ta_wings_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.igc.ta_sel = 'Wings';
ANDT_GUI_M_Sel (handles.igc);

% --- Executes on button press in ta_landinggears_btn.
function ta_landinggears_btn_Callback(hObject, eventdata, handles)
% hObject    handle to ta_landinggears_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.igc.ta_sel = 'Landing Gears';
ANDT_GUI_M_Sel (handles.igc);


% --- Executes during object creation, after setting all properties.
function backgr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to backgr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate backgr


% --- Executes on button press in Back_btn.
function Back_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Back_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ANDT_GUI_WEL (handles.igc);
