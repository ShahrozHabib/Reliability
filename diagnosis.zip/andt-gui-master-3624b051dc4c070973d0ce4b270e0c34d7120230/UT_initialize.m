function [A,D] = UT_initialize(data_path,varargin)
%--------------------------------------------------------------------------------------------

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
%     axes (disp_h);
    axis on;      
else
    % disp_h = 1; 
end

D=0:50/255:50-(50/255);
% Extract all files sequencially
nm=dir(data_path);
for i=1:length(nm);
    newdata=importdata(nm(i).name,' ', 5);
    vars=fieldnames(newdata);
    A(:,i)=newdata.(vars{1});
    clear newdata
    clear vars
end






