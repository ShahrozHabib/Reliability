function [RotMat, Scaling_Factor,data_cen_x,data_cen_y] = ET_genCalibparams( impedence_mag, Real_Component, Imaginary_Component, varargin )
% This function generates two calibration parameters from Maximum Magnitude
% and Rotation Matrix. The input for this function is the data file from
% calibration standard. 

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
    axes (disp_h);
    axis on;      
else
    % disp_h = 1; 
end

x=Real_Component;
y=Imaginary_Component;
MaxMag = max(max(impedence_mag));
[a, b] = find(impedence_mag == MaxMag);
Max_Real = Real_Component(a(1));
Max_Im = Imaginary_Component(a(1));
Phs = (atan((Max_Im/Max_Real)))*180/pi; % Phase is in degrees
Rot_Deg = (135 - Phs)/180*pi;% setting 135 degree as signal phase for 1mm (deepest) notch
Scaling_Factor = (10/MaxMag);% setting 10V as signal value for 1mm (deepest) notch
RotMat= [cos(Rot_Deg) -1*sin(Rot_Deg); sin(Rot_Deg) cos(Rot_Deg)];
xy= [x y];

rot_xy= (xy*RotMat);
sc_rot_xy=rot_xy;

sc_rot_x = sc_rot_xy(:,[1]);
sc_rot_y = sc_rot_xy(:,[2]);



%% data Centering

data_cen_x=max(sc_rot_x);
data_cen_y=min(sc_rot_y);
end

