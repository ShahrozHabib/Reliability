for k=1:4

subplot(1,2,1)    
[y,f,t,p] = spectrogram(A(:,k),w,3,256,10e6);
surf(t,f,abs(p),'edgecolor','none');
axis tight 
%view (180,90)
pause
% clf

[cx cy]=ginput(1);
tmp = abs(t'-cx);
[idx idy] = min(tmp); %index of closest value

tm=(t(:,idy));
dc=tm*5926/2;

% C=[9 12 15 19 24];
subplot(2,2,2)
plot(tt,A(:,k))
text(cx,0,'O','color','red')
title(['A-Scan location   ',num2str(k),''])
legend(['Distance = ',num2str(cx*5926*0.5),'m'])
grid on
xlabel('Time');
ylabel('Amplitude');


subplot(2,2,4)
plot(f,p(:,idy))

ylabel('Amplitude');
xlabel('Frequency (Hz)');

title(['Time = ',num2str(tm),'sec'])
legend(['Distance = ',num2str(dc),'m'])
grid on
pause
 end