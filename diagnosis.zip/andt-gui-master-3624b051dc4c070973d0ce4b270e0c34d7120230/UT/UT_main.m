%%
current_path = path;    % store current path
path (path, 'C:\Users\Salar\Desktop\ANDT_GUI-20140310\MNK UT\Data_files\*.dat'); % append given data path to MATLAB search path temporarily

[A,D]=main('C:\Users\Salar\Desktop\ANDT_GUI-20140310\MNK UT\Data_files\*.dat');

path (current_path);    % restore current path

%%
AScan(A,D)

%%
Cscan( A,D )

%%
spctstft(A,D)

%%
emdn(A,D)

%%
[VB]=hlhut(A)