for k=1:5
fr=0:10e6/256:10e6-1;
F=fft(A(:,k),256);
%subplot(5,5,k)
plot(fr,fftshift(abs(F)))
%plot(tt,A(:,k))
pause
end