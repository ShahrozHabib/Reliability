function [ Enrgy ] = hlhut(A)

for k=1:4
    imf=emd((A(:,k)));
    [aaa,fff,ttf] = hhspectrum(imf);
    [im,ttt] = toimage(aaa,fff);
    subplot(2,2,k)
    disp_hhs(im)
    colormap(bone)
    colormap(1-colormap)
    axis([6 10 0.06 0.15])
    colorbar
    
    load('temp.mat', 'im')
      for i=1
         % n=i*5-4;
      Ft=cumsum(im(6:15,30:51)'); % distance from 6 mm till 10 mm 
      %Ft=cumsum(im');
      Tf=Ft';
      sd=size(Ft);
      Cd=Tf(:,sd(1)); % length of Tf in case of old one 
      VB(i,k)=mean(Cd);
      end
 % for normalized values
 
      V=cumsum(VB);
      V1=V(length(V),:);
      for o=1:length(V1)
          Q(:,o)=VB(:,o)/V1(o);
      end
     
end

Enrgy=Q;

end

