function emdn(A,D)

% This function calculates the emds of the given input A-Scans and Time or
% Distance Value

for k=1:length(A(1,:))

rslt=eemd(A(:,k),0,1);
subplot(4,2,1)
plot(D,rslt(:,1))
title('Time Domain Data')
xlabel('Distance')
subplot(4,2,2)
plot(D,rslt(:,2));
title('1st IMF')
subplot(4,2,3)
plot(D,rslt(:,3));
title('2nd IMF')
subplot(4,2,4)
plot(D,rslt(:,4));
title('3rd IMF')
subplot(4,2,5)
plot(D,rslt(:,5));
title('4th IMF')
subplot(4,2,6)
plot(D,rslt(:,6));
title('5th IMF')
subplot(4,2,7)
plot(D,rslt(:,7));
title('6th IMF')
subplot(4,2,8)
plot(D,rslt(:,8));
title ('Monotonic Component')
%plot(D,sum(rslt(:,6:8),2)-1.3,'r-');
hold off
set(gca,'yTickLabel',[]);
%axis([1850 2010 -1.8 0.3]);
xlabel('Distance');
pause
end
end

