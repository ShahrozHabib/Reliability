function spctstft(A,D)

tt=2*D/5926e3;

w=window(@rectwin,6); % window size to be used for STFT
figure ;

for k=1:length(A(1,:))
    
fr=0:10e6/256:10e6-1;
[y,f,t,p] = spectrogram(A(:,k),w,4,256,10e6);
 surf(t,f,abs(p),'edgecolor','none');
 axis tight 
% view (180,90)
% pause
% clf
Bm=A(:,k);
C=[15 18 21 24 27];
subplot(2,3,1)
plot(tt,A(:,k))
title(['A-Scan location   ',num2str(k),''])
grid on
xlabel('Time');
ylabel('Amplitude');
text(t(C),t(C),'O','color','red')
 for px=1:5
    tm=(t(:,C(px)));
    dc=tm*5926/2;
subplot(2,3,px+1)
[y,f,t,p] = spectrogram(A(:,k),w,4,256,15e6);
     surf(t,f,10*abs(p),'edgecolor','red');
     axis tight 
     view (-90,0)
xlabel('time (sec)');
ylabel('Frequency (Hz)');
plot(f,p(:,C(px)))
ylabel('Amplitude');
xlabel('Frequency (Hz)');
title(['Time = ',num2str(tm),'sec'])
legend(['Distance = ',num2str(dc),'m'])
grid on
 end
 pause
end
 pause
end

