function [Amp,Dis] = main(path)
%--------------------------------------------------------------------------------------------
Dis=0:50/255:50-(50/255);
% Extract all files sequencially
nm=dir(path);
for i=1:length(nm);
    newdata=importdata(nm(i).name,' ', 5);
    vars=fieldnames(newdata);
    Amp(:,i)=newdata.(vars{1});
    clear newdata
    clear vars
end






