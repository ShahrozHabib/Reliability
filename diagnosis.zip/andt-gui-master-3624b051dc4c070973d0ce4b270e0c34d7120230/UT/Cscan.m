function Cscan(A , D)

for k=1:length(A(1,:))
[X,Y]=findpeaks(A(:,k),'npeaks',11);
    %[X1,Y1]=findpeaks(Amp,'sortstr','ascend')
    D1=D(Y);
    %D2=D(Y1);
    F=[X D1'];
    for p=1:11
        if F(p,2)>6 && F(p,1)>15
        M(k)=F(p,2);
        break
    end
    end

end
figure 
imagesc(M)
xlabel ('Distance')
ylabel('Distance / Location')
title('C-Scan Plot')
   colorbar 



end

