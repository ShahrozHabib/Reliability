function AScan(A,D)
figure
for k=1:4
   subplot(2,2,k);
   plot(D,A(:,k))
   grid
   title('Amplitude Scan')
   xlabel('Depth in mm')
   ylabel('Amplitude')
end
end
% % Points for Max-Min and Zero Crossing
% x=A(:,5);
% figure; plot(x); set(gca,'xtick',0:numel(x)+2); ylim([0 210])
% [iP,iT,iC] = findextrema(x);
% hold on; plot(iP,x(iP),'r*'); plot(iT,x(iT),'g*'); plot(iC,x(iC),'ks');
% legend({'Data','Peak','Trough','Zero-Crossing'},'location','NorthEast');