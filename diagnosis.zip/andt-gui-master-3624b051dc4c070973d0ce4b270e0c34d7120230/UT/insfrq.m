function [ output_args ] = Untitled4( input_args )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

year=D;
for k=1:lenght(nm)
rslt=eemd(A(:,k),0,1);
    for l=1:3
   
omega_m3=ifndq(rslt(:,l+1),1);
subplot(2,1,1);
X(:,l)=abs(omega_m3);
plot(year,rslt(:,l+1));
%axis([1850 2010 -0.12 0.12]); 
title('IMF ');
%ylabel('Kelvin');
grid;
subplot(2,1,2);
plot(year, omega_m3/2/pi,'r-');
grid;
xlabel('Depth');
ylabel('Frequency');
title('instantaneous frequency');
%axis([1850 2010 0 0.12]);
pause
    end
end

end

