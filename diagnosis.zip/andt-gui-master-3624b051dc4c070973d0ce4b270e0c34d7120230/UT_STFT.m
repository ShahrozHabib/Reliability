function  UT_STFT(A,D, varargin)

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
    if (optargin == 5)
        cx = varargin{2};
        cy = varargin{3};
        k = varargin{4};
        cmap = varargin{5};
    elseif (optargin == 4)
        cx = varargin{2};
        cy = varargin{3};
        k = varargin{4};
        cmap = colormap; % Keep default colormap by default
    elseif (optargin == 3)
        cx = varargin{2};
        cy = varargin{3};
        k = 1;
        cmap = colormap; % Keep default colormap by default
    else 
        cx = 0;
        cy = 0;
        k = 1;
        cmap = colormap; % Keep default colormap by default
    end
    axis on;     
else
    % disp_h = 1; 
end

% for k=1:4

tt=2*D/5926e3;

w=window(@rectwin,6); % window size to be used for STFT
% figure ;


subplot(1,2,1);    
[y,f,t,p] = spectrogram(A(:,k),w,3,256,10e6);
colormap(cmap);
surf(t,f,abs(p),'edgecolor','none');
axis tight 
view (180,90)
title(['STFT for Location # ' num2str(k)]);
% pause
% clf

% [cx cy]=ginput(1);
tmp = abs(t'-cx);
[idx idy] = min(tmp); %index of closest value

tm=(t(:,idy));
dc=tm*5926/2;

% C=[9 12 15 19 24];
subplot(2,2,2);
plot(tt,A(:,k));
text(cx,0,'O','color','red')
title(['A-Scan for Location # ' num2str(k)]);
legend(['Distance = ',num2str(cx*5926*0.5),'m'])
grid on;
xlabel('Time');
ylabel('Amplitude');


subplot(2,2,4);
plot(f,p(:,idy));

ylabel('Amplitude');
xlabel('Frequency (Hz)');

title(['At Time = ',num2str(tm),'sec']);
legend(['Distance = ',num2str(dc),'m']);
grid on;


% pause
 %end