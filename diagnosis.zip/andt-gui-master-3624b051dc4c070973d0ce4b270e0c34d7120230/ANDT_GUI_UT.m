function varargout = ANDT_GUI_UT(varargin)
% ANDT_GUI_UT MATLAB code for ANDT_GUI_UT.fig
%      ANDT_GUI_UT, by itself, creates a new ANDT_GUI_UT or raises the existing
%      singleton*
%
%      H = ANDT_GUI_UT returns the handle to a new ANDT_GUI_UT or the handle to
%      the existing singleton*.
%
%      ANDT_GUI_UT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANDT_GUI_UT.M with the given input arguments.
%
%      ANDT_GUI_UT('Property','Value',...) creates a new ANDT_GUI_UT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ANDT_GUI_UT_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ANDT_GUI_UT_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ANDT_GUI_UT

% Last Modified by GUIDE v2.5 06-Dec-2014 14:41:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ANDT_GUI_UT_OpeningFcn, ...
                   'gui_OutputFcn',  @ANDT_GUI_UT_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ANDT_GUI_UT is made visible.
function ANDT_GUI_UT_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ANDT_GUI_UT (see VARARGIN)

% Choose default command line output for ANDT_GUI_UT
handles.output = hObject;

% Display backgrounds
set (hObject,'CurrentAxes',handles.axes1);
imshow ('backgr.bmp');
axis(handles.axes1,'normal');

set (hObject,'CurrentAxes',handles.ut_disp);
nust_logo = imread ('nust.jpg');
imshow (nust_logo);
% axis on;
% axis auto;
% axis normal;
set (handles.ut_disp,'yDir','normal');

% Choose default command line output for ANDT_GUI_UT
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
    handles.igc.ta_sel = parent.igc.ta_sel; % update ta_sel from parent GUI
    handles.igc.m_sel = parent.igc.m_sel; % update m_sel from parent GUI
else
    handles.igc.ta_sel = 'Target Area'; % default if no parent GUI present
    handles.igc.m_sel = 'UT'; % default if no parent GUI present
end


% Initialize ut variables
handles.ut.calib_filename = '';
handles.ut.calib_filepath = '';
handles.ut.raw_filename = '';
handles.ut.raw_filepath = '';
handles.ut.stft_x = 0;
handles.ut.stft_y = 0;
handles.ut.NumLoc = 1;
handles.ut.SelLoc = 1;
handles.ut.def_cmap = colormap; % Default Color map used in UT for STFT
handles.ut.inv_cmap = flipud(colormap); % Inverted Color map used in UT for C Scan
handles.ut.hht_cmap = flipud(bone); % Inverted Color map used in UT for C Scan

% Disable all buttons
set(handles.ascan_btn,'enable','off');
set(handles.HHT_btn,'enable','off');
set(handles.cscan_btn,'enable','off');
set(handles.fft_btn,'enable','off');
set(handles.stft_btn,'enable','off');
set(handles.report_btn,'enable','off');
set(handles.stft_btn,'enable','off');
set(handles.Datacursor,'enable','off');
set(handles.PopUp,'enable','off');


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ANDT_GUI_UT wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% Set window Title
set (hObject,'Name',cat(2,'Aerospace NDT GUI - ',handles.igc.ta_sel,' - ',handles.igc.m_sel));


% --- Outputs from this function are returned to the command line.
function varargout = ANDT_GUI_UT_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Calib_Path_UT.
function calib_file_sel_Callback(hObject, eventdata, handles)
% hObject    handle to Calib_Path_UT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[handles.ut.calib_filename,handles.ut.calib_filepath] = uigetfile({'*.dat'}); % Prompt user to select appropriate *.dat file
sel_calib_file_pathname = strcat(handles.ut.calib_filepath,handles.ut.calib_filename);%Concatanating Filepath z

if ~isdir(handles.ut.calib_filepath)
    set(handles.Calib_Path_UT,'string','No callibration file selected');
    errordlg('Error! you have not selected file','No file selected!'); 
    set(handles.load_btn,'enable','off');
    return;
else
    set(handles.Calib_Path_UT,'string',sel_calib_file_pathname);
    if isdir(handles.ut.raw_filepath)
        set(handles.load_btn,'enable','on');
    else
        set(handles.load_btn,'enable','off');
    end
end

% Update handles structure
guidata(handles.output, handles);



% --- Executes on button press in Raw_Path_UT.
function raw_file_sel_Callback(hObject, eventdata, handles)
% hObject    handle to Raw_Path_UT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[handles.ut.raw_filepath] = uigetdir();

if ~isdir(handles.ut.raw_filepath)
    set(handles.Raw_Path_UT,'string','No raw folder selected');
    errordlg('Error! you have not selected file','No file selected!'); 
    set(handles.load_btn,'enable','off');
    return;
else
    set(handles.Raw_Path_UT,'string',handles.ut.raw_filepath);
    if isdir(handles.ut.calib_filepath)
        set(handles.load_btn,'enable','on');
    else
        set(handles.load_btn,'enable','off');
    end
end

% Update handles structure
guidata(handles.output, handles);


% --- Executes on button press in load_btn.
function load_btn_Callback(hObject, eventdata, handles)
% hObject    handle to load_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

current_path = path;    % store current path
path (path, handles.ut.raw_filepath); % append given data path to MATLAB search path temporarily

[handles.ut.A, handles.ut.D] = UT_initialize(cat(2,handles.ut.raw_filepath,'\','*.dat'),handles.ut_disp);
path (current_path);    % restore current path

%for calibration file

current_path = path;    % store current path
path (path, handles.ut.calib_filepath); % append given data path to MATLAB search path temporarily
[handles.ut.A_calib, handles.ut.D_calib] = UT_initialize(cat(2,handles.ut.calib_filepath,'\','*.dat'),handles.ut_disp);

path (current_path);    % restore current path

handles.ut.NumLoc = length(handles.ut.A(1,:)); % Store length of A as number of locations for dropdown menu and row/col check

% Get and Check Row/Col inputs
handles.ut.Rows = str2double(get(handles.Row_Input,'String'));
handles.ut.Cols = str2double(get(handles.Col_Input,'String'));
if (handles.ut.Rows*handles.ut.Cols ~= handles.ut.NumLoc)
    errordlg('Total number of locations do not match actual number of files loaded!');
    return;
end

% Enable all buttons
set(handles.ascan_btn,'enable','on');
set(handles.HHT_btn,'enable','on'); % Currently Disabled
set(handles.cscan_btn,'enable','on');
set(handles.fft_btn,'enable','on');
set(handles.stft_btn,'enable','on');
set(handles.report_btn,'enable','on');
set(handles.PopUp,'enable','on');

   
% Create List of Strings for Drop-down PopUp Menu
for k = 1:handles.ut.NumLoc
        PopUp{k} = sprintf('Location number %d', k);
end
set(handles.PopUp,'Style','Popupmenu','String',PopUp);
set(handles.PopUp,'enable','off');

% Update handles structure
guidata(handles.output, handles);


% --- Executes on button press in ascan_btn.
function ascan_btn_Callback(hObject, eventdata, handles)
% hObject    handle to ascan_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Datacursor,'enable','off');
set(handles.PopUp,'enable','on');

set(handles.Desc_txt,'String','Amplitude Scan: It gives the plot between Amplitude and Time.');

current_path = path;    % store current path
path (path, handles.ut.raw_filepath); % append given data path to MATLAB search path temporarily

UT_AScan(handles.ut.A, handles.ut.D, handles.ut_disp, handles.ut.SelLoc);

path (current_path);    % restore current path
% set(handles.PopUp,'enable','off');

% --- Executes on button press in HHT_btn.
function HHT_btn_Callback(hObject, eventdata, handles)
% hObject    handle to HHT_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Datacursor,'enable','off');
set(handles.PopUp,'enable','on');

set(handles.Desc_txt,'String','HHT: It shows the Hilbert Huang Transform of A Scans. The greater the intensity of the scatter plot, greater is the probability of flaw.');

current_path = path;    % store current path
path (path, handles.ut.raw_filepath); % append given data path to MATLAB search path temporarily

UT_hlhut(handles.ut.A,handles.ut_disp, handles.ut.SelLoc,handles.ut.hht_cmap);

path (current_path);    % restore current path

% Update handles structure
guidata(handles.output, handles);


% --- Executes on button press in cscan_btn.
function cscan_btn_Callback(hObject, eventdata, handles)
% hObject    handle to cscan_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Datacursor,'enable','off');
set(handles.PopUp,'enable','off');

set(handles.Desc_txt,'String','C Scan: It gives the top view of the test specimen and it is top view thickness mapping of the material which is obtained with the help of A Scans.');

current_path = path;    % store current path
path (path, handles.ut.raw_filepath); % append given data path to MATLAB search path temporarily

handles.ut.M = UT_CScan(handles.ut.A, handles.ut.D, handles.ut_disp, handles.ut.Rows, handles.ut.Cols, handles.ut.inv_cmap,1);

path (current_path);    % restore current path

% Update handles structure
guidata(handles.output, handles);

% --- Executes on button press in fft_btn.
function fft_btn_Callback(hObject, eventdata, handles)
% hObject    handle to fft_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Datacursor,'enable','off');
set(handles.PopUp,'enable','on');

set(handles.Desc_txt,'String','FFT: It gives the Fast Frequency Transform of A Scans.');

current_path = path;    % store current path
path (path, handles.ut.raw_filepath); % append given data path to MATLAB search path temporarily

UT_Fft(handles.ut.A, handles.ut.D, handles.ut_disp, handles.ut.SelLoc);

path (current_path);    % restore current path
% set(handles.PopUp,'enable','off');



% --- Executes on button press in stft_btn.
 function stft_btn_Callback(hObject, eventdata, handles)
% hObject    handle to stft_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Datacursor,'enable','on');
set(handles.PopUp,'enable','on');

set(handles.Desc_txt,'String','STFT: It gives the Short Term Frequency Transform of A Scans.');

current_path = path;    % store current path
path (path, handles.ut.raw_filepath); % append given data path to MATLAB search path temporarily

UT_STFT(handles.ut.A, handles.ut.D, handles.ut_disp, handles.ut.stft_x, handles.ut.stft_y, handles.ut.SelLoc, handles.ut.def_cmap);

path (current_path);    % restore current path
% set(handles.PopUp,'enable','off');


% --- Executes on button press in report_btn.
function report_btn_Callback(hObject, eventdata, handles)
% hObject    handle to report_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Datacursor,'enable','off');
set(handles.PopUp,'enable','off');

%set(handles.Desc_txt,'String','Report: Report not implemented yet!.');

%for calibration file
current_path = path;    % store current path
path (path, handles.ut.calib_filepath); % append given data path to MATLAB search path temporarily

handles.ut.M_calib = UT_CScan(handles.ut.A_calib, handles.ut.D_calib, handles.ut_disp, 1, 1, handles.ut.inv_cmap,0);

path (current_path);    % restore current path

% Report Generation

[Report_filename, Report_pathname]= uiputfile('*.txt','Save Report as'); % Prompt User for Saving Report file

if Report_pathname
    
    % Open File for Reporting Important Parameters
    fid = fopen(cat(2,Report_pathname,Report_filename),'w');

    if (fid == -1), 
        error('File not opened!'); 
    end

    fprintf(fid,'::Ultrasonic Test Report::\r\n\r\n\r\n');
    fprintf(fid,'Engineers: M. Nouman Khan, Taha Ali\r\n');
    fprintf(fid,'Developers: Sumayya Abbas, Salar Bin Javaid\r\n');
    fprintf(fid,'Date: %s\r\n\r\n',date);
    fprintf(fid,'A scan# \t Defect/No Defect \t\t Depth \r\n\r\n');

    M_c = handles.ut.M';

    for k=1:handles.ut.NumLoc

    %to compare depths
    comp = (abs(handles.ut.M_calib-M_c(k))/M_c(k))*100;
     if (comp>=10)
         comp_val = 1;

     else
         comp_val = 0;
     end

     if (comp_val==1)

     fprintf(fid,'%d \t\t %s \t\t\t %0.2f mm \r\n',k,'Defect',M_c(k));

     else 
     fprintf(fid,'%d \t\t %s \t %d \r\n',k,'No Defect');     

     end

    fprintf(fid,'\r\n');
    end

    fprintf(fid,'::End of Report::');
    fclose(fid);

    system(cat(2,Report_pathname,Report_filename));
else
    msgbox('Report has not been saved.','File input cancelled!'); 
end



% --- Executes during object creation, after setting all properties.
function ut_disp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ut_disp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate ut_disp


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes on button press in Datacursor.
function Datacursor_Callback(hObject, eventdata, handles)
% hObject    handle to Datacursor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[handles.ut.stft_x,handles.ut.stft_y]=ginput(1);

current_path = path;    % store current path
path (path, handles.ut.raw_filepath); % append given data path to MATLAB search path temporarily

UT_STFT(handles.ut.A, handles.ut.D, handles.ut_disp, handles.ut.stft_x, handles.ut.stft_y, handles.ut.SelLoc);

path (current_path);    % restore current path

% Update handles structure
guidata(handles.output, handles);


% --- Executes when uipanel3 is resized.
function uipanel3_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to uipanel3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when control is resized.
function control_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to control (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on button press in Back_btn.
function Back_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Back_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ANDT_GUI_M_Sel (handles.igc);


% --- Executes on selection change in PopUp.
function PopUp_Callback(hObject, eventdata, handles)
% hObject    handle to PopUp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns PopUp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PopUp
% Create the controls and initialize the string property with the cell arrays
% handles.PopUp = uicontrol('Style', 'Popupmenu','Position', [1120 300 185 50], 'String', PopUp);

handles.ut.SelLoc = get(handles.PopUp,'Value');
% current_path = path;    % store current path
% path (path, handles.ut.raw_filepath); % append given data path to MATLAB search path temporarily
% 
% UT_STFT(handles.ut.A, handles.ut.D, handles.ut_disp, handles.ut.stft_x, handles.ut.stft_y, handles.ut.NumLoc);
% 
% path (current_path);    % restore current path

%Update handles structure
guidata(handles.output, handles);




% --- Executes during object creation, after setting all properties.
function PopUp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PopUp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Row_Input_Callback(hObject, eventdata, handles)
% hObject    handle to Row_Input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Row_Input as text
%        str2double(get(hObject,'String')) returns contents of Row_Input as a double


% --- Executes during object creation, after setting all properties.
function Row_Input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Row_Input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Col_Input_Callback(hObject, eventdata, handles)
% hObject    handle to Col_Input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Col_Input as text
%        str2double(get(hObject,'String')) returns contents of Col_Input as a double


% --- Executes during object creation, after setting all properties.
function Col_Input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Col_Input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton17.
function pushbutton17_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function browse_UT_Calib_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Calib_Path_UT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function calib_file_sel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Calib_Path_UT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on key press with focus on Calib_Path_UT and none of its controls.
function calib_file_sel_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to Calib_Path_UT (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function Calib_Path_UT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Calib_Path_UT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
