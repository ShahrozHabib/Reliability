function varargout = ANDT_GUI_Template(varargin)
% ANDT_GUI_TEMPLATE M-file for ANDT_GUI_Template.fig
%      ANDT_GUI_TEMPLATE, by itself, creates a new ANDT_GUI_TEMPLATE or raises the existing
%      singleton*.
%
%      H = ANDT_GUI_TEMPLATE returns the handle to a new ANDT_GUI_TEMPLATE or the handle to
%      the existing singleton*.
%
%      ANDT_GUI_TEMPLATE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANDT_GUI_TEMPLATE.M with the given input arguments.
%
%      ANDT_GUI_TEMPLATE('Property','Value',...) creates a new ANDT_GUI_TEMPLATE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ANDT_GUI_Template_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ANDT_GUI_Template_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ANDT_GUI_Template

% Last Modified by GUIDE v2.5 03-Mar-2014 13:54:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ANDT_GUI_Template_OpeningFcn, ...
                   'gui_OutputFcn',  @ANDT_GUI_Template_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ANDT_GUI_Template is made visible.
function ANDT_GUI_Template_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ANDT_GUI_Template (see VARARGIN)

% Choose default command line output for ANDT_GUI_Template
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ANDT_GUI_Template wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ANDT_GUI_Template_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function backgr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BACKGROUND (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate BACKGROUND
imshow('backgr.bmp');
