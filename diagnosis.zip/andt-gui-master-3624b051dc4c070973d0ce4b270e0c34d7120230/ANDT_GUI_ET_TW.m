function varargout = ANDT_GUI_ET(varargin)
% ANDT_GUI_ET M-file for ANDT_GUI_ET.fig
%      ANDT_GUI_ET, by itself, creates a new ANDT_GUI_ET or raises the existing
%      singleton*.
%
%      H = ANDT_GUI_ET returns the handle to a new ANDT_GUI_ET or the handle to
%      the existing singleton*.
%
%      ANDT_GUI_ET('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANDT_GUI_ET.M with the given input arguments.
%
%      ANDT_GUI_ET('Property','Value',...) creates a new ANDT_GUI_ET or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ANDT_GUI_ET_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ANDT_GUI_ET_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run_btn (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ANDT_GUI_ET

% Last Modified by GUIDE v2.5 07-Mar-2014 16:41:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ANDT_GUI_ET_OpeningFcn, ...
                   'gui_OutputFcn',  @ANDT_GUI_ET_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ANDT_GUI_ET is made visible.
function ANDT_GUI_ET_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ANDT_GUI_ET (see VARARGIN)

% Choose default command line output for ANDT_GUI_ET
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
    handles.igc.ta_sel = parent.igc.ta_sel; % update ta_sel from parent GUI
    handles.igc.m_sel = parent.igc.m_sel; % update m_sel from parent GUI
else
    handles.igc.ta_sel = 'Target Area'; % default if no parent GUI present
    handles.igc.m_sel = 'ET'; % default if no parent GUI present
end

% Initialize et variables
handles.et.calib_filename = '';
handles.et.calib_filepath = '';
handles.et.raw_filename = '';
handles.et.raw_filepath = '';


% Update handles structure
guidata(hObject, handles);

% Disable all push buttons before file selection
set(handles.run_btn,'string','run','enable','off');
set(handles.mag_btn,'string','','enable','off');
set(handles.hist_btn,'string','','enable','off');
set(handles.adapt_th_btn,'string','','enable','off');
set(handles.roi_detect_btn,'string','','enable','off');
set(handles.report_btn,'string','','enable','off');
set(handles.pushbutton6,'string','','enable','off');
set(handles.pushbutton7,'string','','enable','off');
set(handles.pushbutton8,'string','','enable','off');
set(handles.pushbutton9,'string','','enable','off');
set(handles.pushbutton13,'string','','enable','off');
% UIWAIT makes ANDT_GUI_ET wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% Set window Title
set (hObject,'Name',cat(2,'Aerospace NDT GUI - ',handles.igc.ta_sel,' - ',handles.igc.m_sel));

clc;
clear all;
close all;

global callback8;
global callback9;
global callback6;
callback6 = 0;
callback8 = 0;
callback9 = 0;


% --- Outputs from this function are returned to the command line.
function varargout = ANDT_GUI_ET_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function background_CreateFcn(hObject, eventdata, handles)
% hObject    handle to background1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate background1
imshow('backgr.bmp')


% --- Executes on button press in mag_btn.
function mag_btn_Callback(hObject, eventdata, handles)
% hObject    handle to mag_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global z;
plot(z,'*'); % First Plot ( Impedence )
title('Impedance plot');
xlabel('Resistance, R');
ylabel('Inductive Reactance,X');

% --- Executes on button press in hist_btn.
function hist_btn_Callback(hObject, eventdata, handles)
% hObject    handle to hist_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global abs_mag;
plot(abs_mag) % Second Plot  ( Magnitude of Impedence)
title('Magnitude Matrix Plot');
title('Magnitude Plot');
xlabel('Indices');
ylabel('Amplitude');

% --- Executes on button press in adapt_th_btn.
function adapt_th_btn_Callback(hObject, eventdata, handles)
% hObject    handle to adapt_th_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global abs_mag;
imagesc(abs_mag'); % Third Plot ( Image of Impedence Magnitude)
title('Imagesc plot of raw data Magnitude');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');

% --- Executes on button press in roi_detect_btn.
function roi_detect_btn_Callback(hObject, eventdata, handles)
% hObject    handle to roi_detect_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global new_mag;
plot(new_mag); % Fourth Plot ( Calibrated Impedence Magnitude)


% --- Executes on button press in report_btn.
function report_btn_Callback(hObject, eventdata, handles)
% hObject    handle to report_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global callback5;

imagesc(callback5); % Fifth Plot ( Image of Calibrated Impedence Magnitude)
title('Imagesc plot of Calibrated Magnitude');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');

% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Data;

for i = 1:length(Data(:,1))
        for j = 1:length(Data(1,:))
            if Data(i,j) >= 7
               Data(i,j) = 1;
            end
        end
end

imagesc(Data) 
title('Imagesc plot of Magnitude After Land Mark Elimination');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global bin_img;
imagesc(bin_img); 
    title('Imagesc plot of  Magnitude after Adaptive Thresholding');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');

% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global callback8;
imagesc(callback8);
title('Imagesc plot of Calibrated Imaginary Part');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');
% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global callback9;
imagesc(callback9);
title('Imagesc plot of Calibrated Real Part');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');

% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CBW;
imagesc(CBW); % Seventh Plot ( Thresholded Image)
title('Imagesc plot of ROI Detection');
xlabel('indices')
ylabel('Rows');
h=colorbar;
xlabel(h,'Voltage');



% --- Executes on button press in calib_file_sel.
function calib_file_sel_Callback(hObject, eventdata, handles)
% hObject    handle to calib_file_sel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[handles.et.calib_filename,handles.et.calib_filepath] = uigetfile({'*.dat'});

if handles.et.calib_filename==0
set(handles.calib_file_sel,'string','no calibration file');
end
if ~ischar(handles.et.calib_filename) 
    errordlg('Error! you have not selected file','no file selected!'); 
    set(handles.run_btn,'string','run','enable','off');
    return;
else
    set(handles.calib_file_sel,'string',handles.et.calib_filepath);
    if ~ischar(handles.et.raw_filename)
        set(handles.run_btn,'string','run','enable','off');
    else
        set(handles.run_btn,'string','run','enable','on');
    end
end

% Update handles structure
guidata(handles.output, handles);

% --- Executes on button press in raw_file_sel.
function raw_file_sel_Callback(hObject, eventdata, handles)
% hObject    handle to raw_file_sel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[handles.et.raw_filename,handles.et.raw_filepath] = uigetfile({'*.dat'}); %selectam poza dorita pentru incarcare in axes1

if handles.et.raw_filename==0
set(handles.raw_file_sel,'string','no raw file');
end
if ~ischar(handles.et.raw_filename) 
    errordlg('Error! you have not selected file','no file selected!'); 
    set(handles.run_btn,'string','run','enable','off');
    return;
else
    set(handles.raw_file_sel,'string',handles.et.raw_filepath);
    if ~ischar(handles.et.calib_filename)
        set(handles.run_btn,'string','run','enable','off');
    else
        set(handles.run_btn,'string','run','enable','on');
    end
end

handles.et.calib_filename
% Update handles structure
guidata(handles.output, handles);


% --- Executes on button press in run_btn.
function run_btn_Callback(hObject, eventdata, handles)
% hObject    handle to run_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global new_mag;
global Data;

global callback5;
global callback8;
global callback9;


set(handles.mag_btn,'string','impedance plot','enable','on')
set(handles.hist_btn,'string','Matrix plot','enable','on');
set(handles.adapt_th_btn,'string','Raw data file','enable','on');
set(handles.roi_detect_btn,'string','Calib impedance','enable','on');
set(handles.report_btn,'string','Calib magnitude','enable','on');
set(handles.pushbutton6,'string','Land mark','enable','on');
set(handles.pushbutton7,'string','Adaptive thresholding','enable','on');
set(handles.pushbutton8,'string','Calib imaginary','enable','on');
set(handles.pushbutton9,'string','Calib real','enable','on');
set(handles.pushbutton13,'string','ROI detection','enable','on');
pause(.1)

[handles.et.impedence, handles.et.impedence_mag, handles.et.Real_Component, handles.et.Imaginary_Component] = extract_data(cat(2,handles.et.raw_filepath,'*.dat'),handles.et.display_h);


Data=new_mag';
callback5=new_mag';
pause(2);
callback8=calibrated_data.outim_200k;
callback9=calibrated_data.outre_200k;


% Update handles structure
guidata(handles.output, handles);


% --- Executes during object creation, after setting all properties.
function et_disp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to et_disp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate et_disp
handles.et.display_h = hObject;

% Update handles structure
guidata(handles.output, handles);
