function varargout = ANDT_GUI_ET(varargin)
%ANDT_GUI_ET M-file for ANDT_GUI_ET.fig
%      ANDT_GUI_ET, by itself, creates a new ANDT_GUI_ET or raises the existing
%      singleton*.
%
%      H = ANDT_GUI_ET returns the handle to a new ANDT_GUI_ET or the handle to
%      the existing singleton*.
%
%      ANDT_GUI_ET('Property','Value',...) creates a new ANDT_GUI_ET using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to ANDT_GUI_ET_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      ANDT_GUI_ET('CALLBACK') and ANDT_GUI_ET('CALLBACK',hObject,...) call the
%      local function named CALLBACK in ANDT_GUI_ET.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ANDT_GUI_ET

% Last Modified by GUIDE v2.5 04-Dec-2014 20:17:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ANDT_GUI_ET_OpeningFcn, ...
                   'gui_OutputFcn',  @ANDT_GUI_ET_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ANDT_GUI_ET is made visible.
function ANDT_GUI_ET_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Display backgrounds
set (hObject,'CurrentAxes',handles.background);
imshow ('backgr.bmp');
axis(handles.background,'normal');

set (hObject,'CurrentAxes',handles.et_disp);
nust_logo = imread ('nust.jpg');
imshow (nust_logo);
% axis on;
% axis auto;
% axis normal;
set (handles.et_disp,'yDir','normal');


% Choose default command line output for ANDT_GUI_ET
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
    handles.igc.ta_sel = parent.igc.ta_sel; % update ta_sel from parent GUI
    handles.igc.m_sel = parent.igc.m_sel; % update m_sel from parent GUI
else
    handles.igc.ta_sel = 'Target Area'; % default if no parent GUI present
    handles.igc.m_sel = 'ET'; % default if no parent GUI present
end

% Initialize et variables
handles.et.calib_filename = '';
handles.et.calib_filepath = '';
handles.et.raw_filename = '';
handles.et.raw_filepath = '';
handles.et.calib2_filename = '';
handles.et.calib2_filepath = '';
handles.et.raw2_filename = '';
handles.et.raw2_filepath = '';
handles.et.def_cmap = colormap; % Default Color map used in ET for Adaptive Thresh. & ROI
handles.et.inv_cmap = flipud(colormap); % Inverted Color map used in ET for Calibrated Magnitude display

% Update handles structure
guidata(hObject, handles);

% Disable all push buttons before file selection
set(handles.load_btn,'enable','off');
set(handles.mag_btn,'enable','off');
set(handles.hist_btn,'enable','off');
set(handles.adapt_th_btn,'enable','off');
set(handles.roi_detect_btn,'enable','off');
set(handles.report_btn,'enable','off');
set(handles.Desc_text,'string','Detailed Description');

% Set window Title
set (hObject,'Name',cat(2,'Aerospace NDT GUI - ',handles.igc.ta_sel,' - ',handles.igc.m_sel));



% UIWAIT makes ANDT_GUI_ET wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = ANDT_GUI_ET_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function et_disp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to et_disp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate et_disp


% --- Executes on button press in mag_btn.
function mag_btn_Callback(hObject, eventdata, handles)
% hObject    handle to mag_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

delete (allchild(handles.et_disp));

set (handles.et_disp,'yDir','reverse');     %Adjust the orientation of y-axis

set(handles.Desc_text,'string','Magnitude: The image comprises of various colors, ranged from blue to red. Blue indicates no deflection from the probe, in the given area, while red indicates maximum deflection. Deflection occurs due to the cracks, land marks and noise in the signal');

current_path = path;    % store current path
path (path, handles.et.raw_filepath); % append given data path to MATLAB search path temporarily

[handles.et.impedance, handles.et.impedance_mag, handles.et.Real_Component, handles.et.Imaginary_Component] = ET_extract_data (cat(2,handles.et.raw_filepath,'\','*.dat'),handles.et_disp);

ET_calibrate( handles.et.Real_Component, handles.et.Imaginary_Component, handles.et.RotMat, handles.et.Scaling_Factor, handles.et.data_cen_x, handles.et.data_cen_y, handles.et_disp, handles.et.inv_cmap);

path (current_path);    % restore current path

set(handles.hist_btn,'enable','on');
set(handles.adapt_th_btn,'enable','on');
set(handles.roi_detect_btn,'enable','on');

% Update handles structure
guidata(handles.output, handles);

% --- Executes on button press in hist_btn.
function hist_btn_Callback(hObject, eventdata, handles)
% hObject    handle to hist_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

delete (allchild(handles.et_disp));

set (handles.et_disp,'yDir','normal');      %Adjust the orientation of y-axis

set(handles.Desc_text,'string','Histogram: Displays the probability distribution of pixel values in an image in the form of a bar plot. The height of each rectangle indicates the number of elements in the bin.');

current_path = path;    % store current path
path (path, handles.et.raw_filepath); % append given data path to MATLAB search path temporarily

[ calibrate_impedance,imaginary_part,real_part] = ET_calibrate( handles.et.Real_Component, handles.et.Imaginary_Component, handles.et.RotMat, handles.et.Scaling_Factor, handles.et.data_cen_x, handles.et.data_cen_y, handles.et_disp, handles.et.inv_cmap);
calibrated_data.outim_200k=imaginary_part;
calibrated_data.outre_200k=real_part;

% Pre processing Land Mark Elimination 
% [ lme_data] = ET_land_mark_elimination( calibrate_impedance );

% Adaptive_Thresholding
ET_Adaptive_Thresholding( calibrate_impedance, handles.et_disp, 0 , handles.et.def_cmap); % last parameter is zero for plotting only histogram

path (current_path);    % restore current path

% Update handles structure
guidata(handles.output, handles);

% --- Executes on button press in adapt_th_btn.
function adapt_th_btn_Callback(hObject, eventdata, handles)
% hObject    handle to adapt_th_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

delete (allchild(handles.et_disp));

set (handles.et_disp,'yDir','reverse');      %Adjust the orientation of y-axis

set(handles.Desc_text,'string','Adaptive Thresholding: Displays the processed image of a particular area of an aircraft part. It used to remove the ill influence present in the data. The red regions signify the possible affected area in an aircraft.');

current_path = path;    % store current path
path (path, handles.et.raw_filepath); % append given data path to MATLAB search path temporarily

[ calibrate_impedance,imaginary_part,real_part] = ET_calibrate( handles.et.Real_Component, handles.et.Imaginary_Component, handles.et.RotMat, handles.et.Scaling_Factor, handles.et.data_cen_x, handles.et.data_cen_y, handles.et_disp, handles.et.inv_cmap);
calibrated_data.outim_200k=imaginary_part;
calibrated_data.outre_200k=real_part;

% Pre processing Land Mark Elimination 
%[ lme_data] = ET_land_mark_elimination( calibrate_impedance );

% Adaptive_Thresholding
ET_Adaptive_Thresholding( calibrate_impedance,handles.et_disp,1, handles.et.def_cmap); % last parameter is not zero

path (current_path);    % restore current path

% Update handles structure
guidata(handles.output, handles);

% --- Executes on button press in roi_detect_btn.
function roi_detect_btn_Callback(hObject, eventdata, handles)
% hObject    handle to roi_detect_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

delete (allchild(handles.et_disp));

set (handles.et_disp,'yDir','reverse');     %Adjust the orientation of y-axis

set(handles.Desc_text,'string','ROI Detection: Displays the possible region of interests after morphological operations (i.e. pre-processing techniques) are successfully applied. The regions show the area of interest where the probability of the presence of a flaw is rather high');

current_path = path;    % store current path
path (path, handles.et.raw_filepath); % append given data path to MATLAB search path temporarily

[ calibrate_impedance,imaginary_part,real_part] = ET_calibrate( handles.et.Real_Component, handles.et.Imaginary_Component, handles.et.RotMat, handles.et.Scaling_Factor, handles.et.data_cen_x, handles.et.data_cen_y, handles.et_disp, handles.et.inv_cmap);
calibrated_data.outim_200k=imaginary_part;
calibrated_data.outre_200k=real_part;

% Pre processing Land Mark Elimination 
% [ lme_data] = ET_land_mark_elimination( calibrate_impedance );

% Adaptive_Thresholding
adaptive_thresholding_image=ET_Adaptive_Thresholding( calibrate_impedance,handles.et_disp,1,handles.et.def_cmap); % last parameter is zero for plotting only histogram

%Applies morphological operation
[ clean_binimage ] = ET_morph_ops( adaptive_thresholding_image,handles.et_disp,handles.et.def_cmap);

%ROI detection
[ roiboxes ] = ET_roi_detection( clean_binimage, handles.et_disp );

path (current_path);    % restore current path

% Update handles structure
guidata(handles.output, handles);


% --- Executes on button press in report_btn.
function report_btn_Callback(hObject, eventdata, handles)
% hObject    handle to report_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

delete (allchild(handles.et_disp));

set (handles.et_disp,'yDir','reverse');     %Adjust the orientation of y-axis

set(handles.Desc_text,'string','Report: Displays the final report which gives adequate detail about the effected regions. The report is obtained after comparison of data obtained at two frequencies, which leads to greater accuracy.');

set(handles.hist_btn,'enable','off');
set(handles.adapt_th_btn,'enable','off');
set(handles.roi_detect_btn,'enable','off');

current_path = path;    % store current path
path (path, handles.et.raw_filepath); % append given data path to MATLAB search path temporarily

[ calibrate_impedance,imaginary_part,real_part] = ET_calibrate( handles.et.Real_Component, handles.et.Imaginary_Component, handles.et.RotMat, handles.et.Scaling_Factor, handles.et.data_cen_x, handles.et.data_cen_y, handles.et_disp, handles.et.inv_cmap);
calibrated_data.outim_200k=imaginary_part;
calibrated_data.outre_200k=real_part;

% Pre processing Land Mark Elimination 
% [ lme_data] = ET_land_mark_elimination( calibrate_impedance );

% Adaptive_Thresholding
adaptive_thresholding_image=ET_Adaptive_Thresholding( calibrate_impedance,handles.et_disp,1,handles.et.def_cmap); % last parameter is zero for plotting only histogram

%Applies morphological operation
[ clean_binimage ] = ET_morph_ops( adaptive_thresholding_image,handles.et_disp,handles.et.def_cmap);

%ROI detection
[ roiboxes ] = ET_roi_detection( clean_binimage, handles.et_disp );

path (current_path);    % restore current path


% Code for low frequency files

current_path = path;    % store current path
path (path, handles.et.raw2_filepath); % append given data path to MATLAB search path temporarily

[handles.et.impedance, handles.et.impedance_mag, handles.et.Real_Component, handles.et.Imaginary_Component] = ET_extract_data (cat(2,handles.et.raw2_filepath,'\','*.dat'),handles.et_disp);

[ calibrate_impedance,imaginary_part,real_part] = ET_calibrate( handles.et.Real_Component, handles.et.Imaginary_Component, handles.et.RotMat, handles.et.Scaling_Factor, handles.et.data_cen_x, handles.et.data_cen_y, handles.et_disp, handles.et.inv_cmap);
calibrated_data.outim_100k=imaginary_part;
calibrated_data.outre_100k=real_part;

% Feature Extraction
[ Feature_Extracted_Boxes ] = ET_feature_extraction( roiboxes,calibrated_data );

% Classification 
[ features ] = ET_classification( Feature_Extracted_Boxes );

path (current_path);    % restore current path


delete (allchild(handles.et_disp)); % Delete the displayed image, see issue#14

% Report Generation

[Report_filename, Report_pathname]= uiputfile('*.txt','Save Report as'); % Prompt User for Saving Report file

if Report_pathname
    
    % Open File for Reporting Important Parameters
    fid = fopen(cat(2,Report_pathname,Report_filename),'w');
    if (fid == -1), error('File not opened!'); end
    fprintf(fid,'::Eddy Current Test Report::\r\n\r\n');
    fprintf(fid,'Selected Inspection Area: %s\r\n\r\n', handles.igc.ta_sel);
    fprintf(fid,'Engineers: Moez-ul-Hasan, Taha Ali\r\n');
    fprintf(fid,'Developers: Salar Bin Javaid, Ameer Usman\r\n');
    fprintf(fid,'Date: %s\r\n\r\n',date);


    fprintf(fid,'Number of ROIs: %d\r\n\r\n',length(features));
    fprintf(fid,'ROI# \tROI Locations \t\tFeatures \t\tValue \t\tDecision\r\n\r\n');

    for k=1:length(features)

    fprintf(fid,'%d \t%ld \t\t\t%s \t\t%f \t%s\r\n',k,features(k).roi(1,1),'Max Reactance', ...
    features(k).A200_maxVert,features(k).isDefect);

    fprintf(fid,'\t%ld \t\t\t%s \t\t%f\r\n',features(k).roi(1,2),'Max Magnitude', ...
    features(k).A200_maxMag);

    fprintf(fid,'\t%ld \t\t\t%s \t%f\r\n',features(k).roi(1,3),'Phase_High_Freq', ...
    features(k).A200_PhsMxVert);

    fprintf(fid,'\t%ld \t\t\t%s \t%f\r\n',features(k).roi(1,4),'Phase_Low_Freq ', ...
    features(k).A100_PhsMxVert);

    fprintf(fid,'\r\n');
    end

    fprintf(fid,'::End of Report::');
    fclose(fid);

    system(cat(2,Report_pathname,Report_filename));
else
    msgbox('Report has not been saved.','File input cancelled!'); 
end

% Update handles structure
guidata(handles.output, handles);


% --- Executes on button press in calib_file_path.
function calib_file_sel_Callback(hObject, eventdata, handles)
% hObject    handle to calib_file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% High frequency calib file selection
[handles.et.calib_filename,handles.et.calib_filepath] = uigetfile({'*.dat'},'Please Select High Frequency Calibration File','.\ET\Calibration_files\200KHz\'); % Prompt user to select appropriate *.dat file
if ~isdir(handles.et.calib_filepath)
    set(handles.calib_file_path,'string','No calibration file selected');
    errordlg('Error! you have not selected file','No file selected!'); 
    set(handles.load_btn,'enable','off');
    return;
else
    set(handles.calib_file_path,'string',handles.et.calib_filepath);
    if isdir(handles.et.raw_filepath)
        set(handles.load_btn,'enable','on');
    else
        set(handles.load_btn,'enable','off');
    end
end

% Update handles structure
guidata(handles.output, handles);


% --- Executes on button press in raw_file_path.
function raw_file_sel_Callback(hObject, eventdata, handles)
% hObject    handle to raw_file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% High frequency raw files directory selection
[handles.et.raw_filepath] = uigetdir('.\ET\Data_files\200k','Please select High frequency raw files directory');

if ~isdir(handles.et.raw_filepath)
    set(handles.raw_file_path,'string','No raw folder selected');
    errordlg('Error! you have not selected file','No file selected!'); 
    set(handles.load_btn,'enable','off');
    return;
else
    set(handles.raw_file_path,'string',handles.et.raw_filepath);
    if isdir(handles.et.calib_filepath)
        set(handles.load_btn,'enable','on');
    else
        set(handles.load_btn,'enable','off');
    end
end

% Update handles structure
guidata(handles.output, handles);


% --- Executes on button press in load_btn.
function load_btn_Callback(hObject, eventdata, handles)
% hObject    handle to load_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

current_path = path;    % store current path
path (path, handles.et.calib_filepath); % append given data path to MATLAB search path temporarily

[handles.et.impedance, handles.et.impedance_mag, handles.et.Real_Component, handles.et.Imaginary_Component] = ET_extract_data (cat(2,handles.et.calib_filepath,'\','*.dat'),handles.et_disp);

if (isempty(handles.et.impedance)||isempty(handles.et.impedance_mag)||isempty(handles.et.Real_Component)||isempty(handles.et.Imaginary_Component))
    errordlg('Invalid calibration or data file selected','File Error')
end    

[handles.et.RotMat, handles.et.Scaling_Factor, handles.et.data_cen_x, handles.et.data_cen_y] = ET_genCalibparams( handles.et.impedance_mag, handles.et.Real_Component, handles.et.Imaginary_Component);

handles.et.data_cen_x=0;
handles.et.data_cen_y=0;

path (current_path);    % restore current path

current_path = path;    % store current path
path (path, handles.et.calib2_filepath); % append given data path to MATLAB search path temporarily

[handles.et.impedance, handles.et.impedance_mag, handles.et.Real_Component, handles.et.Imaginary_Component] = ET_extract_data (cat(2,handles.et.calib2_filepath,'\','*.dat'),handles.et_disp);

if (isempty(handles.et.impedance)||isempty(handles.et.impedance_mag)||isempty(handles.et.Real_Component)||isempty(handles.et.Imaginary_Component))
    errordlg('Invalid calibration or data file selected','File Error')
end  

[handles.et.RotMat, handles.et.Scaling_Factor, handles.et.data_cen_x, handles.et.data_cen_y] = ET_genCalibparams( handles.et.impedance_mag, handles.et.Real_Component, handles.et.Imaginary_Component);

handles.et.data_cen_x=0;
handles.et.data_cen_y=0;

path (current_path);    % restore current path

% Enable magniude and report button, all buttons will be enabled after magnitude
set(handles.mag_btn,'enable','on');
set(handles.hist_btn,'enable','off');
set(handles.adapt_th_btn,'enable','off');
set(handles.roi_detect_btn,'enable','off');
set(handles.report_btn,'enable','on');

% Update handles structure
guidata(handles.output, handles);

% --- Executes during object creation, after setting all properties.
function background_CreateFcn(hObject, eventdata, handles)
% hObject    handle to background (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate background


% --- Executes on button press in calib_file_path_2.
	function calib_file_sel_2_Callback(hObject, eventdata, handles)
% hObject    handle to calib_file_path_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Low frequency calib file selection
[handles.et.calib2_filename,handles.et.calib2_filepath] = uigetfile({'*.dat'},...
    'Please select Low frequency calib file','.\ET\Calibration_files\100KHz\'); % Prompt user to select appropriate *.dat file
if ~isdir(handles.et.calib2_filepath)
    set(handles.calib_file_path_2,'string','No calibration file selected');
    errordlg('Error! you have not selected file','No file selected!'); 
    set(handles.load_btn,'enable','off');
    return;
else
    set(handles.calib_file_path_2,'string',handles.et.calib2_filepath);
    if isdir(handles.et.raw2_filepath)
        set(handles.load_btn,'enable','on');
    else
        set(handles.load_btn,'enable','off');
    end
end

% Update handles structure
guidata(handles.output, handles);



% --- Executes on button press in raw_file_path_2.
function raw_file_sel_2_Callback(hObject, eventdata, handles)
% hObject    handle to raw_file_path_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Low frequency raw files directory selection
[handles.et.raw2_filepath] = uigetdir('.\ET\Data_files\100K','Please select Low frequency raw files directory');

if ~isdir(handles.et.raw2_filepath)
    set(handles.raw_file_path_2,'string','No raw folder selected');
    errordlg('Error! you have not selected file','No file selected!'); 
    set(handles.load_btn,'enable','off');
    return;
else
    set(handles.raw_file_path_2,'string',handles.et.raw2_filepath);
    if isdir(handles.et.calib2_filepath)
        set(handles.load_btn,'enable','on');
    else
        set(handles.load_btn,'enable','off');
    end
end

% Update handles structure
guidata(handles.output, handles);


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over Desc_text.
function Desc_text_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to Desc_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over Desc_heading_txt.
function Desc_heading_txt_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to Desc_heading_txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in Back_btn.
function Back_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Back_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ANDT_GUI_M_Sel (handles.igc);


% --- Executes during object creation, after setting all properties.
function Desc_text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Desc_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function calib_file_path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to calib_file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function raw_file_path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to raw_file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function raw_file_path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to raw_file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function calib_file_path_2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to calib_file_path_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function raw_file_path_2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to raw_file_path_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in calib_file_sel_2.
function calib_file_sel_2_Callback(hObject, eventdata, handles)
% hObject    handle to calib_file_sel_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
