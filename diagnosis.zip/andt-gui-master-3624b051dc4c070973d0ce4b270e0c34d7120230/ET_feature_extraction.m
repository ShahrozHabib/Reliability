function [ Feature_Extracted_Boxes ] = ET_feature_extraction( roiboxes, calibrated_data, varargin )
% This is the 7th fucnction and it is used to extract features from ROI.

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
    axes (disp_h);
    axis on;      
else
    % disp_h = 1; 
end


s_bit=1;
    num_boxes=size(roiboxes,1);
    
     for n=1:num_boxes
        %------------------Extract ROI Data-----------------------------------%

interest_data.outim_200k = calibrated_data.outim_200k(roiboxes(n,1):roiboxes(n,2), roiboxes(n,3):roiboxes(n,4));
interest_data.outre_200k = calibrated_data.outre_200k(roiboxes(n,1):roiboxes(n,2), roiboxes(n,3):roiboxes(n,4));
interest_data.outim_100k = calibrated_data.outim_100k(roiboxes(n,1):roiboxes(n,2), roiboxes(n,3):roiboxes(n,4));
interest_data.outre_100k = calibrated_data.outre_100k(roiboxes(n,1):roiboxes(n,2), roiboxes(n,3):roiboxes(n,4));

%%............Field # 1.................

Feature_Extracted_Boxes(n).roi = roiboxes(n,:);


%.............Feature: Max Vert Axial First Channel.................%


Feature_Extracted_Boxes(n).A200_maxVert = max(max(interest_data.outim_200k));

%..............Feature: Max Mag Axial First Channel................%
        Feature_Extracted_Boxes(n).A200_maxMag = ...
max(max(abs((interest_data.outre_200k) + sqrt(-1)*interest_data.outim_200k))); 

    
            % Location of Maximum Vertical Component.
            [a b] = find(interest_data.outim_200k == Feature_Extracted_Boxes(n).A200_maxVert);

%-----------Relative Row Column Values[Considering the entire Image]------------------------%
            row = roiboxes(n,1)+a(1)-1; %Check OK
            col = roiboxes(n,3)+b(1)-1; %Check OK
%-------------------------------------------------------------%

%------------Phase at MAX VERT Computation-------------------------%

ph_first = angle(interest_data.outre_200k(a(1),b(1))+sqrt(-1)*interest_data.outim_200k(a(1),b(1)));
ph_second = angle(interest_data.outre_100k(a(1),b(1))+sqrt(-1)*interest_data.outim_100k(a(1),b(1)));

 %---------------Phase Conversion to ASME Std--------------------------%
 
  Feature_Extracted_Boxes(n).A200_PhsMxVert = floor(180-ph_first*180/pi); 
  Feature_Extracted_Boxes(n).A100_PhsMxVert = floor(180-ph_second*180/pi);

   
     end





end

