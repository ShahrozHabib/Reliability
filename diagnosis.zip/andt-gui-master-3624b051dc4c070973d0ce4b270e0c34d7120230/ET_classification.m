function [ features ] = ET_classification( Feature_Extracted_Boxes, varargin )
%UNTITLED2 Summary of this function goes here

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
    axes (disp_h);
    axis on;      
else
    % disp_h = 1; 
end

features= Feature_Extracted_Boxes;

     
     for i=1:length(features);
    isDefect = '';
    if((features(i).A200_maxVert >= 20) && (features(i).A200_maxMag <= 130)) ;
        %if( (features(i).A300_PhsMxVert  > params.A300_PhsMxVert_low) && (features(i).A300_PhsMxVert  < params.A300_PhsMxVert_high))
            if( (features(i).A200_PhsMxVert  > 20) && (features(i).A200_PhsMxVert  < 150))                              % values taken from SPfiles Arkanas
                if( (features(i).A100_PhsMxVert  > 0) && (features(i).A100_PhsMxVert  < 150))                        % values taken from SPfiles Arkanas
                    %if(CL_OD == 1)  % what is CL_OD?                                                                         % values taken from SPfiles Arkanas
                        %if((features(i).A300_PhsMxVert - features(i).A200_PhsMxVert) > params.A300_200)                      
                             if((features(i).A200_PhsMxVert - features(i).A100_PhsMxVert) >= -10)  %% values taken from SPfiles Arkanas 
                                 isDefect = 'A';
                            end
                        %end
                    %end
                    %if( (params.CL_OD == 0) || (params.CL_OD == 2) )
                        %if((features(i).A100_PhsMxVert - features(i).A200_PhsMxVert) > params.A100_200)
                            %if((features(i).A200_PhsMxVert - features(i).A300_PhsMxVert) >= params.A200_300)
                                %isDefect = 'A';
                            %end                        
                        %end
                    %end
                end
            end
        %end
    end
  
    
    isDefect = [isDefect];
    if(strcmp(isDefect,'A'))
        isDefect = 'DEFECT';
    %elseif(strcmp(isDefect,'C'))
        %isDefect = 'SCI';
    %elseif(strcmp(isDefect, 'AC'))
        %isDefect = 'VOL';
    else 
        isDefect = 'NO DEFECT';
    end 
    features(i).isDefect = isDefect;
end




end

