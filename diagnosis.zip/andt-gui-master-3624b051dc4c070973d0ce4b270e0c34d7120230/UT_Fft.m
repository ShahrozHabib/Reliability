function UT_Fft(A,D, varargin)

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    disp_h = varargin{1};
    axis on;
    if (optargin == 2)
        k = varargin{2}; % Get Location Number
    else
        k = 1;
    end
else
    % disp_h = 1; 
end

subplot(1,1,1);
% for k=1:4
fr=0:10e6/256:10e6-1;
F=fft(A(:,k),256);
%subplot(5,5,k)

F_abs = abs(F);
F_n = F_abs./max(F_abs); % Normalize F
fr_n = fr./max(fr); % Normlize fr

% plot(fr,fftshift(abs(F)));
plot(fr_n,fftshift(F_n));
title(['Frequency Transform of A scan for Location # ' num2str(k)]);
xlabel('Normalized Frequency');
ylabel('Normalized Amplitude');
grid on;
%plot(tt,A(:,k))
% pause
% end