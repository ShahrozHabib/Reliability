function varargout = Prog_GUI_DB_Plot(varargin)
% PROG_GUI_DB_PLOT MATLAB code for Prog_GUI_DB_Plot.fig
%      PROG_GUI_DB_PLOT, by itself, creates a new PROG_GUI_DB_PLOT or raises the existing
%      singleton*.
%
%      H = PROG_GUI_DB_PLOT returns the handle to a new PROG_GUI_DB_PLOT or the handle to
%      the existing singleton*.
%
%      PROG_GUI_DB_PLOT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROG_GUI_DB_PLOT.M with the given input arguments.
%
%      PROG_GUI_DB_PLOT('Property','Value',...) creates a new PROG_GUI_DB_PLOT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Prog_GUI_DB_Plot_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Prog_GUI_DB_Plot_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Prog_GUI_DB_Plot

% Last Modified by GUIDE v2.5 29-Mar-2016 15:46:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Prog_GUI_DB_Plot_OpeningFcn, ...
                   'gui_OutputFcn',  @Prog_GUI_DB_Plot_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Prog_GUI_DB_Plot is made visible.
function Prog_GUI_DB_Plot_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Prog_GUI_DB_Plot (see VARARGIN)

% Display backgrounds
set (hObject,'CurrentAxes',handles.backgr);
[imagedata imagemap] = imread('backgr.bmp');
imshow (imagedata, imagemap);
axis(handles.backgr,'normal');

set (hObject,'CurrentAxes',handles.display_plot);
nust_logo = imread ('nust.jpg');
I2 = flipdim(nust_logo ,2);           %# horizontal flip
I3 = flipdim(I2 ,1);                  %# vertical flip
I4 = flipdim(I3,2);                   %# horizontal+vertical flip
imshow (I4);

% Choose default command line output for Prog_GUI_DB_Plot
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
end

set (hObject,'Name','Aerospace NDT Prognostics GUI - Database Plot');
% set (handles.Next_Btn, 'enable', 'off')


handles.INS=getappdata(0,'NoIns');
set(handles.slider1, 'Min', 1);
set(handles.slider1, 'Max', handles.INS);
set(handles.slider1, 'Value', 1);
set(handles.slider1, 'SliderStep', [1/(handles.INS-1) 1/(handles.INS-1)]);

setappdata(0,'background',handles.backgr);
setappdata(0,'display_plot',handles.display_plot);

set(handles.Desc_Text1,'string','Plot of Loaded DB File');
set(handles.Desc_Text2,'string','Press the Plot button to create a plot of the file loaded in the previous GUI. Move the slider to obersve the plot at different values of Flight Cycles. Press Next to move forward.');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Prog_GUI_DB_Plot wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Prog_GUI_DB_Plot_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Three_Dim_Plot.
function Three_Dim_Plot_Callback(hObject, eventdata, handles)
% hObject    handle to Three_Dim_Plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% plot_3d_dbfile;
% set (handles.Next_Btn, 'enable', 'on')
sliderValue=1;
set(handles.Tot_Cycles,'String',handles.INS)
set(handles.Cycle_No,'String',sliderValue)
setappdata(0,'sliderValue',sliderValue);
plot_3d_dbfile;


% --- Executes on button press in Next_Btn.
function Next_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Next_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Prog_GUI_Pre_Set (handles.igc);


% --- Executes on button press in Back_Btn.
function Back_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Back_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Prog_GUI_LoadGenDB(handles.igc);


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sliderValue = get(handles.slider1,'Value');
set(handles.Cycle_No,'String',sliderValue);
setappdata(0,'sliderValue',sliderValue);
plot_3d_dbfile;



% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function Desc_Text2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Desc_Text2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function Desc_Text1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Desc_Text1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
