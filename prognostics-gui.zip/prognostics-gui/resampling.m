function [xkj,wkj,parentj]=resampling(xki,wki,resamplingScheme);
%resampling algorithm
%xki: Predicted samples derived from time step k
%wki: importance weights from time step k+1
%xkj: Resampled particles
%wkj: new weights
%parentj: parent index of each resampled particle
%resamplingScheme: 1, 2, 3, or 4; indicates which method to use for
%resampling
%Takes in column vectors and returns row vectors

% Used in parent as: [xki,wki,parentj]=resampling(xkj,wkj,resamplingscheme);

Ns=length(xki);

%Pick a resampling method:
switch (resamplingScheme)
    case 1
        parentj = residualR(1:Ns,wki);        % Residual resampling.
        xkj = xki(parentj)'; % Keep particles with resampled indices
        wkj = ones(1,Ns)/Ns;
    case 2
        parentj = deterministicR(1:Ns,wki);   % Minimum variance resampling.
        xkj = xki(parentj)'; % Keep particles with resampled indices
        wkj = ones(1,Ns)/Ns;
    case 3
        parentj = multinomialR(1:Ns,wki);     % Multinomial resampling.
        xkj = xki(parentj)'; % Keep particles with resampled indices
        wkj = ones(1,Ns)/Ns;
    otherwise
        %Based on code in PF tutorial by arulampalam et al
        %step 1: initialize CDF
        c=zeros(1,Ns);
        %step 2: construct CDF
        %c = cumsum(wki');
        for i=2:Ns
            c(i) = c(i-1)+wki(i);
        end

        %step 3: start at CDF bottom:
        i=1;
        %step 4: draw starting point
        u=zeros(1,Ns);
        u1 = rand(1,1)/Ns;
        u = 0:Ns-1; u = u/Ns;
        u=u+u1;

        %step 5: loop:
        for j=1:Ns
            %move along CDF
            %     u(j) = u1+(j-1)/Ns;
            while u(j) > c(i)
                i=i+1;
                %         if i > Ns
                %             i=Ns;
                %             break;
                %         end
            end
            %assign sample, weight and parent:
            xkj(j) = xki(i);
            wkj(j) = 1/Ns;
            parentj(j) = i;
        end
end;



%return;
return;
%end function resampling()
