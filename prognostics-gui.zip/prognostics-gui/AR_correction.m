function  corr_meas = AR_correction (pr_meas, data_limit, actual_data, P_magn , tr_cycles, rul_resolution, nfs)
% AR Correction: it takes the predicted measurements from PF, observation data(measurements), measurement polynomial, required resolution and predict
% the Future States (with correction) with respect to number of cycles
% Syntax:   corr_meas = AR_correction (pr_meas, data_limit, actual_data, P_magn , tr_cycles, rul_resolution, nfs)
% Argument: 
%           pr_meas (measurements predicted from PF)
%           data_limit (acts as the limit for obtaining normalized states)
%           actual_data (Data points)
%           P_magn (measurement equation polynomial for the actual_data)
%           tr_cycles (number of cycles for training index) should be at
%           maximum equal to maximum number of observation cycles
%           rul_resolution (step size of predicted states in number of cycles)
%           nfs (Number of future states to be predicted)
% Returns:  corr_meas (Estimated States and Predicted States with correction)
%           
% Engineer: Taha Ali, Waleed Bin Yousuf
% Date:     06 August 2015

% Constants / Parameters
x=dlmread('Settings.txt'); 
Min_err = x(10); % Minimum error below which the difference will be taken as zero.
order=x(11);
method='fb';

ti=floor(tr_cycles/rul_resolution);

xx = polyval(P_magn,actual_data./data_limit);

for i=1:1:length(pr_meas(:,1))

        %ar implementation on state model and statemodel+measurement update
        %xx_ar=iddata(xx(:,1:15)'-xx_ar');
        %pr_meas = int_dp./limit;

        index = 1:ti;
        data_ar=xx(i,index)'-pr_meas(i,index)'
        data_ar(abs(data_ar)<Min_err)=0;

        xx_ar = iddata(data_ar);                   
        [N_ar, ny_ar, nu_ar] = size(xx_ar);          % ny: no. of output channel, nu:no.of input channel, N:no.of series data points
        zer = iddata(zeros(nfs+1,ny_ar),zeros(nfs+1,nu_ar),xx_ar.Ts);
        yz_ar = [xx_ar; zer];


        % Build model
        mb_ar = ar(xx_ar,order,method);

        % Perform prediction
        yft = predict(mb_ar,yz_ar,nfs,'e');

        yft_op = yft.OutputData'; % AR predicted correction factor

        corr_meas(i,:) = xx(i,1:ti+nfs+1)+abs(yft_op); % PF predicted states corrected with AR predicted correction factor (in normalized depths)
end
% corr_meas(corr_meas>1)=1;