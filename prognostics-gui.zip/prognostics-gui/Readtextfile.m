function [ w,l,t,cycles ] = Readtextfile()
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
myFile = getappdata(0,'fileName'); % to receive variables that were passed
fid= fopen(myFile);
w=csvread(myFile,0,0,[0,0,1,0]); %Number of instants
w=w(1,1);
setappdata(0, 'NoIns',w);

% for i=1:1:w;
% cycles=csvread('disp5.txt',1,0,[1,0,1,w]);
% end
for i=1:1:w;
% l=csvread(myFile,((8*i)-7),(8*i))
l(i,:)=csvread(myFile,1,8*(i-1),[1 8*(i-1) 1 8*i-1]);
% transposet(j,:)
end
l=transpose(l);
setappdata(0,'length',l) % to pass variables between GUIs
for j=1:1:w;
% l=csvread(myFile,((8*i)-7),(8*i))
t(j,:)=csvread(myFile,2,8*(j-1),[2 8*(j-1) 2 8*j-1]);
end
t=transpose(t);
setappdata(0,'thickness',t) % to pass variables between GUIs
for i=1:1:w;
cycles=csvread(myFile,3,0,[3,0,3,i-1]);
end
cycles;
lastcycle=cycles(w);
setappdata(0,'lastcycle',lastcycle)
setappdata(0,'cyc',cycles) % to pass variables between GUIs
sheetthickness=csvread(myFile,4,0,[4,0,4,0]);
setappdata(0,'sheet',sheetthickness) % to pass variables between GUIs
lengthlimit=csvread(myFile,5,0,[5,0,5,0]);
setappdata(0,'llimit',lengthlimit) % to pass variables between GUIs
day=csvread(myFile,6,0,[6,0,6,0]);
setappdata(0,'day',day) % to pass variables between GUIs
month=csvread(myFile,7,0,[7,0,7,0]);
setappdata(0,'month',month) % to pass variables between GUIs
year=csvread(myFile,8,0,[8,0,8,0]);
setappdata(0,'year',year) % to pass variables between GUIs
% type=csvread(myFile,9,0,[9,0,9,0]);
% setappdata(0,'type',type) % to pass variables between GUIs
% regno=csvread(myFile,10,0,[10,0,10,0]);
% setappdata(0,'regno',regno) % to pass variables between GUIs
% rib=csvread(myFile,11,0,[11,0,11,0]);
% setappdata(0,'rib',rib) % to pass variables between GUIs
% stringer=csvread(myFile,12,0,[12,0,12,0]);
% setappdata(0,'stringer',stringer) % to pass variables between GUIs

for i=1:1:w;
fh=csvread(myFile,13,0,[13,0,13,i-1]);
end
setappdata(0,'fh',fh) % to pass variables between GUIs
%C = strsplit(data,', ')
%C = textread(myFile, '%s','Lengths', '\n');
%C =fscanf(fid, '%f%s%s%f%f%s%s%f%f\r\n ');
%test_main;
%call_3d
% csk_plot_3d;
fclose(fid);
end 

