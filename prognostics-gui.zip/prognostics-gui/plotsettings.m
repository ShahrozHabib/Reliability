function varargout = plotsettings(varargin)
% plotsettings MATLAB code for plotsettings.fig
%      plotsettings, by itself, creates a new plotsettings or raises the existing
%      singleton*.
%
%      H = plotsettings returns the handle to a new plotsettings or the handle to
%      the existing singleton*.
%
%      plotsettings('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in plotsettings.M with the given input arguments.
%
%      plotsettings('Property','Value',...) creates a new plotsettings or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before plotsettings_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to plotsettings_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help plotsettings

% Last Modified by GUIDE v2.5 29-Mar-2016 16:06:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @plotsettings_OpeningFcn, ...
                   'gui_OutputFcn',  @plotsettings_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before plotsettings is made visible.
function plotsettings_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to plotsettings (see VARARGIN)

% Display backgrounds
set (hObject,'CurrentAxes',handles.backgr);
imshow ('backgr.bmp');
axis(handles.backgr,'normal');

% Choose default command line output for plotsettings
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
end

set (hObject,'Name','Aerospace NDT Prognostics GUI - Advanced Plot Settings');

% UIWAIT makes plotsettings wait for user response (see UIRESUME)
% uiwait(handles.figure1);
%first check the existence of the file.
%if file not present create a file and load zeros.
if  exist('Settings.txt','file')
data=dlmread('Settings.txt');  
set(handles.Coeff_SFT_Text,'String',data(1));
set(handles.Scaling_Const_Text,'String',data(2));
set(handles.No_Samples_Text,'String',data(3));
set(handles.Sig_Noise_Text,'String',data(4));
set(handles.csk_edge_Text,'String',data(5));
set(handles.max_angle_Text,'String',data(6));
set(handles.R_min_Text,'String',data(7));
set(handles.Meshscale_Text,'String',data(8));
set(handles.Max_axis_Text,'String',data(9));
set(handles.Min_err_Text,'String',data(10));
set(handles.AR_order_Text,'String',data(11));
handles.Angle=45;
else
    fid=fopen('Settings.txt','w');
    def=[1.786,0.4,1000,10,6.35,360,6.35,4,400,0.001,6];
    dlmwrite('Settings.txt',def);
end

set(handles.Desc_Text1,'string','Advanced Settings');
set(handles.Desc_Text2,'string','These parameters control the operation of the prognostic alorithms. Click Default to reset the values to their default presets. Click OK to return to previous GUI.');
set(handles.Desc_Text3,'string','Csk_edge:');
set(handles.Desc_Text4,'string','The dimension of the countersunk rivet hole from the center (radius of the CSK rivet hole). It must be in millimeters (mm).');
set(handles.Desc_Text5,'string','p:');
set(handles.Desc_Text6,'string','Coefficient for State Transition Model which controls the variability in the prediction of future states.');
% Update handles structure
guidata(hObject, handles);



% --- Outputs from this function are returned to the command line.
function varargout = plotsettings_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function Coeff_SFT_Text_Callback(hObject, eventdata, handles)
% hObject    handle to Coeff_SFT_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Coeff_SFT_Text as text
%        str2double(get(hObject,'String')) returns contents of Coeff_SFT_Text as a double


% --- Executes during object creation, after setting all properties.
function Coeff_SFT_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Coeff_SFT_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Scaling_Const_Text_Callback(hObject, eventdata, handles)
% hObject    handle to Scaling_Const_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Scaling_Const_Text as text
%        str2double(get(hObject,'String')) returns contents of Scaling_Const_Text as a double


% --- Executes during object creation, after setting all properties.
function Scaling_Const_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Scaling_Const_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function No_Samples_Text_Callback(hObject, eventdata, handles)
% hObject    handle to No_Samples_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of No_Samples_Text as text
%        str2double(get(hObject,'String')) returns contents of No_Samples_Text as a double


% --- Executes during object creation, after setting all properties.
function No_Samples_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to No_Samples_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Sig_Noise_Text_Callback(hObject, eventdata, handles)
% hObject    handle to Sig_Noise_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sig_Noise_Text as text
%        str2double(get(hObject,'String')) returns contents of Sig_Noise_Text as a double


% --- Executes during object creation, after setting all properties.
function Sig_Noise_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sig_Noise_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function csk_edge_Text_Callback(hObject, eventdata, handles)
% hObject    handle to csk_edge_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of csk_edge_Text as text
%        str2double(get(hObject,'String')) returns contents of csk_edge_Text as a double


% --- Executes during object creation, after setting all properties.
function csk_edge_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to csk_edge_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function csk_edge_i_Text_Callback(hObject, eventdata, handles)
% hObject    handle to csk_edge_i_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of csk_edge_i_Text as text
%        str2double(get(hObject,'String')) returns contents of csk_edge_i_Text as a double


% --- Executes during object creation, after setting all properties.
function csk_edge_i_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to csk_edge_i_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function max_angle_Text_Callback(hObject, eventdata, handles)
% hObject    handle to max_angle_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of max_angle_Text as text
%        str2double(get(hObject,'String')) returns contents of max_angle_Text as a double


% --- Executes during object creation, after setting all properties.
function max_angle_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to max_angle_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function R_min_Text_Callback(hObject, eventdata, handles)
% hObject    handle to R_min_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of R_min_Text as text
%        str2double(get(hObject,'String')) returns contents of R_min_Text as a double


% --- Executes during object creation, after setting all properties.
function R_min_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to R_min_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function R_min_i_Text_Callback(hObject, eventdata, handles)
% hObject    handle to R_min_i_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of R_min_i_Text as text
%        str2double(get(hObject,'String')) returns contents of R_min_i_Text as a double


% --- Executes during object creation, after setting all properties.
function R_min_i_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to R_min_i_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meshscale_Text_Callback(hObject, eventdata, handles)
% hObject    handle to Meshscale_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meshscale_Text as text
%        str2double(get(hObject,'String')) returns contents of Meshscale_Text as a double


% --- Executes during object creation, after setting all properties.
function Meshscale_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meshscale_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Max_axis_Text_Callback(hObject, eventdata, handles)
% hObject    handle to Max_axis_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Max_axis_Text as text
%        str2double(get(hObject,'String')) returns contents of Max_axis_Text as a double


% --- Executes during object creation, after setting all properties.
function Max_axis_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Max_axis_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in OK_Btn.
function OK_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to OK_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
word1=get(handles.Coeff_SFT_Text,'String');
word2=get(handles.Scaling_Const_Text,'String');
word3=get(handles.No_Samples_Text,'String');
word4=get(handles.Sig_Noise_Text,'String');
word5=get(handles.csk_edge_Text,'String');
word6=get(handles.max_angle_Text,'String');
word7=get(handles.R_min_Text,'String');
word8=get(handles.Meshscale_Text,'String');
word9=get(handles.Max_axis_Text,'String');
worda=get(handles.Min_err_Text,'String');
wordb=get(handles.AR_order_Text,'String');
M(1)=str2double(word1);
M(2)=str2double(word2);
M(3)=str2double(word3);
M(4)=str2double(word4);
M(5)=str2double(word5);
M(6)=str2double(word6);
M(7)=str2double(word7);
M(8)=str2double(word8);
M(9)=str2double(word9);
M(10)=str2double(worda);
M(11)=str2double(wordb);
filename='Settings.txt';
dlmwrite(filename,M);
setappdata(0,'SFTcoef',M(1));
setappdata(0,'Scaleconst',M(2));
setappdata(0,'samples',M(3));
setappdata(0,'signoise',M(4));
setappdata(0,'cskedge',M(5));
setappdata(0,'maxangle',M(6));
setappdata(0,'rmin',M(7));
setappdata(0,'Meshscale',M(8));
setappdata(0,'Maxaxis',M(9));
setappdata(0,'Minerror',M(10));
setappdata(0,'ARorder',M(11));
% setappdata(0, 'Angle_Step', handles.Angle); %Global angle step


Prog_GUI_Pre_Set(handles.igc);

% --- Executes on button press in Default_Btn.
function Default_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Default_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
def=[1.786,0.4,1000,10,6.35,360,6.35,4,400,0.001,6];
% for p=1:14
%     set(handles.ed(1),'String',def(p));
% end
set(handles.Coeff_SFT_Text,'String',def(1));
set(handles.Scaling_Const_Text,'String',def(2));
set(handles.No_Samples_Text,'String',def(3));
set(handles.Sig_Noise_Text,'String',def(4));
set(handles.csk_edge_Text,'String',def(5));
set(handles.max_angle_Text,'String',def(6));
set(handles.R_min_Text,'String',def(7));
set(handles.Meshscale_Text,'String',def(8));
set(handles.Max_axis_Text,'String',def(9));
set(handles.Min_err_Text,'String',def(10));
set(handles.AR_order_Text,'String',def(11));



function AR_method_Text_Callback(hObject, eventdata, handles)
% hObject    handle to AR_method_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of AR_method_Text as text
%        str2double(get(hObject,'String')) returns contents of AR_method_Text as a double


% --- Executes during object creation, after setting all properties.
function AR_method_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AR_method_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function AR_order_Text_Callback(hObject, eventdata, handles)
% hObject    handle to AR_order_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of AR_order_Text as text
%        str2double(get(hObject,'String')) returns contents of AR_order_Text as a double


% --- Executes during object creation, after setting all properties.
function AR_order_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AR_order_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Min_err_Text_Callback(hObject, eventdata, handles)
% hObject    handle to Min_err_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Min_err_Text as text
%        str2double(get(hObject,'String')) returns contents of Min_err_Text as a double


% --- Executes during object creation, after setting all properties.
function Min_err_Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Min_err_Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in Angle_PopUp.
function Angle_PopUp_Callback(hObject, eventdata, handles)
% hObject    handle to Angle_PopUp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Angle_PopUp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Angle_PopUp
contents = cellstr(get(hObject,'String'));
Angle_St =  contents{get(hObject, 'Value')}

assignin('base','Angle_St', Angle_St);
if (strcmp(Angle_St,'15'))
    handles.Angle = 15
    setappdata(0, 'Angle_Step', handles.Angle); %Global angle step
elseif (strcmp(Angle_St,'30'))
    handles.Angle = 30
    setappdata(0, 'Angle_Step', handles.Angle); %Global angle step
elseif (strcmp(Angle_St,'45'))
    handles.Angle = 45
    setappdata(0, 'Angle_Step', handles.Angle); %Global angle step
end
assignin('base','Angle', handles.Angle);





% --- Executes during object creation, after setting all properties.
function Angle_PopUp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Angle_PopUp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function uipanel6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
