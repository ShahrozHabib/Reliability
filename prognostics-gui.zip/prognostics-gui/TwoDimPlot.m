% function TwoDimPlot(int_ln, int_dp, pr_lengths, pr_depths, corr_meas_ln, corr_meas_dp, tr_cycles, rul_resolution, nfs)
background=getappdata(0,'background1');
plot=getappdata(0,'display_plot1');

int_ln=getappdata(0,'int_ln');
int_dp=getappdata(0,'int_dp');
pr_lengths=getappdata(0,'pr_lengths');
pr_depths=getappdata(0,'pr_depths');
corr_meas_ln=getappdata(0,'corr_meas_ln');
corr_meas_dp=getappdata(0,'corr_meas_dp');
tr_cycles=getappdata(0,'TC');
rul_resolution=getappdata(0,'RUL');
nfs=getappdata(0,'Future_States');
% angle_step=getappdata(0, 'Angle_Step');
angle_step=45;

Training_Index=tr_cycles/rul_resolution;
Eval_Bound=Training_Index+nfs; % Evaluation Boundary 
% Angle_Lns=getappdata(0,'sliderValueLn')
curr_row=getappdata(0,'curr_row');

% Row_no = Angle./angle_step + 1
axis on;
axes(plot);
stem(int_ln(curr_row,1:Eval_Bound),'fill','red','BaseValue',0);
hold on
stem(pr_lengths(curr_row,1:Eval_Bound),'fill','green','BaseValue',0,'Marker','+');
hold on
stem(corr_meas_ln(curr_row,1:Eval_Bound),'fill','blue','BaseValue',0,'Marker','*');
hold off
% hold on
% stem(int_dp(Angle_Dps+1,1:Eval_Bound));
% hold on
% stem(pr_depths(Angle_Dps+1,1:Eval_Bound));
% hold on
% stem(corr_meas_dp(Angle_Dps+1,1:Eval_Bound));