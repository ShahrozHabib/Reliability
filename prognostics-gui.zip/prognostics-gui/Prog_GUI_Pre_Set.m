function varargout = Prog_GUI_Pre_Set(varargin)
% PROG_GUI_PRE_SET MATLAB code for Prog_GUI_Pre_Set.fig
%      PROG_GUI_PRE_SET, by itself, creates a new PROG_GUI_PRE_SET or raises the existing
%      singleton*.
%
%      H = PROG_GUI_PRE_SET returns the handle to a new PROG_GUI_PRE_SET or the handle to
%      the existing singleton*.
%
%      PROG_GUI_PRE_SET('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROG_GUI_PRE_SET.M with the given input arguments.
%
%      PROG_GUI_PRE_SET('Property','Value',...) creates a new PROG_GUI_PRE_SET or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Prog_GUI_Pre_Set_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Prog_GUI_Pre_Set_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Prog_GUI_Pre_Set

% Last Modified by GUIDE v2.5 29-Mar-2016 16:23:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Prog_GUI_Pre_Set_OpeningFcn, ...
                   'gui_OutputFcn',  @Prog_GUI_Pre_Set_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Prog_GUI_Pre_Set is made visible.
function Prog_GUI_Pre_Set_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Prog_GUI_Pre_Set (see VARARGIN)

% Display backgrounds
set (hObject,'CurrentAxes',handles.backgr);
imshow ('backgr.bmp');
axis(handles.backgr,'normal');

% Choose default command line output for Prog_GUI_DB_Plot
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
end

set (hObject,'Name','Aerospace NDT Prognostics GUI - Prediction Settings');
% set (handles.Next_Btn, 'enable', 'off')

handles.FS=3;
handles.RUL=1000;
handles.TC=22000;
handles.m=0;
handles.SThick=0;
handles.LengthLimit=0;

a=getappdata(0, 'Value');
set(handles.Sheet_Tickness_Tx, 'String', a);

% Choose default command line output for Prog_GUI_Pre_Set
handles.output = hObject;
 myFile = getappdata(0,'fileName'); % to receive variables that were passed
 skinth=csvread(myFile,4,0,[4,0,4,0]);
 set(handles.Sheet_Tickness_Tx,'String',skinth); % Sheet Thickness print

 ll=csvread(myFile,5,0,[5,0,5,0]);
 set(handles.Length_Lim_Tx,'String',ll);
% Update handles structure
guidata(hObject, handles);

set(handles.No_Future_States_Tx,'String',handles.FS);
set(handles.RUL_Res_Tx, 'String', handles.RUL);
set(handles.TrainCyc_Tx, 'String', handles.TC);

set(handles.Desc_Text1,'string','Prediction Settings');
set(handles.Desc_Text2,'string','The values (editable) are set at default for optimum results. Note that Training Cycles are fozen at a specific value in the Real Mode. RUL Resolution must always be a multiple of 500. Click the Advanced Settings button to observe more parameters. Click Next to proceed.') ;
set(handles.Desc_Text3,'string','Training Cycles:');
set(handles.Desc_Text4,'string','Defines the training cycle till which the data is available.');
% UIWAIT makes Prog_GUI_Pre_Set wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Prog_GUI_Pre_Set_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function Length_Lim_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Length_Lim_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Length_Lim_Tx as text
%        str2double(get(hObject,'String')) returns contents of Length_Lim_Tx as a double
set(handles.Desc_Text3,'string','Skin Thickness:');
set(handles.Desc_Text4,'string','Maximum Sheet thickness in which the rivet is fixed. It must be in millimeters (mm). ');


% --- Executes during object creation, after setting all properties.
function Length_Lim_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Length_Lim_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function No_Future_States_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to No_Future_States_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of No_Future_States_Tx as text
%        str2double(get(hObject,'String')) returns contents of No_Future_States_Tx as a double
set(handles.Desc_Text3,'string','Length Limit:');
set(handles.Desc_Text4,'string','Maximum allowable dimension for the flaw growth around the rivet hole. It must be in millimeters (mm).');


% --- Executes during object creation, after setting all properties.
function No_Future_States_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to No_Future_States_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function RUL_Res_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to RUL_Res_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RUL_Res_Tx as text
%        str2double(get(hObject,'String')) returns contents of RUL_Res_Tx as a double
set(handles.Desc_Text3,'string','Number of Future States:');
set(handles.Desc_Text4,'string','NFS is the Number of Future States which the user wants to predict (Note: NFS is the multiple of RUL resolution)');


% --- Executes during object creation, after setting all properties.
function RUL_Res_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RUL_Res_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TrainCyc_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to TrainCyc_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TrainCyc_Tx as text
%        str2double(get(hObject,'String')) returns contents of TrainCyc_Tx as a double
set(handles.Desc_Text3,'string','RUL Resolution:');
set(handles.Desc_Text4,'string','RUL Resolution is the difference in the prediction cycles. For instance: If the user needs to predict the future states after every 1000 loading cycles then the RUL resolution should be 1000.');


% --- Executes during object creation, after setting all properties.
function TrainCyc_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TrainCyc_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Next_Btn.
function Next_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Next_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a=get(handles.No_Future_States_Tx,'String');
handles.FS=str2double(a);
setappdata(0,'Future_States',handles.FS);
a=get(handles.RUL_Res_Tx,'String');
handles.RUL=str2double(a);
setappdata(0,'RUL',handles.RUL);
a=get(handles.TrainCyc_Tx,'String');
handles.TC=str2double(a);
setappdata(0,'TC',handles.TC);
a=get(handles.Sheet_Tickness_Tx,'String');
handles.SThick=str2double(a);
setappdata(0,'Max_Sheet_Thickness',handles.SThick);
a=get(handles.Length_Lim_Tx,'String');
handles.LengthLimit=str2double(a);
setappdata(0,'Length_Limit',handles.LengthLimit);
Adv_Setting=dlmread('Settings.txt');
setappdata(0,'Adv_Setting',Adv_Setting);

h = msgbox('Loading prognostic algorithms, please wait.','Success');
 Prog_GUI_ARCorr (handles.igc);






% --- Executes on button press in Back_Btn.
function Back_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Back_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Prog_GUI_DB_Plot(handles.igc);


% --- Executes on button press in Adv_Setting_Btn.
function Adv_Setting_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Adv_Setting_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
plotsettings(handles.igc);


% --- Executes during object creation, after setting all properties.
function Mode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when selected object is changed in Mode.
function Mode_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in Mode 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

selection = get(handles.Mode,'SelectedObject');
mode = get(selection, 'String');

switch mode
    case 'Evaluation Mode'
        set(handles.TrainCyc_Tx, 'String', handles.TC);
        set(handles.TrainCyc_Tx, 'Enable', 'on')
    case 'Real Mode'
        lastcycle=getappdata(0,'lastcycle');
        lastcycle=lastcycle/1000;
        lastcycle=floor(lastcycle);
        lastcycle=lastcycle*1000
        set(handles.TrainCyc_Tx, 'String', lastcycle)
        set(handles.TrainCyc_Tx, 'Enable', 'off')
end



function Sheet_Tickness_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Sheet_Tickness_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sheet_Tickness_Tx as text
%        str2double(get(hObject,'String')) returns contents of Sheet_Tickness_Tx as a double
Skin_Th_Tx=getappdata(0, 'Skin_Th_Tx');
Skin_Th_Tx=num2str(Skin_Th_Tx);
set(handles.m,'String',Skin_Th_Tx);
dip(handles);

% set(handles.Next_Btn, 'enable', 'on');


% --- Executes during object creation, after setting all properties.
function Sheet_Tickness_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sheet_Tickness_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function backgr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to backgr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate backgr
