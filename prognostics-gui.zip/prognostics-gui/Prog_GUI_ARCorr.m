function varargout = Prog_GUI_ARCorr(varargin)
% PROG_GUI_ARCORR MATLAB code for Prog_GUI_ARCorr.fig
%      PROG_GUI_ARCORR, by itself, creates a new PROG_GUI_ARCORR or raises the existing
%      singleton*.
%
%      H = PROG_GUI_ARCORR returns the handle to a new PROG_GUI_ARCORR or the handle to
%      the existing singleton*.
%
%      PROG_GUI_ARCORR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROG_GUI_ARCORR.M with the given input arguments.
%
%      PROG_GUI_ARCORR('Property','Value',...) creates a new PROG_GUI_ARCORR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Prog_GUI_ARCorr_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Prog_GUI_ARCorr_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Prog_GUI_ARCorr

% Last Modified by GUIDE v2.5 29-Mar-2016 16:49:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Prog_GUI_ARCorr_OpeningFcn, ...
                   'gui_OutputFcn',  @Prog_GUI_ARCorr_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Prog_GUI_ARCorr is made visible.
function Prog_GUI_ARCorr_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Prog_GUI_ARCorr (see VARARGIN)

% Display backgrounds
set (hObject,'CurrentAxes',handles.backg);
imshow ('backgr.bmp');
axis(handles.backg,'normal');

set (hObject,'CurrentAxes',handles.disp_plot);
nust_logo = imread ('nust.jpg');
I2 = flipdim(nust_logo ,2);           %# horizontal flip
I3 = flipdim(I2 ,1);                  %# vertical flip
I4 = flipdim(I3,2);                   %# horizontal+vertical flip
imshow (I4);

% Choose default command line output for Prog_GUI_ARCorr
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
end

set (hObject,'Name','Aerospace NDT Prognostics GUI - Prognosis');

% x=45;
% handles.AngleStep=360/x;
set(handles.Two_Dim_Plot_Lengths, 'Enable', 'on')
set(handles.Two_Dim_Plot_Dep, 'Enable', 'on')
set(handles.Three_Dim_Plot_PF, 'Enable', 'off')
set(handles.Three_Dim_Plot_AR, 'Enable', 'off')
set(handles.slider1, 'Enable', 'on')
set(handles.slider3, 'Enable', 'off')

lengths=getappdata(0,'length');    
thickness=getappdata(0,'thickness');
nfs=getappdata(0,'Future_States');
total_rows = size(lengths,1);
set(handles.slider1, 'Min', 1);
set(handles.slider1, 'Max', total_rows);
set(handles.slider1, 'Value', 1);
set(handles.slider1, 'SliderStep', [1/(total_rows-1) 1/(total_rows-1)]);

set(handles.slider3, 'Min', 1);
set(handles.slider3, 'Max', nfs+1);
set(handles.slider3, 'Value', 1);
set(handles.slider3, 'SliderStep', [1/(nfs) 1/(nfs)]);

setappdata(0,'background1',handles.backg);
setappdata(0,'display_plot1',handles.disp_plot);

Main_Call_Prognosis;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Prog_GUI_ARCorr wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Prog_GUI_ARCorr_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Report_Gen_Btn.
function Report_Gen_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Report_Gen_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[Report_filename, Report_pathname]= uiputfile('*.txt','Save Report as'); % Prompt User for Saving Report file
if Report_pathname
    
    % Open File for Reporting Important Parameters
  
    fid = fopen(cat(2,Report_pathname,Report_filename),'w');

    if (fid == -1), 
        error('File not opened!'); 
    end
    
NoIns=getappdata(0, 'NoIns');
length=getappdata(0,'length');
depth=getappdata(0,'thickness');   
fc=getappdata(0,'cyc');   
SkinTh=getappdata(0,'sheet');
LengthLimit=getappdata(0,'llimit');
Day=getappdata(0,'day');
Month=getappdata(0,'month');
Year=getappdata(0,'year');
Type=getappdata(0,'type');
RegNo=getappdata(0,'regno');
Rib=getappdata(0,'rib');
Stringer=getappdata(0,'stringer');
fh=getappdata(0,'fh');

    fprintf(fid,'Final Report\r\n');
    fprintf(fid,'Engineers: Taha Ali, Waleed Bin Yousuf, Kiran Aslam\r\n');
    fprintf(fid,'Developers: Salar Bin Javaid, Ahmad Ali Qureshi\r\n');
    fprintf(fid,'Date: %d-%d-%d\r\n\r\n', Day, Month, Year);
   fprintf(fid,'Type: %s\r\n',Type);
   fprintf(fid,'Registration Number: %s\r\n',RegNo);
%    
%    selection = get(handles.uipanel2,'SelectedObject');
%    handles.LR = get(selection, 'String');
%    fprintf(fid,'Wing: %s\r\n',handles.LR);
%    
   fprintf(fid,'Stringer Number: %s\r\n',Stringer);
   fprintf(fid,'Rib: %s\r\n',Rib);
   fprintf(fid,'Skin thickness: %d\r\n',SkinTh);
   fprintf(fid,'Length Limit: %d\r\n\r\n',LengthLimit); % Length Limit
   fprintf(fid,'Number of Instants: %d\r\n\',NoIns); % No of instants
   
   fprintf (fid,'\r\n');
   fprintf(fid,'::Data Entries:: \r\n');
%     for i=1:1:8
%         fprintf (fid,'%d\r\n',de(i,:));
%    end

 fprintf(fid,'Flying hours: \r\n');
 fprintf(fid,'%d,',fh);
 fprintf (fid, '\r\n\r\n');
 fprintf(fid,'Flying cycles: \r\n');
 fprintf(fid,'%d,',fc);
 fprintf (fid, '\r\n\r\n');
   fprintf (fid,'Lengths: \r\n');
   fprintf (fid,'%d,',length);
   fprintf (fid, '\r\n\r\n');
   fprintf (fid,'Thickness: \r\n');
   fprintf (fid,'%d,',depth);
   fprintf (fid,'\r\n');
%  fprintf(fid,'%d,',handles.csk.fc);

fprintf (fid,'\r\n');
    

end    


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
% sliderValueLn = get(handles.slider1,'Value')
% setappdata(0,'sliderValueLn',sliderValueLn);
curr_row = get(handles.slider1,'Value');
% curr_row = floor(sliderValue);
setappdata(0,'curr_row',curr_row);
Enable_Lengths=getappdata(0,'Enable_Lengths');
angles=45*curr_row;
set(handles.Curr_Lens,'String',angles);
if Enable_Lengths==1
    TwoDimPlot
else if Enable_Lengths==0
        TwoDimPlot_Depths
    end
end

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



% --- Executes on button press in Back_Btn.
function Back_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Back_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Prog_GUI_Pre_Set(handles.igc);

% --- Executes when selected object is changed in Compute_Panel.
function Compute_Panel_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in Compute_Panel 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
selection = get(handles.Compute_Panel,'SelectedObject');
mode = get(selection, 'String');

switch mode
    case '2 D Plot'
         set(handles.Two_Dim_Plot_Lengths, 'Enable', 'on')
         set(handles.Two_Dim_Plot_Dep, 'Enable', 'on')
         set(handles.Three_Dim_Plot_PF, 'Enable', 'off')
         set(handles.Three_Dim_Plot_AR, 'Enable', 'off')
         set(handles.slider1, 'Enable', 'on')
         set(handles.slider3, 'Enable', 'off')
    case '3 D Plot'
         set(handles.Three_Dim_Plot_PF, 'Enable', 'on')
         set(handles.Three_Dim_Plot_AR, 'Enable', 'on')
         set(handles.Two_Dim_Plot_Lengths, 'Enable', 'off')
         set(handles.Two_Dim_Plot_Dep, 'Enable', 'off')
         set(handles.slider3, 'Enable', 'on')
         set(handles.slider1, 'Enable', 'off')
end


% --- Executes during object creation, after setting all properties.
function Compute_Panel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Compute_Panel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in Three_Dim_Plot_PF.
function Three_Dim_Plot_PF_Callback(hObject, eventdata, handles)
% hObject    handle to Three_Dim_Plot_PF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.slider3, 'Value', 1);
ThreeDSlider=1;
setappdata(0,'ThreeDSlider',ThreeDSlider);
Enable_AR=0;
setappdata(0,'Enable_AR',Enable_AR);
plot_pf_3D;
tr_cycles=getappdata(0,'TC');
rul_resolution=getappdata(0,'RUL');
time_index = floor((tr_cycles+(1-1)*rul_resolution)/rul_resolution);
t=time_index*1000;
set(handles.Cyc_Disp_Text,'String',t);


% --- Executes on button press in Two_Dim_Plot_Lengths.
function Two_Dim_Plot_Lengths_Callback(hObject, eventdata, handles)
% hObject    handle to Two_Dim_Plot_Lengths (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% len=getappdata(0,'length'); 
% rows = size(len,1);
% set(handles.Total_Lens,'String',rows);
set(handles.slider1, 'Value', 1);
angles=45;
set(handles.Curr_Lens,'String',angles);
Enable_Lengths=1;
setappdata(0,'Enable_Lengths',Enable_Lengths);
% Main_2D_AR;

TwoDimPlot

% --- Executes on button press in Two_Dim_Plot_Dep.
function Two_Dim_Plot_Dep_Callback(hObject, eventdata, handles)
% hObject    handle to Two_Dim_Plot_Dep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.slider1, 'Value', 1);
angles=45;
set(handles.Curr_Lens,'String',angles);
% len=getappdata(0,'length'); 
% rows = size(len,1);
% set(handles.Total_Lens,'String',rows);
lengths=getappdata(0,'length'); 

Enable_Lengths=0;
setappdata(0,'Enable_Lengths',Enable_Lengths);
% Main_2D_AR;

TwoDimPlot_Depths


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
ThreeDSlider = get(handles.slider3,'Value');
setappdata(0,'ThreeDSlider',ThreeDSlider)
% Main_3D_AR
Enable_AR=getappdata(0,'Enable_AR');
if Enable_AR==1
    plot_ar_3D
else if Enable_AR==0
        plot_pf_3D
    end
end
tr_cycles=getappdata(0,'TC');
rul_resolution=getappdata(0,'RUL');
time_index = floor((tr_cycles+(ThreeDSlider-1)*rul_resolution)/rul_resolution);
t=time_index*1000;
set(handles.Cyc_Disp_Text,'String',t);



% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in Three_Dim_Plot_AR.
function Three_Dim_Plot_AR_Callback(hObject, eventdata, handles)
% hObject    handle to Three_Dim_Plot_AR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.slider3, 'Value', 1);
ThreeDSlider=1;
setappdata(0,'ThreeDSlider',ThreeDSlider);
Enable_AR=1;
setappdata(0,'Enable_AR',Enable_AR);
plot_ar_3D;
tr_cycles=getappdata(0,'TC');
rul_resolution=getappdata(0,'RUL');
time_index = floor((tr_cycles+(1-1)*rul_resolution)/rul_resolution);
t=time_index*1000;
set(handles.Cyc_Disp_Text,'String',t);
