function  [pr_lengths,P_magn,int_ln] = predict_lengths (cycles,lengths,length_limit,tr_cycles,rul_resolution,nfs)
% Depth Prediction wrapper for PF: it takes the observation data(measurements), cycles, required resolution and predict
% the Future States with respect to number of cycles
% Syntax:    [pr_lengths,P_magn,int_ln] = predict_lengths (cycles,lengths,length_limit,tr_cycles,rul_resolution,nfs)
% Argument: cycles(flight cycles corresponding to original data points)
%           lengths(Data points)
%           length_limit (acts as the limit)
%           tr_cycles (number of cycles for training index) should be at
%           maximum equal to maximum number of observation cycles
%           rul_resolution (step size of predicted states in number of cycles)
%           nfs (Number of future states to be predicted)
% Returns:  pr_lengths (Estimated Measurements with Predicted Measurements)
%           P_magn (Last polynomial estimated as measurement function)
%           
% Engineer: Taha Ali, Waleed Bin Yousuf
% Date:     02 August 2015

% Internal constants / Parameters
% UIWAIT makes plotsettings wait for user response (see UIRESUME)
% uiwait(handles.figure1);
%first check the existence of the file.
%if file not present create a file and load zeros.
x=dlmread('Settings.txt');  
p=x(1);% Used in State Transition Equation (Degradation Model) [Ref eq (8) in Khan2011-RUL]
Ns=x(3);% no. of samples
SNR=x(4);


% p=getappdata(0,'SFTcoef')
% Ns=getappdata(0,'samples') 
% SNR=getappdata(0,'signoise')

ti=floor(tr_cycles/rul_resolution);

nrows = length (lengths(:,1));
angle_step = floor(360/nrows);

for angle = 0:angle_step:360-angle_step;
    int_ln_row = interpolate_data (cycles,lengths((angle/angle_step)+1,:),length_limit);
    
    prftr=int_ln_row(1:ti*rul_resolution)./length_limit; % selected-normalized-actual data picked as profile training data

    % Create one single Noise variable and use it for all angles
    if ~exist('Noise','var')
    Noise = randn(1,length(prftr));
    end
    
    mag_prog = std(prftr.*length_limit)/SNR.*Noise+prftr.*length_limit;
    P_magn=polyfit(prftr,mag_prog,2);
    
    pr_lengths((angle/angle_step)+1,:) = pf(int_ln_row,ti,nfs,mag_prog,prftr,P_magn,p,Ns);
    
    % formation of 2D matrix of lengths with respect to angles
    int_ln((angle/angle_step)+1,:) = int_ln_row(1:rul_resolution:length(int_ln_row));
end

% Convert states to measurements using last P_magn polynomial
pr_lengths = polyval(P_magn,pr_lengths);
