function varargout = DB_Gen(varargin)
% DB_Gen MATLAB code for DB_Gen.fig
%      DB_Gen, by itself, creates a new DB_Gen or raises the existing
%      singleton*.
%
%      H = DB_Gen returns the handle to a new DB_Gen or the handle to
%      the existing singleton*.
%TEST
%      DB_Gen('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DB_Gen.M with the given input arguments.
%
%      DB_Gen('Property','Value',...) creates a new DB_Gen or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DB_Gen_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DB_Gen_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DB_Gen

% Last Modified by GUIDE v2.5 13-Feb-2016 14:31:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DB_Gen_OpeningFcn, ...
                   'gui_OutputFcn',  @DB_Gen_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DB_Gen is made visible.
function DB_Gen_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DB_Gen (see VARARGIN)

% Display backgrounds
set (hObject,'CurrentAxes',handles.backgr);
imshow ('backgr.bmp');
axis(handles.backgr,'normal');

set (hObject,'Name','Aerospace NDT Prognostics GUI - Generate Database File');

% Choose default command line output for DB_Gen
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
end

%intialization 
handles.csk.x=0;
handles.csk.a=0;
handles.csk.b=0;
handles.csk.c=0;
handles.csk.d=0;
handles.csk.e=0;
handles.csk.f=0;
handles.csk.l=0;
handles.csk.m=0;
t=0;
de=0;
handles.csk.Day_Tx=0;
handles.csk.Month_Tx=0;
handles.csk.Year_Tx=0;
handles.csk.V=0;
%handles.csk.de=0;
handles.csk.de=zeros(8,2);
handles.csk.incr=2;

% Disable these buttons
set(handles.Next_Btn,'enable','off');
set(handles.de_table,'enable','off');
set(handles.Report_Save_Btn,'enable','off');
set(handles.Start_Entry_Btn,'enable','on');
set(handles.Desc_Text1,'string','Create a Database file');
set(handles.Desc_Text2,'string','Enter values in the fields given below. Current instants are displayed on the top right. Enter the Type of the aircraft i.e. ATR, Airbus, Boeing 747.');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DB_Gen wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DB_Gen_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Next_Btn.
function Next_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Next_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.Incr_String, 'String', handles.csk.incr);
x=str2double(handles.csk.V);
if x==handles.csk.incr
    handles.csk.incr
else
    handles.csk.incr=handles.csk.incr+1;
end


%number of instants here is 'noi' which changes after each observvation
%while 'm' remains constant 
% set(handles.de_table,'Data',{0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0; 0 0});
%set(handles.de_table, 'Data', cell(size(get(handles.de_table,'Data'))));
curr_noi=handles.csk.x;
handles.csk.m=handles.csk.x;
% if exist('handles.csk.de','var')
data=handles.csk.de;
% end
% de=handles.csk.a;
% fh=handles.csk.b;
% fc=handles.csk.c;
% Day_Tx=handles.csk.d;
% Month_Tx=handles.csk.e;
% Year_Tx=handles.csk.f;

if curr_noi>0
  de=get(handles.de_table,'Data');
  setappdata(0,'de',de);
  handles.csk.fh=str2double(get(handles.Fly_Hrs_Tx,'String'));
handles.csk.fc(handles.csk.noi-curr_noi+1)=str2double(get(handles.Fly_Cyc_Tx,'String'));
%   handles.csk.fc=[];
% if handles.csk.noi>0
%     handles.csk.fc(noi)=str2double(get(handles.Fly_Hrs_Tx,'String'));
%     handles.csk.noi =handles.csk.noi-1;
%  end
%AHMAD
  handles.csk.x=str2double(get(handles.NIS_Tx,'String'));
  handles.csk.d=str2double(get(handles.Day_Tx,'String'));
  handles.csk.e=str2double(get(handles.Month_Tx,'String'));
  handles.csk.f=str2double(get(handles.Year_Tx,'String'));
  handles.csk.g=get(handles.Type_Tx,'String');
  handles.csk.h=get(handles.Reg_No_Tx,'String');
  handles.csk.i=get(handles.Rib_Tx,'String');
  handles.csk.j=str2double(get(handles.Skin_Th_Tx,'String'));
  handles.csk.l=get(handles.Stringer_No_Tx, 'String');
  handles.csk.m=str2double(get(handles.Length_Lim_Tx, 'String'));
  
%   setappdata(0, 'NoIns',handles.csk.x);
%   setappdata(0, 'Day',handles.csk.d);
%   setappdata(0, 'Month',handles.csk.e);
%   setappdata(0, 'Year',handles.csk.f);
%   setappdata(0, 'Type',handles.csk.g);
%   setappdata(0, 'RegNo',handles.csk.h);
%   setappdata(0, 'Rib',handles.csk.i);
%   setappdata(0, 'SkinThickness',handles.csk.j);
%   setappdata(0, 'Stringer',handles.csk.l);
%   setappdata(0, 'LengthLimit',handles.csk.m);
  
%   data(:,2*(curr_noi)-1)=str2double(de(:,1));
%   data(:,2*(curr_noi))=str2double(de(:,2));
for i=1:1:8;
  data(i,2*(handles.csk.noi-curr_noi+1)-1)=de{i,1};
  data(i,2*(handles.csk.noi-curr_noi+1))=de{i,2};
end
end

curr_noi=curr_noi-1;

if curr_noi==0
    set(handles.Report_Save_Btn,'enable','on');
end

 handles.csk.de=data;
 handles.csk.x=curr_noi;

% handles.csk.a=de;
%  handles.csk.b=fh;
% handles.csk.c=fc;
% handles.csk.e=Day_Tx;
% handles.csk.f=mon;
% handles.csk.g=Year_Tx;

% Update handles structure
set(handles.Desc_Text3,'string','Press the Save DB File button to save the generated Database file, when the button is enabled.');
guidata(handles.output, handles);




% --- Executes on button press in Report_Save_Btn.
function Report_Save_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Report_Save_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Report Generation

set(handles.Desc_Text3,'string','Press the Close button to return to the previous GUI and Load the generated file.');
[Report_filename, Report_pathname]= uiputfile('*.txt','Save Report as'); % Prompt User for Saving Report file

if Report_pathname
    
    % Open File for Reporting Important Parameters
  
    fid = fopen(cat(2,Report_pathname,Report_filename),'w');

    if (fid == -1), 
        error('File not opened!'); 
    end
%    fprintf(fid,'Report format:GUI\r\n');
%    fprintf(fid,'Engineers: Taha Ali, Kiran Aslam\r\n');
%    fprintf(fid,'Date: %d-%d-%d\r\n\r\n', handles.csk.d, handles.csk.e, handles.csk.f);
%    fprintf(fid,'Type: %s\r\n',handles.csk.g);
%    fprintf(fid,'Registration Number: %s\r\n',handles.csk.h);
%    
%    selection = get(handles.uipanel2,'SelectedObject');
%    handles.LR = get(selection, 'String');
%    fprintf(fid,'Wing: %s\r\n',handles.LR);
%    
%    fprintf(fid,'Stringer Number: %s\r\n',handles.csk.l);
%    fprintf(fid,'Rib: %s\r\n',handles.csk.i);
%    fprintf(fid,'Skin thickness: %s\r\n\r\n',handles.csk.j);
   fprintf(fid,'%d\r\n\',handles.csk.noi); % No of instants
   
   %fprintf (fid,'\r\n');
   %fprintf(fid,'Data Entries \r\n');
    %for i=1:1:8
       % fprintf (fid,'%d\r\n',handles.csk.de(i,:));
   % end
%  for i=1:1:handles.csk.noi
%  fprintf(fid,'Flying hours: %s\r\n\r\n',handles.csk.fh);
%  end 
    
   
  
%   fprintf(fid,'day_tx: %d\r\n\r\n',handles.csk.d);
%   fprintf(fid,'month_tx: %d\r\n\r\n',handles.csk.e);
%   fprintf(fid,'year_tx: %d\r\n\r\n',handles.csk.f);
  % fprintf (fid,'Lengths:\r\n');
    for j=1:1:handles.csk.noi
    for i=1:1:8
        fprintf (fid,'%d,',handles.csk.de(i,((2*j)-1)));
    end
%     fprintf(fid, '\r\n');
    end
  fprintf (fid,'\r\n');
   %fprintf (fid,'Thickness:\r\n');
    for j=1:1:handles.csk.noi
    for i=1:1:8
        fprintf (fid,'%d,',handles.csk.de(i,((2*j))));
    end

    end
    
    
fprintf (fid,'\r\n');
fprintf(fid,'%d,',handles.csk.fc); %Flying Cycles
fprintf (fid,'\r\n');
fprintf(fid,'%d,',handles.csk.j); % Skin Thickness
fprintf (fid,'\r\n');
fprintf(fid,'%d,',handles.csk.m); % Length Limit
fprintf (fid,'\r\n');
fprintf(fid,'%d,',handles.csk.d);
fprintf (fid,'\r\n');
fprintf(fid,'%d,',handles.csk.e);
fprintf (fid,'\r\n');
fprintf(fid,'%d,',handles.csk.f);
fprintf (fid,'\r\n');
fprintf(fid,'%s,',handles.csk.g);
fprintf (fid,'\r\n');
fprintf(fid,'%s,',handles.csk.h);
fprintf (fid,'\r\n');
fprintf(fid,'%s,',handles.csk.i);
fprintf (fid,'\r\n');
fprintf(fid,'%s,',handles.csk.l);
fprintf (fid,'\r\n');
fprintf(fid,'%d,',handles.csk.fh);
end    

% --- Executes on button press in Left_RadBtn.
function Left_RadBtn_Callback(hObject, eventdata, handles)
% hObject    handle to Left_RadBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Left_RadBtn


% --- Executes on button press in Right_RadBtn.
function Right_RadBtn_Callback(hObject, eventdata, handles)
% hObject    handle to Right_RadBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Right_RadBtn



function Type_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Type_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Type_Tx as text
%        str2double(get(hObject,'String')) returns contents of Type_Tx as a double
set(handles.Desc_Text1,'string','Registration Number');
set(handles.Desc_Text2,'string','Enter the Registration Number of the aircraft');


% --- Executes during object creation, after setting all properties.
function Type_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Type_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in Start_Entry_Btn.
function Start_Entry_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Start_Entry_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.csk.V = get(handles.NIS_Tx, 'String');
set(handles.Instant_String, 'String', handles.csk.V);
set(handles.Incr_String, 'String', 1);

set(handles.Next_Btn,'enable','on');
set(handles.de_table,'enable','on');
set(handles.Report_Save_Btn,'enable','off');
set(handles.Stringer_No_Tx,'enable','off');
set(handles.Rib_Tx,'enable','off');
set(handles.Skin_Th_Tx,'enable','off');
set(handles.Left_RadBtn,'enable','off');
set(handles.Right_RadBtn,'enable','off');
set(handles.Type_Tx,'enable','off');
set(handles.Day_Tx,'enable','off');
set(handles.Month_Tx,'enable','off');
set(handles.Year_Tx,'enable','off');
set(handles.Reg_No_Tx,'enable','off');
set(handles.Length_Lim_Tx,'enable','off');
set(handles.Fly_Hrs_Tx,'enable','on');
set(handles.Fly_Cyc_Tx,'enable','on');
set(handles.Day_Tx,'enable','on');
set(handles.Month_Tx,'enable','on');
set(handles.Year_Tx,'enable','on');
t=str2double(get(handles.NIS_Tx,'String'));
set(handles.NIS_Tx,'enable','off');
handles.csk.x=t;
handles.csk.noi=t;
%iteration=t;
%set(handles.Iteration_String,'String','hello',iteration);
% Update handles structure
guidata(handles.output, handles);
set(handles.Start_Entry_Btn,'enable','off');
set(handles.Desc_Text3,'string','Press the Next button for the next iteration of values.');
% Update handles structure
guidata(hObject, handles);


function Year_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Year_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Year_Tx as text
%        str2double(get(hObject,'String')) returns contents of Year_Tx as a double


% --- Executes during object creation, after setting all properties.
function Year_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Year_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Day_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Day_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Day_Tx as text
%        str2double(get(hObject,'String')) returns contents of Day_Tx as a double


% --- Executes during object creation, after setting all properties.
function Day_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Day_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Month_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Month_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Month_Tx as text
%        str2double(get(hObject,'String')) returns contents of Month_Tx as a double


% --- Executes during object creation, after setting all properties.
function Month_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Month_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function call_Callback(hObject, eventdata, handles)
% hObject    handle to call (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of call as text
%        str2double(get(hObject,'String')) returns contents of call as a double


% --- Executes during object creation, after setting all properties.
function call_CreateFcn(hObject, eventdata, handles)
% hObject    handle to call (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
fprintf(fid,'%d',handles.csk.noi);
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Reg_No_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Reg_No_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Reg_No_Tx as text
%        str2double(get(hObject,'String')) returns contents of Reg_No_Tx as a double
set(handles.Desc_Text1,'string','Stringer Number');
set(handles.Desc_Text2,'string','Enter the Stringer Number of the plane');


% --- Executes during object creation, after setting all properties.
function Reg_No_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Reg_No_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Stringer_No_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Stringer_No_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Stringer_No_Tx as text
%        str2double(get(hObject,'String')) returns contents of Stringer_No_Tx as a double
set(handles.Desc_Text1,'string','Rib');
set(handles.Desc_Text2,'string','Enter the Rib value');


% --- Executes during object creation, after setting all properties.
function Stringer_No_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Stringer_No_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Rib_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Rib_Tx_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Rib_Tx_Tx as text
%        str2double(get(hObject,'String')) returns contents of Rib_Tx_Tx as a double
set(handles.Desc_Text1,'string','Skin Thickness');
set(handles.Desc_Text2,'string','Enter the skin thickness of the sheet being tested.');


% --- Executes during object creation, after setting all properties.
function Rib_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Rib_Tx_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Skin_Th_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Skin_Th_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Skin_Th_Tx as text
%        str2double(get(hObject,'String')) returns contents of Skin_Th_Tx as a double
set(handles.Desc_Text1,'string','Length Limit');
set(handles.Desc_Text2,'string','Enter the Length Limit.');

handles.Skin_Thick = str2double(get(handles.Skin_Th_Tx, 'String'));
setappdata(0,'Skin_Th_Tx', handles.Skin_Thick);
disp(handles)

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function Skin_Th_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Skin_Th_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% 

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function de_table_CreateFcn(hObject, eventdata, handles)
% hObject    handle to de_table (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function NIS_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to NIS_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NIS_Tx as text
%        str2double(get(hObject,'String')) returns contents of NIS_Tx as a double
set(handles.Desc_Text1,'string','Flight Hours');
set(handles.Desc_Text2,'string','Enter the Flight Hours for the particular aircraft.');


% --- Executes during object creation, after setting all properties.
function NIS_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NIS_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Fly_Hrs_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Fly_Hrs_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fly_Hrs_Tx as text
%        str2double(get(hObject,'String')) returns contents of Fly_Hrs_Tx as a double
set(handles.Desc_Text1,'string','Flight Cycles');
set(handles.Desc_Text2,'string','Enter the Flight Cycles for the particular aircraft');


% --- Executes during object creation, after setting all properties.
function Fly_Hrs_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fly_Hrs_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Fly_Cyc_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Fly_Cyc_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fly_Cyc_Tx as text
%        str2double(get(hObject,'String')) returns contents of Fly_Cyc_Tx as a double
set(handles.Desc_Text1,'string','Table');
set(handles.Desc_Text2,'string','Press the Start Entry button and enter the values of lengths and depths in the table displayed. After each set of entries, press the Next button for the next iteration and re-enter values for Flight Cycles & Hours along with the lengths and depths. Repeat until the iterations are complete.');



% --- Executes during object creation, after setting all properties.
function Fly_Cyc_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fly_Cyc_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Close_Btn.
function Close_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Close_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Prog_GUI_LoadGenDB (handles.igc);



function Length_Lim_Tx_Callback(hObject, eventdata, handles)
% hObject    handle to Length_Lim_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Length_Lim_Tx as text
%        str2double(get(hObject,'String')) returns contents of Length_Lim_Tx as a double
set(handles.Desc_Text1,'string','Number of Observations');
set(handles.Desc_Text2,'string','Enter the number of observations, this also translates to the number of instants and is required for application of prognostic algorithms.');



% --- Executes during object creation, after setting all properties.
function Length_Lim_Tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Length_Lim_Tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
