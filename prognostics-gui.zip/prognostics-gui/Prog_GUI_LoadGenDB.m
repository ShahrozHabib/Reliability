function varargout = Prog_GUI_LoadGenDB(varargin)
% PROG_GUI_LOADGENDB MATLAB code for Prog_GUI_LoadGenDB.fig
%      PROG_GUI_LOADGENDB, by itself, creates a new PROG_GUI_LOADGENDB or raises the existing
%      singleton*.
%
%      H = PROG_GUI_LOADGENDB returns the handle to a new PROG_GUI_LOADGENDB or the handle to
%      the existing singleton*.
%
%      PROG_GUI_LOADGENDB('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROG_GUI_LOADGENDB.M with the given input arguments.
%
%      PROG_GUI_LOADGENDB('Property','Value',...) creates a new PROG_GUI_LOADGENDB or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Prog_GUI_LoadGenDB_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Prog_GUI_LoadGenDB_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Prog_GUI_LoadGenDB

% Last Modified by GUIDE v2.5 11-Feb-2016 17:35:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Prog_GUI_LoadGenDB_OpeningFcn, ...
                   'gui_OutputFcn',  @Prog_GUI_LoadGenDB_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Prog_GUI_LoadGenDB is made visible.
function Prog_GUI_LoadGenDB_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Prog_GUI_LoadGenDB (see VARARGIN)

% Display backgrounds
set (hObject,'CurrentAxes',handles.backgr);
imshow ('backgr.bmp');
axis(handles.backgr,'normal');

% Choose default command line output for Prog_GUI_LoadGenDB
handles.output = hObject;

% Define igc as Inter-GUI Communication structure and include it in handles
% for Inter-functions communications
handles.igc.prev_fig_h = hObject;

% Handle varargin
optargin = size(varargin,2);
stdargin = nargin - optargin;

if optargin         % if optional arguments present          
    parent.igc = varargin{1};
    delete(parent.igc.prev_fig_h); % delete calling figure
end

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ANDT_GUI_WEL wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% Set window Title
set (hObject,'Name','Aerospace NDT Prognostics GUI - Database File');
set (handles.Next_Btn, 'enable', 'off')
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Prog_GUI_LoadGenDB wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Prog_GUI_LoadGenDB_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function Filepath_Edit_Callback(hObject, eventdata, handles)
% hObject    handle to Filepath_Edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Filepath_Edit as text
%        str2double(get(hObject,'String')) returns contents of Filepath_Edit as a double


% --- Executes during object creation, after setting all properties.
function Filepath_Edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Filepath_Edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Load_Btn.
function Load_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Load_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,FilePath ]= uigetfile('.txt');
handles.ExPath = fullfile(FilePath, FileName);
A=handles.ExPath;
setappdata(0,'fileName',A); % to pass variables between GUIs
%handles.ExPath
%fid = fopen(FileName)

set(handles.Filepath_Edit,'string',handles.ExPath);
set (handles.Next_Btn, 'enable', 'on');

%%%%%% For displaying loaded file

% data1 = fileread(handles.ExPath);
% set(handles.Display_Txt,'Max', 2);
% set(handles.Display_Txt,'String',data1);
% set(handles.Display_Txt,'HorizontalAlignment','left');

%%%%%% For displaying loaded file


% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in Gen_DBFile_Btn.
function Gen_DBFile_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Gen_DBFile_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
DB_Gen (handles.igc);


% --- Executes on button press in Next_Btn.
function Next_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Next_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Readtextfile;
Prog_GUI_DB_Plot (handles.igc);



% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in Back_Btn.
function Back_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Back_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 Prog_GUI_Welcome (handles.igc);



function Display_Txt_Callback(hObject, eventdata, handles)
% hObject    handle to Display_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Display_Txt as text
%        str2double(get(hObject,'String')) returns contents of Display_Txt as a double


% --- Executes during object creation, after setting all properties.
function Display_Txt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Display_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
