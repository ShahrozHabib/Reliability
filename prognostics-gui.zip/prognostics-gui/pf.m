function pr_state = pf (obs_data,ti,nfs,mag_prog,prftr,P_magn,p,Ns)
% obs_data=Mag_fm;
% Particle Filter: it takes the observation data(measurements) and predict
% the Future States
% Syntax:   pr_state = pf (obs_data,ti,nfs,mag_prog,prftr,P_magn,p,Ns)
% Argument: obs_data(Observation data), ti(training index), nfs(number of future states)
%           mag_prog(Measurements of data), prftr(Actual States), P_magn(measurement polynomial)
% Returns:  pr_state(Estimated States with Predicted States - 'Normalized')
%           
% Engineer: Taha Ali, Waleed Bin Yousuf
% Date:     31 July 2015



ln_mag_prog=length(mag_prog);
Mag_fm=mag_prog(1:floor(ln_mag_prog/ti):ln_mag_prog);

Max_k=length(Mag_fm);
% xaxisnum=1:Max_k;

new=mag_prog -polyval(P_magn,prftr);%difference between FEM and functional model measurements
%new=randn(length(int_dp));
%keyboard
% err_range=0.8;    % assuming 1 mm error 
% new=rand(1,35000).*err_range;
[newpdf,x_val]=ksdensity(new,'npoints',500);%Generating PDF
%[newpdf,x_val]=hist(new,500);

newpdf=newpdf/sum(newpdf);%normalizing





RUL_vals=[];
XX=[];
pfx=zeros(Ns,1);
    pfx=sort(pfx);
    pfw=ones(Ns,1);
    pfw=pfw/sum(pfw);
    
for k=2:Max_k %Max_k=length(Mag_fm);
    
   
    
    
    [tx,tw]=sir_prog(pfx(:,k-1),pfw(:,k-1),Mag_fm,P_magn,newpdf,x_val,k,p);
    
    [I,J]=sort(tx);
    tx=tx(J);
    tw=tw(J);
    pfx=[pfx,tx];
    pfw=[pfw,tw];
    
end

for k=Max_k:Max_k+nfs
    for i=1:Ns
        xkj(i)=gennextstate_prog(pfx(i,k),p);
    end
    pfx=[pfx,xkj'];
end   % k


pr_state=mean(pfx);
