function  [pr_depths,P_magn,int_dp] = predict_depths (cycles,depths,max_sheet_thickness,tr_cycles,rul_resolution,nfs)
% Depth Prediction wrapper for PF: it takes the observation data(measurements), cycles, required resolution and predict
% the Future States with respect to number of cycles
% Syntax:  [pr_depths,P_magn,int_dp] = predict_depths (cycles,depths,max_sheet_thickness,tr_cycles,rul_resolution,nfs)
% Argument: cycles (flight cycles corresponding to original data points)
%           depths (Data points: already converted from thickness)
%           max_sheet_thickness (acts as the limit)
%           tr_cycles (number of cycles for training index) should be at
%           maximum equal to maximum number of observation cycles
%           rul_resolution (step size of predicted states in number of cycles)
%           nfs (Number of future states to be predicted)
% Returns:  pr_depths (Estimated Measurements with Predicted Measurements)
%           P_magn (Last polynomial estimated as measurement function)
%           
% Engineer: Taha Ali, Waleed Bin Yousuf
% Date:     02 August 2015

% Internal constants / Parameters

x=dlmread('Settings.txt');  
p=x(1);% Used in State Transition Equation (Degradation Model) [Ref eq (8) in Khan2011-RUL]
Ns=x(3);% no. of samples
SNR=x(4);

% p=getappdata(0,'SFTcoef');  % Used in State Transition Equation (Degradation Model) [Ref eq (8) in Khan2011-RUL]
% Ns=getappdata(0,'samples'); % no. of samples
% SNR=getappdata(0,'signoise');

% depths=max_sheet_thickness-thickness;

ti=floor(tr_cycles/rul_resolution);

nrows = length (depths(:,1));
angle_step = floor(360/nrows);

for angle = 0:angle_step:360-angle_step
    int_dp_row = interpolate_data (cycles,depths((angle/angle_step)+1,:),max_sheet_thickness);
    
    prftr=int_dp_row(1:ti*rul_resolution)./max_sheet_thickness; % selected-normalized-actual data picked as profile training data

    % Create one single Noise variable and use it for all angles
    if ~exist('Noise','var')
    Noise = randn(1,length(prftr));
    end
    
    mag_prog = std(prftr.*max_sheet_thickness)/SNR.*Noise+prftr.*max_sheet_thickness;
    P_magn=polyfit(prftr,mag_prog,2);
    
    pr_depths((angle/angle_step)+1,:) = pf(int_dp_row,ti,nfs,mag_prog,prftr,P_magn,p,Ns);
    
     % formation of 2D matrix of depths with respect to angles
    int_dp((angle/angle_step)+1,:) = int_dp_row((1:rul_resolution:length(int_dp_row)));
end

% Convert states to measurements using last P_magn polynomial
pr_depths = polyval(P_magn,pr_depths);
