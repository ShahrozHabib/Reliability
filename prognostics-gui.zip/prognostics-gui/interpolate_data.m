function  int_data = interpolate_data (cycles,act_states,limit)
% interpolate_data: it takes the observation data(measurements) and
% interpolates with respect to number of cycles
% Syntax:   int_data = interpolate_data (cycles,act_states,limit)
% Argument: cycles (cycle numbers corresponding to data instants, starting 
%           from zero),act_states (lengths or depths data),limit (max sheet thickness or length,
%           whichever is applicable)
%           
% Returns:  int_data (Interpolated lengths or depths with respect to cycles)
%           
% Engineer: Taha Ali, Waleed Bin Yousuf
% Date:     31 July 2015

%  starting cycle must be zero (Take care)
% Try Spline interploation
% X = linspace(15000,27000,12001);
st_point=cycles(1);
end_point=cycles(end)+1500;

X = linspace(st_point,end_point,end_point+1);
pp = spline(cycles,[ 0 act_states 0]);
Y = ppval(pp,X);

% limit=7.62;
if any(Y<0)   % If there are limit crossings
        xi=0:1000:27000;
%         yi=pchip(cycles,lengths,xi);
         yi=pchip(cycles,act_states,xi);

        pp = spline(xi,[ 0 yi 0]);
        Y = ppval(pp,X);

        if any(Y<0)  % If STILL there are limit crossings!

            % Forcefully  limit dimension to zero
            Y_ind = find(Y<0);
            Y(Y_ind) = 0;
        end
        if any(Y>limit)  % If STILL there are limit crossings!
        
        % Forcefully  limit dimension to max. 
        Y_ind = find(Y>limit);
        Y(Y_ind) = limit;       
        end
end

int_data=Y;