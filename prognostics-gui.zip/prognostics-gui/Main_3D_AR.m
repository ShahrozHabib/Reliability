%% Tests Modular Prognosis code
% 

% Engineer: Taha Ali, Waleed Bin Yousuf
% Date:     07 August 2015

%% Initialize
% clc;
% clear all;
% close all;

% load Data dot mat 

lengths=getappdata(0,'length');    
thickness=getappdata(0,'thickness');


cycles=getappdata(0,'cyc');

max_sheet_thickness=getappdata(0,'Max_Sheet_Thickness');

tr_cycles=getappdata(0,'TC');
rul_resolution=getappdata(0,'RUL');
nfs=getappdata(0,'Future_States');
length_limit=getappdata(0,'Length_Limit');
% angle_step=getappdata(0, 'Angle_Step')
angle_step=45;
    
    
depths=max_sheet_thickness-thickness;

[out_lengths, out_depths]= angle_interpolation (lengths, depths, angle_step);
lengths = out_lengths;
depths =   out_depths;

% [pr_lengths,P_magn] = predict_lengths (cycles,lengths,length_limit,tr_cycles,rul_resolution,nfs)
[pr_lengths,P_magn_ln,int_ln] = predict_lengths (cycles,lengths,length_limit,tr_cycles,rul_resolution,nfs);

% [pr_depths,P_magn] = predict_depths (cycles,depths,max_sheet_thickness,tr_cycles,rul_resolution,nfs)
[pr_depths,P_magn_dp,int_dp] = predict_depths (cycles,depths,max_sheet_thickness,tr_cycles,rul_resolution,nfs);

% for lengths
% corr_meas = AR_correction (pr_meas, data_limit, actual_data, P_magn , tr_cycles, rul_resolution, nfs)
corr_meas_ln = AR_correction (pr_lengths, length_limit, int_ln, P_magn_ln , tr_cycles, rul_resolution, nfs);

% for depths
corr_meas_dp = AR_correction (pr_depths, max_sheet_thickness, int_dp, P_magn_dp , tr_cycles, rul_resolution, nfs);

% Data structure for plotting 
data.ln_act = int_ln;
data.dp_act = int_dp;
data.ln_pf = pr_lengths;
data.dp_pf = pr_depths;
data.ln_pf_ar = corr_meas_ln;
data.dp_pf_ar = corr_meas_dp;

% csk_prediction_progression (data, time_index, length_limit, max_sheet_thickness, plot_view);
% csk_prediction_progression (data, 24000,rul_resolution, length_limit, max_sheet_thickness, 0)
plot_pf_3D(pr_lengths, pr_depths, length_limit, max_sheet_thickness);
