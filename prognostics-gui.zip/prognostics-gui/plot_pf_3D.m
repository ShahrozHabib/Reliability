% function  [] = plot_pf_3D (lengths, depths, length_limit, max_sheet_thickness, varargin)
% csk_plot_3d: it takes lengths and depths, forms a 3D matrix for CSK, and
% plots it on the given handle
% Syntax:   csk_plot_3d (axes_handle, lengths, depths, time_index, length_limit, max_sheet_thickness, plot_view)
% Argument: 
%           axes_handle (measurements predicted from PF)
%           lengths (Length Data points: 2D matrix with rows corresponding to angles and coloumns corresponding to time/cycles)
%           depths (Depth Data points: 2D matrix with rows corresponding to angles and coloumns corresponding to time/cycles)
%           time_index (the time at which plot is to be obtained)
%           length_limit(acts as the maximum radius possible)
%           max_sheet_thickness ()
%           plot_view (0:planar or 1:isometric)
% Returns:  NIL
%           
% Engineer: Taha Ali, Waleed Bin Yousuf
% Date:     06 August 2015

[handles.imagedata handles.imagemap] = imread('backgr.bmp');

% Constants / Parameters
background=getappdata(0,'background1');
plot=getappdata(0,'display_plot1');
lengths=getappdata(0,'pr_lengths');
depths=getappdata(0,'pr_depths');
plot_view=0;
length_limit=getappdata(0,'Length_Limit');
rul_resolution=getappdata(0,'RUL');
%plot_cycle=21201;
% time_index=getappdata(0,'sliderValue');


tr_cycles=getappdata(0,'TC');
rul_resolution=getappdata(0,'RUL');
Slider_Value=getappdata(0,'ThreeDSlider');
time_index = floor((tr_cycles+(Slider_Value-1)*rul_resolution)/rul_resolution);



cycles=getappdata(0,'cyc');
x=dlmread('Settings.txt');  
max_sheet_thickness=getappdata(0,'Max_Sheet_Thickness');
csk_edge = x(5); % in mm
csk_edge_i = ceil(csk_edge*10);
th_max = x(6); % theta in deg
R_max = length_limit; % rho in mm
R_max_i = ceil(R_max*10);
R_min = x(7); % rho in mm
R_min_i = ceil(R_min*10);



meshscale = x(8);
Max_axis = x(9); % For axis: In tens of mm


%%
ln_rows = length (lengths(:,1));
dp_rows = length (depths(:,1));

if ln_rows~=dp_rows
    error('Number of rows for lengths and depths matrices donot match!');
end
if ((360/ln_rows)-floor(360/ln_rows))
    error('Number of rows must be such that angle step should be an integer!');
end
angle_step = floor(360/ln_rows);

a_ln = lengths (:,time_index)';
a_dp = depths (:,time_index)';

y_l=[0 a_ln a_ln(1) 0]; 
y_d=[0 a_dp a_dp(1) 0];


%% Define angles and given CSK data
x = [0:angle_step:360]/360*2*pi; % Angles 0-2*pi
% csk_edge_p = linspace(csk_edge,csk_edge,11); % Define CSK edge length for eight angles [one is additional for 2*pi, and two for end slopes]
%y_l = [0 0 6 4 4 6 6 0 0 0 0]+csk_edge; % Define the lengths = distance from CSK edge + csk_edge
%y_d = [0 7.3 2.2 2.1 2.0 2.4 2.1 7.2 7.3 7.3 0]; % Define depths at given angles
y = [y_l;y_d]; % Construct combined matrix for lenghts and depths

%% Spline Interpolation along angles
xx = linspace(0,2*pi,360); % Create 1 degree resolution vector
pp = spline(x,y);
yy = ppval(pp,xx); % Evaluate generated piecewise polynomial

%% Definitions for matrix formulation and 3D plot
% xx is angle vector with 1 degree resolution
% yy is the interpolated array, yy = [yy_l;yy_d];
% where yy_l = distance from CSK edge + csk_edge, and yy_d = interpolated
% depths
yy_l = yy(1,:);
yy_l = yy_l + csk_edge; % re-align lengths

yy_d = yy(2,:);

%% Define matrix

Depth = zeros (R_max_i,th_max);
Zer_mat = Depth;
%% Fill matrix

for a=1:1:th_max
    if (yy_l(a)<csk_edge)
        yy_l(a) = csk_edge;
    end
        for r=(floor(yy_l(a)*10)+1):-1:csk_edge_i-1
             Depth(R_max_i-r,a) = yy_d(a);
        end
        
        
        for r=csk_edge_i-2:-1:1
              Depth(R_max_i-r,a) = max_sheet_thickness;
        end
end

%% Plot Polar 3D Matrix
%  Depth = flipud(Depth);

% figure;
% Select axes handle
axis on;
axes(plot);

colormap(background, handles.imagemap);
% cbar_handle = findobj(background,'tag','Colorbar')
freezeColors(background);
% cbfreeze(cbar_handle)

colormap(plot, jet);
cbar_handle = findobj(plot,'tag','Colorbar')
freezeColors(plot);
cbfreeze(cbar_handle)

polar3d_AR(Depth,0,2*pi,0,R_max_i,meshscale,'surf');
hold on;
% polar3d(Depth,0,2*pi,0,254,meshscale,'contour');

polar3d_AR(Zer_mat,0,2*pi,R_max_i,R_max_i+0.001,meshscale,'meshl');
axis on;
% colorbar;
axis ([-Max_axis Max_axis -Max_axis Max_axis]);
colormap(plot, jet);
cbar_handle = findobj(plot,'tag','Colorbar')
freezeColors(plot);
cbfreeze(cbar_handle)

% title ('CSK plot representing ACTUAL flaw leangths and depths at differnt angles')
xlabel ('Distance from Rivet Center ')
ylabel ('Distance from Rivet Center ')
hold off;

if plot_view == 1
    view(3);
else
    view([90 -90]);
end

axis equal;