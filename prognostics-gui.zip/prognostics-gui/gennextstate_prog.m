function xcurr=gennextstate_prog(xk,p)
%function generates true (reference) state sequence

%xk: state at time k, column vector

%k: time step

%xnext: state at next time (k+1), column vector

%PolyOrder: Polynomial order for state


% This function is called in parent as: xkj(i)=gennextstate_prog(xki1(i),p); 
% Draw Samples


state=xk:0.01:1;


statemat=exp(-(abs(state-xk).^p))/(p*sum((1/p)*exp(-(abs(state-xk).^p))));
 

%Now, draw a random number:

y = 0.4*rand(1)*(1-xk); 
% Modified by Taha and Waleed, Original:y = 0.2*rand(1)*(1-xk);

%accept or reject 
% rejection sampling 

Prob = cumsum(statemat);

xx = find(Prob > y);

xcurr =state(xx(1));

% if xcurr<=xk

%     xcurr=xk;

%	end