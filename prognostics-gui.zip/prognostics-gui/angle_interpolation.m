function  [out_lengths, out_depths]= angle_interpolation (lengths, depths, angle_step)
% angle_interpolation:  It takes lengths and depths matrices at 45 degree
%                       steps and returns interpolated lengths and depths matrices with desired
%                       angle step size
% Syntax:   [out_lengths, out_depths]= angle_interpolation (lengths, depths, angle_step)
% Argument: 
%           angle_step( normally 1,5,10,15,30,45)
%           lengths (Length Data points: 2D matrix with rows corresponding to angles and coloumns corresponding to time/cycles)
%           depths (Depth Data points: 2D matrix with rows corresponding to angles and coloumns corresponding to time/cycles)
% Returns:  
%           out_lengths (Interpolated Length Data points: 2D matrix with rows corresponding to angles and coloumns corresponding to time/cycles)
%           out_depths (Interpolated Depth Data points: 2D matrix with rows corresponding to angles and coloumns corresponding to time/cycles)
%        
% Engineer: Taha Ali, Waleed Bin Yousuf
% Date:     07 August 2015

ln_rows = length (lengths(:,1));
dp_rows = length (depths(:,1));

if ln_rows~=dp_rows
    error('Number of rows for lengths and depths matrices donot match!');
end

if ln_rows~=8
       error('Original Angle step for the input should be 45 degrees');
end


if ((360/angle_step)-floor(360/angle_step))
    error('Angle step should be a factor of 360 (So that the intervals must be an integer value)!');
end

ln_col = length (lengths(1,:));

if angle_step == 45
    out_lengths = lengths;
    out_depths = depths;
    return
end

for time_index=1:1:ln_col

    a_ln = lengths (:,time_index)';
    a_dp = depths (:,time_index)';

    y_l=[0 a_ln a_ln(1) 0]; 
    y_d=[0 a_dp a_dp(1) 0];


    %% Define angles and given CSK data
    x = [0:angle_step:360]/360*2*pi; % Angles 0-2*pi
    % csk_edge_p = linspace(csk_edge,csk_edge,11); % Define CSK edge length for eight angles [one is additional for 2*pi, and two for end slopes]
    %y_l = [0 0 6 4 4 6 6 0 0 0 0]+csk_edge; % Define the lengths = distance from CSK edge + csk_edge
    %y_d = [0 7.3 2.2 2.1 2.0 2.4 2.1 7.2 7.3 7.3 0]; % Define depths at given angles
    y = [y_l;y_d]; % Construct combined matrix for lenghts and depths

    %% Spline Interpolation along angles
    xx = linspace(0,2*pi,360/angle_step); % Create 1 degree resolution vector
    pp = spline(x,y);
    yy = ppval(pp,xx); % Evaluate generated piecewise polynomial
    
    yy_l = yy(1,:);
    yy_d = yy(2,:);

  
    out_lengths(:,timeindex) = yy_l';
    out_depths(:,timeindex) = yy_d';
end

