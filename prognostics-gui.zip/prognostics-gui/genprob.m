function p=genprob(z_mag,P_magn,x_val,newpdf,xkj)

%z_mag=magnitude using FEM
%P_magn=functional model polynomial
%xkj=depth at position k using stste transition model

% used in parent %%wkj(i)=genprob(z_mag,P_magn,x_val,newpdf,xkj(i)); % Assign weights 
% z_mag=Mag_fm(k)

Mag=polyval(P_magn,xkj);%measurement using functional model % Predicted measurement at xkj 
x_val=x_val+Mag;% mean shifting of error pdf by new measurement (RUL.m) 
%x_val=x_val+sqrt(Mag);              % temporary change, if found then comment it
% Now x_val is a distribution matrix around 'Mag' with errors from 'newpdf'


if size(find(x_val==z_mag),2)~=0  % Is there any updated (shifted) x_val == z_mag??
    p1=newpdf(find(x_val==z_mag)); % If yes, find in newpdf (the error pdf), corresponding value for matched index and store in 'p1'
else
    ind=max(find(x_val<=z_mag));   % If no, then find the maximum index of any updated (shifted) x_val values < z_mag???
    if ind==length(x_val)               % 
        p1=0;                           % If all values of x_val < z_mag, then 'p1'=0 (x_val is a sorted matrix)
    else
        p1=sum(newpdf(1:ind+1))-sum(newpdf(1:ind)); % If only some values are less, then 'p1'=value from newpdf just greater than z_mag 
    end
end

% Phas=polyval(P_phas,xkj);%measurement using functional model
% 
% x_val_phas=x_val_phas+Phas;%shifting
% 
% if size(find(x_val_phas==z_phas),2)~=0
%     p2=newpdf_phas(find(x_val_phas==z_phas));
% else
%     ind=max(find(x_val_phas<=z_phas));
%     p2=sum(newpdf_phas(1:ind+1))-sum(newpdf_phas(1:ind));
% end
p=p1;
% function p=genprob(z_mag,z_phas,xkj,k)
% %*********Using FEM******
% % if xkj==0;
% %  Mag=0;
% %  Phas=0;
% % else
% %  [Mag,Phas]=calc_field(1,k,xkj);
% %
% % end
% %********Using functional Model*****
% load data3
%
% Mag=polyval(P_mag,xkj);
%
%
% % if xkj==0;
% %     V=V(1);
% % end
% % if xkj==0.2
% %     V=V(2);
% % end
% %
% % if xkj==0.4
% % V=V(3);
% % end
% %
% % if xkj==0.6
% %     V=V(4);
% % end
% load data1
% prftr=transpose(prftr);
% prftr=prftr(:);
%
% prftr=transpose(prftr);
% load data2
%
%
% new=Magf-polyval(P_mag,prftr);
% [newpdf,x]=hist(new,1500);
% newpdf=newpdf/sum(newpdf);
% x=x+Mag;
% if size(find(x==z_mag),2)~=0
%     p=newpdf(find(x==z_mag));
% else
%     ind=max(find(x<=z_mag));
%     p=sum(newpdf(1:ind+1))-sum(newpdf(1:ind));
% end
%
%
%
% %p=ComputeProb(z_mag,'Gaussian',Mag,V_f);
% % M=z_mag-Mag;
% % P=z_phas-Phas;
% % %factor=sqrt((M*cos(P))^2+(M*sin(P))^2);
% % factor=M;
% % p = exp(-(factor)^2/(2*Rk));