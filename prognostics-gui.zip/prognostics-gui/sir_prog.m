function [xki,wki]=sir_prog(xki1,wki1,Mag_fm,P_magn,newpdf,x_val,k,p)
%
% This function is called in parent as: [tx,tw]=sir_prog(pfx(:,k-1),pfw(:,k-1),Mag_fm,P_magn,newpdf,x_val,k,p);


z_mag=Mag_fm(k); % z_mag are the actual measurements
Ns=length(xki1); %no. of samples 

xkj=zeros(Ns,1);
wkj=zeros(size(wki1));
for i=1:Ns
xkj(i)=gennextstate_prog(xki1(i),p); % Draw Samples from state transition pdf
wkj(i)=genprob(z_mag,P_magn,x_val,newpdf,xkj(i)); % Assign weights 
end

%*******normalize weights*********
t=sum(wkj);
wkj=wkj/t;
%*********resample
resamplingscheme=2;
[xki,wki,parentj]=resampling(xkj,wkj,resamplingscheme);
xki=xki';
wki=wki';

